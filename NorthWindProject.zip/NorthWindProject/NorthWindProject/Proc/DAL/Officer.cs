﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace EmployeeHealthWellness.Proc.DAL
{

    public class Order
    {
        Data DataObj = new Data();
        public int Id { get; set; }
        public String EmployeeFullname { get; set; }

        public String ShipName { get; set; }
        public String CustomerID { get; set; }
        public String Name { get; set; }
        public String Surname { get; set; }
        public String NumberOfOrder { get; set; }
      

        public String TotalOrderValue { get; set; }

        public int DirectorateId { get; set; }

        public DateTime Date { get; set; }
        public String CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public String Modifiedby { get; set; }
        public String Guid { get; set; }



        public Order() { }

        public Order(int userID)
        {
            DataObj.SetDbConn(1, DataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLOfficer.OfficerBaseSelect);
            outStr.Append("AND Id=" + userID);

            DataObj.SqlQuery.CommandText = outStr.ToString();
            DataObj.RecSet = DataObj.SqlQuery.ExecuteReader();

            if (DataObj.RecSet.HasRows)
            {
                while (DataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(DataObj.RecSet["Id"]);
        
                    this.Name = DataObj.RecSet["Name"].ToString();
                    this.Surname = DataObj.RecSet["Surname"].ToString();

                    this.NumberOfOrder = DataObj.RecSet["IdentityNumber"].ToString();
                   
                    this.Modifiedby = DataObj.RecSet["ModifiedBy"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(DataObj.RecSet["ModifiedDate"]);

                    this.CreatedBy = DataObj.RecSet["CreatedBy"].ToString();




                }
            }

            DataObj.RecSet.Close();
            DataObj.SetDbConn(0, DataObj.dbConnEHWP);
        }







    }

    public class OrderList
    {
        Data DataObj = new Data();
        public List<Order> Listing { get; set; }

        public OrderList(String startDate,string EndDate, String EmpID ,String CustimerID)
        {
            Listing = new List<Order>();
            DataObj.SetDbConn(1, DataObj.dbConnEHWP);

            StringBuilder outStr = new StringBuilder();
            //outStr.Append(" SELECT 	Id, CaseRef, ClientType, PersalNumber, NAME, Surname, IdentityNumber, Age, Gender, DirectorateId, SubdirectorateId, DesignationId, RegionId, ContactNumber, Active, Deleted, ModifiedBy, ModifiedDate, CreatedBy, CreatedDate, Guid from dcsehwp.tbl_dcsofficer WHERE ('x'='x') ");
            string connectionString = "Data Source=GPDCSDEV01/SAFETY;Initial Catalog=Northwind;User ID=sa;Password=***********" +
                             "Integrated Security=True";

            
           DataSet ds = new DataSet();  
           SqlConnection con; 
  
           SqlCommand cmd = new SqlCommand();  
           SqlParameter sp1 = new SqlParameter();  
           SqlParameter sp2 = new SqlParameter();  
           SqlParameter sp3 = new SqlParameter();  
           SqlParameter sp4 = new SqlParameter();  
  
            con = new SqlConnection(connectionString);  
            cmd.Parameters.Add("@OrderDate", SqlDbType.VarChar).Value = startDate; 
            cmd.Parameters.Add("@[CustomerID]", SqlDbType.VarChar).Value = EmpID;  
            cmd.Parameters.Add("@EmployeeID", SqlDbType.VarChar).Value =CustimerID ;
       
            cmd = new SqlCommand("pr_GetOrderSummary", con);  
            cmd.CommandType = CommandType.StoredProcedure;  
            con.Open();  
            cmd.ExecuteNonQuery();  
            con.Close();  
 

            if (DataObj.RecSet.HasRows)
            {
                while (DataObj.RecSet.Read())
                {
                    Order item = new Order();
                    item.Id = Convert.ToInt32(DataObj.RecSet["Id"]);

                    item.Name = DataObj.RecSet["Name"].ToString();
                    item.Surname = DataObj.RecSet["Surname"].ToString();
                    item.NumberOfOrder = DataObj.RecSet["IdentityNumber"].ToString();
                    
                    item.Modifiedby = DataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(DataObj.RecSet["ModifiedDate"]);
                    item.CreatedBy = DataObj.RecSet["CreatedBy"].ToString();
             

                    Listing.Add(item);
                }
            }

            DataObj.RecSet.Close();
            DataObj.SetDbConn(0, DataObj.dbConnEHWP);
            myTable.DefaultView.Sort = "myColumn DESC";
        }

    }
}