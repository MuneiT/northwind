﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using EmployeeHealthWellness.Proc;
using EmployeeHealthWellness.Proc;

    public class Region
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public String RegionName { get; set; }
        public int Active { get; set; }
        public int Deleted { get; set; }
        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }

        public Region() 
        { }

        public Region(int RegionID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.RegionBaseSelect);
            outStr.Append(" AND Id = " + RegionID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.RegionName = dataObj.RecSet["RegionName"].ToString();
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.Deleted = Convert.ToInt32(dataObj.RecSet["Deleted"]);
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["Modifiedby"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Close DB Connection

        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();

            if (isNew)
            {    
                outStr.Clear();
                outStr.Append(SQLEHWPData.RegionBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.RegionName + "',");
                outStr.Append("'" + Convert.ToInt32(this.Active) + "', ");
                outStr.Append("'" + Convert.ToInt32(this.Deleted) + "', ");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else
            {                  
                outStr.Clear();
                outStr.Append("Update tbl_Region Set ");
                outStr.Append("RegionName = '" + this.RegionName + "', ");
                outStr.Append("Active = '" + Convert.ToInt32(this.Active) + "', ");
                outStr.Append("Deleted = '" + Convert.ToInt32(this.Deleted) + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
          

            return retValue;
        }

        public bool CheckIfExist() //checking if region record exist
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.RegionName))
            {
                outStr.Append("select  * from tbl_Region WHERE ('x'='x') ");
                outStr.Append(" and (");

                if (!string.IsNullOrEmpty(this.RegionName))
                {
                    outStr.Append(" RegionName ='" + this.RegionName + "' ");
                }
            }

            outStr.Append(") ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();


            List<string> ErrorMessage = new List<string>();
            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
                ErrorMessage.Add("* The Region name " + this.RegionName + " already exist.");
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            if (AlreadyExist)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return AlreadyExist;
        }
    }

    public class RegionsList
    {
        Data dataObj = new Data();
        public List<Region> Listing { get; set; }

        public RegionsList() 
        {}

        public RegionsList(string searchColumn, string searchText, string sortBy, int sortByType, bool showOnlyActive)
        {
            Listing = new List<Region>();
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.RegionBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }
            

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    Region item = new Region();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.RegionName = dataObj.RecSet["RegionName"].ToString();
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.Deleted = Convert.ToInt32(dataObj.RecSet["Deleted"]);
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
         }
    }

