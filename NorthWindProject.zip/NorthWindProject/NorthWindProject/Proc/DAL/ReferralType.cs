﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace EmployeeHealthWellness.Proc.DAL
{
  
    public class ReferralType
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int Active { get; set; }
        public String ReferralTypeName { get; set; }
        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public ReferralType() { }

        public ReferralType(int ReferralTypeID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ReferralTypeBaseSelect);
            outStr.Append(" AND Id = " + ReferralTypeID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.ReferralTypeName = dataObj.RecSet["Type"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLEHWPData.ReferralTypeBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.ReferralTypeName + "',");
                outStr.Append("'" + this.Active + "' ,");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_referral_type Set ");
                outStr.Append("TYPE = '" + this.ReferralTypeName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;

        }
        public bool CheckIfExist()
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.ReferralTypeName))
            {
                outStr.Append("select  * from tbl_referral_type  WHERE ('x'='x') ");
                outStr.Append(" and (");

                if (!string.IsNullOrEmpty(this.ReferralTypeName))
                {
                    outStr.Append(" Type ='" + this.ReferralTypeName + "' ");
                }
            }

            outStr.Append(") ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();


            List<string> ErrorMessage = new List<string>();
            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
                ErrorMessage.Add("*  Name with the name supplied " + this.ReferralTypeName + " already exist.");

            }

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            if (AlreadyExist)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return AlreadyExist;
        }
    }

    public class ReferralTypeList
    {
        Data dataObj = new Data();
        public List<ReferralType> Listing { get; set; }
        public ReferralTypeList(bool showOnlyActive)
        {
            Listing = new List<ReferralType>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ReferralTypeBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            outStr.Append("order by CreatedDate");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    ReferralType item = new ReferralType();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.ReferralTypeName = dataObj.RecSet["Type"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }
    public class ProblemType
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int Active { get; set; }
        public String ProblemTypeName { get; set; }

        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public ProblemType() { }

        public ProblemType(int DesignationID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ProblemTypeBaseSelect);
            outStr.Append(" AND Id = " + DesignationID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.ProblemTypeName = dataObj.RecSet["ProblemType"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLEHWPData.ProblemTypeBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.ProblemTypeName + "',");
                outStr.Append("'" + this.Active + "' ,");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_problem_type Set ");
                outStr.Append("ProblemType = '" + this.ProblemTypeName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;

        }
        public bool CheckIfExist()
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.ProblemTypeName))
            {
                outStr.Append("select  * from tbl_problem_type WHERE ('x'='x') ");
                outStr.Append(" and (");

                if (!string.IsNullOrEmpty(this.ProblemTypeName))
                {
                    outStr.Append(" ProblemType ='" + this.ProblemTypeName + "' ");
                }
            }

            outStr.Append(") ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();


            List<string> ErrorMessage = new List<string>();
            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
                ErrorMessage.Add("*  Name with the name supplied " + this.ProblemTypeName + " already exist.");

            }

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            if (AlreadyExist)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return AlreadyExist;
        }
    }

    public class ProblemTypeList
    {
        Data dataObj = new Data();
        public List<ProblemType> Listing { get; set; }
        public ProblemTypeList(bool showOnlyActive)
        {
            Listing = new List<ProblemType>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ProblemTypeBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

           // outStr.Append("order by ProblemType");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    ProblemType item = new ProblemType();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.ProblemTypeName = dataObj.RecSet["ProblemType"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }
}