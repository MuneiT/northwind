﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using EmployeeHealthWellness.Proc;
using System.Configuration;
using EmployeeHealthWellness.Proc.DAL;

public class SupportStaff
{
    Data dataObj = new Data();
    public int Id { get; set; }
    public String Name { get; set; }
    public String Surname { get; set; }
    public String FullName { get; set; }
    public String Email { get; set; }

    public List<TicketItem> SupportTeamCurrentTicketList
    {
        get { return new TicketList(this.Id).Listing; }
        set { }
    } 

    public SupportStaff() { }

    public SupportStaff(int userID)
    {
        dataObj.SetDbConn(1, dataObj.dbConnSysMan);
        StringBuilder outStr = new StringBuilder();
        outStr.Append(SQLData.SupportStaffBaseSelect);
        outStr.Append("AND tUSE.Id=" + userID);

        dataObj.SqlQuery.CommandText = outStr.ToString();
        dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

        if (dataObj.RecSet.HasRows)
        {
            while (dataObj.RecSet.Read())
            {
                this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                this.Name = dataObj.RecSet["Name"].ToString();
                this.Surname = dataObj.RecSet["Surname"].ToString();
                this.FullName = dataObj.RecSet["Name"].ToString() + " " + dataObj.RecSet["Surname"].ToString();
                this.Email = dataObj.RecSet["Email"].ToString();
            }
        }

        dataObj.RecSet.Close();
        dataObj.SetDbConn(0, dataObj.dbConnSysMan);
    }
}

public class SupportStaffList
{
    Data dataObj = new Data();
    public List<SupportStaff> Listing { get; set; }

    public SupportStaffList(bool showOnlyActive)
    {
        Listing = new List<SupportStaff>();
        dataObj.SetDbConn(1, dataObj.dbConnSysMan);
        StringBuilder outStr = new StringBuilder();
        outStr.Append(SQLData.SupportStaffBaseSelect);

        if (showOnlyActive)
        {
            outStr.Append(" AND tUSE.Active = 1 ");
        }

        outStr.Append(" and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"] + " ");

        outStr.Append(" and tROL.AppRoleId IN (" + ConfigurationManager.AppSettings["AdminRoleId"] + "," + ConfigurationManager.AppSettings["SupportRoleId"] + ") ");
        outStr.Append(" order by tUSE.Name");

        dataObj.SqlQuery.CommandText = outStr.ToString();
        dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

        if (dataObj.RecSet.HasRows)
        {
            while (dataObj.RecSet.Read())
            {
                SupportStaff item = new SupportStaff();
                item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                item.Name = dataObj.RecSet["Name"].ToString();
                item.Surname = dataObj.RecSet["Surname"].ToString();
                item.FullName = dataObj.RecSet["Name"].ToString() + " " + dataObj.RecSet["Surname"].ToString();
                item.Email = dataObj.RecSet["Email"].ToString();
                Listing.Add(item);
            }
        }

        dataObj.RecSet.Close();
        dataObj.SetDbConn(0, dataObj.dbConnSysMan);
    }
}
