﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using EmployeeHealthWellness.Proc;



    public class Category
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int Active { get; set; }
        public String CategoryName { get; set; }        
        public Category() { }

        public Category(int CategoryID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.CategoryBaseSelect);
            outStr.Append(" AND Id = " + CategoryID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.CategoryName = dataObj.RecSet["CategoryName"].ToString();
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLData.CategoryBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.CategoryName + "',");
                outStr.Append("'" + this.Active + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update hd_Category Set ");
                outStr.Append("CategoryName = '" + this.CategoryName + "', ");
                outStr.Append("Active = '" + this.Active + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;

        }
    }

    public class CategoryList
    {
        Data dataObj = new Data();
        public List<Category> Listing { get; set; }
        public CategoryList(bool showOnlyActive)
        {
            Listing = new List<Category>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.CategoryBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            outStr.Append("order by CategoryName");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    Category item = new Category();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.CategoryName = dataObj.RecSet["CategoryName"].ToString();
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }
