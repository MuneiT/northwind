﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace EmployeeHealthWellness.Proc.DAL
{

    public class CaseHistory
    {
        Data DataObj = new Data();
        public int Id { get; set; }
        public int CaseId { get; set; }
        public int OfficerId { get; set; }
        public DateTime ReportedDate { get; set; }

        public DateTime ApDate { get; set; }
        public String ProgressNote { get; set; }
        public int CaseHistoryStatus { get; set; }
        public int ReferralType { get; set; }
        public int ServiceType { get; set; }
        public int ProblemCategory { get; set; }
        public int ProblemType { get; set; }


        public String CaseHistoryDescription { get; set; }

        public DateTime Created { get; set; }
        public String CreatedBy { get; set; }
        public DateTime Modified { get; set; }
        public String Modifiedby { get; set; }
        public String Guid { get; set; }

        public CaseHistory() { }

        public CaseHistory(int userID)
        {
            DataObj.SetDbConn(1, DataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.CaseHistoryBaseSelect);
            outStr.Append("AND Id=" + userID);

            DataObj.SqlQuery.CommandText = outStr.ToString();
            DataObj.RecSet = DataObj.SqlQuery.ExecuteReader();

            if (DataObj.RecSet.HasRows)
            {
                while (DataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(DataObj.RecSet["Id"]);
                    this.OfficerId = Convert.ToInt32(DataObj.RecSet["OfficerId"]);
                    this.ReportedDate = Convert.ToDateTime(DataObj.RecSet["ReportedDate"]);
                    this.CaseHistoryStatus = Convert.ToInt32(DataObj.RecSet["CaseStatus"]);
                    this.ReferralType = Convert.ToInt32(DataObj.RecSet["ReferralType"]);
                    this.ServiceType = Convert.ToInt32(DataObj.RecSet["ServiceType"]);
                    this.ProblemCategory = Convert.ToInt32(DataObj.RecSet["ProblemCategory"]);
                    this.ProblemType = Convert.ToInt32(DataObj.RecSet["ProblemType"]);
                    this.CaseHistoryDescription = DataObj.RecSet["CaseDescription"].ToString();
                    this.Modifiedby = DataObj.RecSet["ModifiedBy"].ToString();
                    this.Modified = Convert.ToDateTime(DataObj.RecSet["ModifiedDate"]);
                    this.CreatedBy = DataObj.RecSet["CreatedBy"].ToString();
                    this.Created = Convert.ToDateTime(DataObj.RecSet["CreatedDate"]);
                }
            }

            DataObj.RecSet.Close();
            DataObj.SetDbConn(0, DataObj.dbConnEHWP);
        }





        public int CommitUserChanges(bool isNew)
        {
            DataObj.SetDbConn(1, DataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew)
            {
                outStr.Clear();
                outStr.Append(SQLEHWPData.CaseHistoryBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + Convert.ToInt32(this.CaseId) + "',");
                outStr.Append("'" + Convert.ToInt32(this.OfficerId) + "',");
                outStr.Append("'" + this.ReportedDate.ToString("yyyy-MM-dd") + "',");
                outStr.Append("1,");
                outStr.Append("'" + Convert.ToInt32(this.ReferralType) + "',");
                outStr.Append("'" + Convert.ToInt32(this.ServiceType) + "',");
                outStr.Append("'" + Convert.ToInt32(this.ProblemCategory) + "',");
                outStr.Append("'" + Convert.ToInt32(this.ProblemType) + "',");
                outStr.Append("'" + this.CaseHistoryDescription + "',");
                outStr.Append("'" + this.ApDate.ToString("yyyy-MM-dd") + "',");
                outStr.Append("'" + this.ProgressNote + "',");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.Modified.ToString("yyyy-MM-dd HH:mm:ss") + "',");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.Created.ToString("yyyy-MM-dd HH:mm:ss") + "'");


                outStr.Append(")");
            }
            else
            {
                outStr.Clear();
                outStr.Append("Update tbl_CaseHistory Set ");
                outStr.Append("ApDate = '" + this.ReportedDate.ToString("yyyy-MM-dd") + "', ");
                outStr.Append("CaseHistoryStatus = '" + this.CaseHistoryStatus + "', ");

                outStr.Append("ProgressNote = '" + this.ProgressNote + "', ");

                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.Modified.ToString("yyyy-MM-dd HH:mm:ss") + "'");

                outStr.Append("Where Id = '" + this.Id + "' ");

            }
            DataObj.SqlQuery.CommandText = outStr.ToString();
            DataObj.SqlQuery.ExecuteNonQuery();

            int retValue = this.Id;


            DataObj.SetDbConn(0, DataObj.dbConnEHWP);



            return retValue;
        }



    }

    public class CaseHistoryListing
    {
        Data DataObj = new Data();
        public List<CaseHistory> Listing { get; set; }

        public CaseHistoryListing(int officerId)
        {
            Listing = new List<CaseHistory>();
            DataObj.SetDbConn(1, DataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.CaseHistoryBaseSelect);

            if (officerId > 0)
            {
                outStr.Append("AND OfficerId=" + officerId);
            }

            outStr.Append(" order by CreatedDate ASC");

            DataObj.SqlQuery.CommandText = outStr.ToString();
            DataObj.RecSet = DataObj.SqlQuery.ExecuteReader();

            if (DataObj.RecSet.HasRows)
            {
                while (DataObj.RecSet.Read())
                {
                    CaseHistory item = new CaseHistory();
                    item.Id = Convert.ToInt32(DataObj.RecSet["Id"]);
                    item.CaseId = Convert.ToInt32(DataObj.RecSet["CaseId"]);
                    item.OfficerId = Convert.ToInt32(DataObj.RecSet["OfficerId"]);
                    item.ReportedDate = Convert.ToDateTime(DataObj.RecSet["ReportedDate"]);
                    item.ApDate = Convert.ToDateTime(DataObj.RecSet["ApDate"]);
                    item.CaseHistoryStatus = Convert.ToInt32(DataObj.RecSet["CaseStatus"]);
                    item.ReferralType = Convert.ToInt32(DataObj.RecSet["ReferralType"]);
                    item.ServiceType = Convert.ToInt32(DataObj.RecSet["ServiceType"]);
                    item.ProblemCategory = Convert.ToInt32(DataObj.RecSet["ProblemCategory"]);
                    item.ProblemType = Convert.ToInt32(DataObj.RecSet["ProblemType"]);
                    item.ProgressNote = DataObj.RecSet["ProgressNote"].ToString();
                    item.CaseHistoryDescription = DataObj.RecSet["CaseDescription"].ToString();
                    item.Modifiedby = DataObj.RecSet["ModifiedBy"].ToString();
                    item.Modified = Convert.ToDateTime(DataObj.RecSet["ModifiedDate"]);
                    item.CreatedBy = DataObj.RecSet["CreatedBy"].ToString();
                    item.Created = Convert.ToDateTime(DataObj.RecSet["CreatedDate"]);

                    Listing.Add(item);
                }
            }

            DataObj.RecSet.Close();
            DataObj.SetDbConn(0, DataObj.dbConnEHWP);

        }
    }
}