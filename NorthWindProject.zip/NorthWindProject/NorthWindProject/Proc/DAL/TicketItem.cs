﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Configuration;

namespace EmployeeHealthWellness.Proc.DAL
{
    public class TicketItem
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public String HDTicketNo { get; set; }
        public int RequesterId { get; set; }
        public int LoggedById { get; set; }
        public DateTime LoggedDate { get; set; }
        public String ProblemSubject { get; set; }
        public String ProblemDescription { get; set; }
        //public String CategoryName { get; set; }
        public DateTime ResolvedDate { get; set; }
        public DateTime ClosedDate { get; set; }
        public int CurrentSupportStaffId { get; set; }
        public int PriorityLevelId { get; set; }
        public int CategoryId { get; set; }
        public int StatusCodeId { get; set; }
        public int TypeId { get; set; }
        public String ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public String Guid { get; set; }
        public String RegionName { get; set; }
        public int Active { get; set; }

        public List<TicketUpdatesItem> TicketUpdateHistory
        {
            get { return new TicketUpdatesList(this.Id).Listing; }
            set { }
        }

        public List<TicketScreenshotAttachment> TicketScreenshotAttachements
        {
            get { return new TicketScreenShotAttachmentList(this.Id).Listing; }
            set { }
        }

        public List<TicketClientAvailabilityItem> TicketClientAvailabilityHistory
        {
            get { return new TicketClientAvailabilityList(this.Id).Listing; }
            set { }
        }

        public TicketItem() { }

        public TicketItem(int TicketId)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.TicketBaseSelectNew);
            outStr.Append("AND tTIC.Id = " + TicketId);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.HDTicketNo = dataObj.RecSet["HDTicketNo"].ToString();
                    this.RequesterId = Convert.ToInt32(dataObj.RecSet["RequesterId"]);
                    this.LoggedById = Convert.ToInt32(dataObj.RecSet["LoggedById"]);
                    this.LoggedDate = Convert.ToDateTime(dataObj.RecSet["LoggedDate"]);
                    this.ProblemSubject = dataObj.RecSet["ProblemSubject"].ToString();
                    this.ProblemDescription = dataObj.RecSet["ProblemDescription"].ToString();
                    this.ResolvedDate = Convert.ToDateTime(dataObj.RecSet["ResolvedDate"]);
                    this.ClosedDate = Convert.ToDateTime(dataObj.RecSet["ClosedDate"]);
                    this.CurrentSupportStaffId = Convert.ToInt32(dataObj.RecSet["CurrentSupportStaffId"]);
                    this.PriorityLevelId = Convert.ToInt32(dataObj.RecSet["PriorityLevelId"]);
                    this.CategoryId = Convert.ToInt32(dataObj.RecSet["CategoryId"]);
                    this.StatusCodeId = Convert.ToInt32(dataObj.RecSet["StatusCodeId"]);
                    this.TypeId = Convert.ToInt32(dataObj.RecSet["TypeId"]);
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    this.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    this.Guid = dataObj.RecSet["Guid"].ToString();
                    this.RegionName = dataObj.RecSet["RegionName"].ToString();
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }

        public int CommitTicketChanges(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew)
            {
                outStr.Clear();
                outStr.Append(SQLData.TicketBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.HDTicketNo + "','" + this.RequesterId + "','" + this.LoggedById + "','" + this.LoggedDate.ToString("yyyy-MM-dd HH:mm:ss") + "','" + this.ProblemSubject + "','" + this.ProblemDescription + "',");
                outStr.Append("'" + this.ModifiedBy + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "',");
                outStr.Append("'" + this.Guid + "'");
                outStr.Append(")");
            }
            else
            {
                outStr.Clear();
                outStr.Append("Update hd_tickets Set ");
                outStr.Append("ProblemSubject = '" + this.ProblemSubject + "', ");
                outStr.Append("ProblemDescription = '" + this.ProblemDescription + "', ");
                outStr.Append("ModifiedBy = '" + this.ModifiedBy + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("where Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            int retValue = this.Id;

            if (isNew)
            {
                outStr.Clear();
                outStr.Append("select Id AS newID from hd_tickets where Guid='" + this.Guid + "'");
                dataObj.SqlQuery.CommandText = outStr.ToString();
                retValue = (int)dataObj.SqlQuery.ExecuteScalar();
            }

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;
        }

        public int CommitHelpDeskClientTicketChanges()
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            outStr.Clear();
            outStr.Append("Update hd_tickets Set ");
            outStr.Append("PriorityLevelId = '" + this.PriorityLevelId + "', ");
            outStr.Append("CategoryId = '" + this.CategoryId + "', ");
            outStr.Append("StatusCodeId = '" + this.StatusCodeId + "', ");
            outStr.Append("TypeId = '" + this.TypeId + "', ");

            if (this.StatusCodeId == 7 || this.StatusCodeId == 2 || this.StatusCodeId == 4) // || this.StatusCodeId == 8
            {
                outStr.Append("CurrentSupportStaffId = '0', ");
            }
            else
            {
                outStr.Append("CurrentSupportStaffId = '" + this.CurrentSupportStaffId + "', ");
            }

            TicketItem thisTicket = new TicketItem(this.Id);
            if (thisTicket != null)
            {
                if (thisTicket.ProblemSubject != this.ProblemSubject)
                {
                    outStr.Append("ProblemSubject = '" + this.ProblemSubject + "', ");
                }

                if (thisTicket.ProblemDescription != this.ProblemDescription)
                {
                    outStr.Append("ProblemDescription = '" + this.ProblemDescription + "', ");
                }

                if (thisTicket.StatusCodeId != this.StatusCodeId)
                {
                    if (this.StatusCodeId == 2)
                    {
                        outStr.Append("ResolvedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                    }

                    if (this.StatusCodeId == 4)
                    {
                        outStr.Append("ClosedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                        outStr.Append("Active = 0,");
                    }

                    if (this.StatusCodeId == 7)
                    {
                        outStr.Append("Active = 0, Deleted = 1,");
                    }
                }
            }

            outStr.Append("ModifiedBy = '" + this.ModifiedBy + "', ");
            outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
            outStr.Append("where Id = " + this.Id + "");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            int retValue = this.Id;

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;
        }

        public int CommitITSupprtAgentTicketChanges()
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();            

            outStr.Clear();
            outStr.Append("Update hd_tickets Set ");
            outStr.Append("StatusCodeId = '" + this.StatusCodeId + "', ");

            if (this.StatusCodeId == 2 || this.StatusCodeId == 8)
            {
                outStr.Append("CurrentSupportStaffId = '0', ");
            }
            else
            {
                outStr.Append("CurrentSupportStaffId = '" + this.CurrentSupportStaffId + "', ");
            }


            //outStr.Append("CurrentSupportStaffId = '" + this.CurrentSupportStaffId + "', ");


            TicketItem thisTicket = new TicketItem(this.Id);
            if (thisTicket != null)
            {
                if (thisTicket.StatusCodeId != this.StatusCodeId)
                {
                    if (this.StatusCodeId == 2)
                    {
                        outStr.Append("ResolvedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                    }
                }
            }

            outStr.Append("ModifiedBy = '" + this.ModifiedBy + "', ");
            outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
            outStr.Append("where Id = " + this.Id + "");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            int retValue = this.Id;

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;
        }

        public void GeneralInsertUpdate(String InsertUpdateQuery)
        {
            StringBuilder outStr = new StringBuilder();
            outStr.Clear();
            outStr.Append(InsertUpdateQuery.ToString());
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }

    public class TicketList
    {
        Data dataObj = new Data();
        public List<TicketItem> Listing { get; set; }

        public TicketList(string searchColumn, string searchText, string sortBy, int sortByType, bool mustBeActive, bool viewTicektsforUser, bool viewTicketsForTech, string dateRangeType, String datestart, String dateend)
        {
            Listing = new List<TicketItem>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.TicketBaseSelectNew);

            if (mustBeActive)
            {
                outStr.Append(" AND tTIC.Active = 1 ");
            }

            if (viewTicektsforUser || viewTicketsForTech)
            {
                if (viewTicektsforUser && viewTicketsForTech)
                {
                    outStr.Append(" and (tTIC.RequesterId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                    outStr.Append(" or tTIC.CurrentSupportStaffId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + ") ");
                }
                else if (viewTicketsForTech)
                {
                    outStr.Append(" and tTIC.CurrentSupportStaffId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                }
                else if (viewTicektsforUser)
                {
                    outStr.Append(" and tTIC.RequesterId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                }
            }

            if (!string.IsNullOrEmpty(searchColumn))
            {
                outStr.Append(" AND ");

                switch (searchColumn)
                {
                    case "hd": //HelpDesk No
                        outStr.Append(" tTIC.HDTicketNo = '" + searchText + "' ");
                        break;

                    case "pl": //Priority Levels
                        outStr.Append(" tTIC.PriorityLevelId = '" + searchText + "' ");
                        break;

                    case "cat": //Category
                        outStr.Append(" tTIC.CategoryId = '" + searchText + "' ");
                        break;

                    case "sci": //Status Code Id
                        outStr.Append(" tTIC.StatusCodeId = '" + searchText + "' ");
                        break;

                    case "ti": //Type Id
                        outStr.Append(" tTIC.TypeId = '" + searchText + "' ");
                        break;

                    case "dr"://Date Range
                        switch (dateRangeType)
                        {
                            case "ld"://Logged Date
                                outStr.Append("  (date(LoggedDate) between '" + datestart + "' and '" + dateend + "') ");
                                break;

                            case "rd"://Resolved Date
                                outStr.Append("  (date(ResolvedDate) between '" + datestart + "' and '" + dateend + "') ");
                                break;

                            case "cd"://Closed Date
                                outStr.Append("  (date(ClosedDate) between '" + datestart + "' and '" + dateend + "') ");
                                break;
                        }
                        break;

                    //case "ld"://Logged Date
                    //    outStr.Append(" and (date(LoggedDate) between '" + datestart + "' and '" + dateend + "') ");
                    //    break;
                }
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketItem item = new TicketItem();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.HDTicketNo = dataObj.RecSet["HDTicketNo"].ToString();
                    item.RequesterId = Convert.ToInt32(dataObj.RecSet["RequesterId"]);
                    item.LoggedById = Convert.ToInt32(dataObj.RecSet["LoggedById"]);
                    item.LoggedDate = Convert.ToDateTime(dataObj.RecSet["LoggedDate"]);
                    item.ProblemSubject = dataObj.RecSet["ProblemSubject"].ToString();
                    item.ProblemDescription = dataObj.RecSet["ProblemDescription"].ToString();
                    item.ResolvedDate = Convert.ToDateTime(dataObj.RecSet["ResolvedDate"]);
                    item.ClosedDate = Convert.ToDateTime(dataObj.RecSet["ClosedDate"]);
                    item.CurrentSupportStaffId = Convert.ToInt32(dataObj.RecSet["CurrentSupportStaffId"]);
                    item.PriorityLevelId = Convert.ToInt32(dataObj.RecSet["PriorityLevelId"]);
                    item.CategoryId = Convert.ToInt32(dataObj.RecSet["CategoryId"]);
                    item.StatusCodeId = Convert.ToInt32(dataObj.RecSet["StatusCodeId"]);
                    item.TypeId = Convert.ToInt32(dataObj.RecSet["TypeId"]);
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    item.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    item.Guid = dataObj.RecSet["Guid"].ToString();
                    item.RegionName = dataObj.RecSet["RegionName"].ToString();
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            switch (sortByType)
            {
                case 0:
                    switch (sortBy)
                    {
                        case "hd":
                            Listing = Listing.OrderBy(me => me.HDTicketNo).ToList();
                            break;

                        case "pl":
                            Listing = Listing.OrderBy(me => me.PriorityLevelId).ToList();
                            break;

                        case "cat":
                            Listing = Listing.OrderBy(me => me.CategoryId).ToList();
                            break;

                        case "sci":
                            Listing = Listing.OrderBy(me => me.StatusCodeId).ToList();
                            break;

                        case "ti":
                            Listing = Listing.OrderBy(me => me.TypeId).ToList();
                            break;

                        case "ld":
                            Listing = Listing.OrderBy(me => me.LoggedDate).ToList();
                            break;

                        case "rd":
                            Listing = Listing.OrderBy(me => me.ResolvedDate).ToList();
                            break;

                        case "cd":
                            Listing = Listing.OrderBy(me => me.ClosedDate).ToList();
                            break;

                        default:
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;
                    }
                    break;

                case 1:
                    switch (sortBy)
                    {
                        case "hd":
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;

                        case "pl":
                            Listing = Listing.OrderByDescending(me => me.PriorityLevelId).ToList();
                            break;

                        case "cat":
                            Listing = Listing.OrderByDescending(me => me.CategoryId).ToList();
                            break;

                        case "sci":
                            Listing = Listing.OrderByDescending(me => me.StatusCodeId).ToList();
                            break;

                        case "ti":
                            Listing = Listing.OrderByDescending(me => me.TypeId).ToList();
                            break;

                        case "ld":
                            Listing = Listing.OrderByDescending(me => me.LoggedDate).ToList();
                            break;

                        case "rd":
                            Listing = Listing.OrderByDescending(me => me.ResolvedDate).ToList();
                            break;

                        case "cd":
                            Listing = Listing.OrderByDescending(me => me.ClosedDate).ToList();
                            break;

                        default:
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;
                    }
                    break;
            }
        }

        public TicketList(bool mustBeActive, string selPriorities, string selCategories, string sortBy, string sortByType, string selTicketType, string selStatus, bool viewTicektsforUser, bool viewTicketsForTech, string dateRangeType, String datestart, String dateend, string selTechnician)
        {
            Listing = new List<TicketItem>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.TicketBaseSelectNew);

            #region Done
            if (mustBeActive)
            {
                outStr.Append(" AND tTIC.Active = 1 ");
            }

            if (viewTicektsforUser || viewTicketsForTech)
            {
                if (viewTicektsforUser && viewTicketsForTech)
                {
                    outStr.Append(" and (tTIC.RequesterId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                    outStr.Append(" or tTIC.CurrentSupportStaffId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + ") ");
                }
                else if (viewTicketsForTech)
                {
                    outStr.Append(" and tTIC.CurrentSupportStaffId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                }
                else if (viewTicektsforUser)
                {
                    outStr.Append(" and tTIC.RequesterId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                }
            }
            #endregion

            if (!string.IsNullOrEmpty(dateRangeType))
            {
                switch (dateRangeType)
                {
                    case "ld"://Logged Date
                        outStr.Append("  and (date(LoggedDate) between '" + datestart + "' and '" + dateend + "') ");
                        break;

                    case "rd"://Resolved Date
                        outStr.Append("  and (date(ResolvedDate) between '" + datestart + "' and '" + dateend + "') ");
                        break;

                    case "cd"://Closed Date
                        outStr.Append("  and (date(ClosedDate) between '" + datestart + "' and '" + dateend + "') ");
                        break;
                }
            }

            //Service Channels Filter
            if (!string.IsNullOrEmpty(selPriorities))
                outStr.Append(" AND tTIC.PriorityLevelId IN (" + selPriorities + ") ");

            if (!string.IsNullOrEmpty(selCategories))
                outStr.Append(" AND tTIC.CategoryId IN (" + selCategories + ") ");

            if (!string.IsNullOrEmpty(selTicketType))
                outStr.Append(" AND tTIC.TypeId IN (" + selTicketType + ") ");

            if (!string.IsNullOrEmpty(selStatus))
                outStr.Append(" AND tTIC.StatusCodeId IN (" + selStatus + ") ");

            if (!string.IsNullOrEmpty(selTechnician) && (Gen.isSpecificType(selTechnician, "int")))
            {
                if (Convert.ToInt32(selTechnician) > 0)
                {
                    outStr.Append(" AND tTIC.CurrentSupportStaffId = " + selTechnician + " ");
                }
            }

            //if (!string.IsNullOrEmpty(searchColumn))
            //{
            //    outStr.Append(" AND ");

            //    switch (searchColumn)
            //    {
            //        case "hd": //HelpDesk No
            //            outStr.Append(" HDTicketNo = '" + searchText + "' ");
            //            break;

            //        case "pl": //Priority Levels
            //            outStr.Append(" PriorityLevelId = '" + searchText + "' ");
            //            break;

            //        case "cat": //Category
            //            outStr.Append(" CategoryId = '" + searchText + "' ");
            //            break;

            //        case "sci": //Status Code Id
            //            outStr.Append(" StatusCodeId = '" + searchText + "' ");
            //            break;

            //        case "ti": //Type Id
            //            outStr.Append(" TypeId = '" + searchText + "' ");
            //            break;

            //        case "dr"://Date Range
            //            switch (dateRangeType)
            //            {
            //                case "ld"://Logged Date
            //                    outStr.Append("  (date(LoggedDate) between '" + datestart + "' and '" + dateend + "') ");
            //                    break;

            //                case "rd"://Resolved Date
            //                    outStr.Append("  (date(ResolvedDate) between '" + datestart + "' and '" + dateend + "') ");
            //                    break;

            //                case "cd"://Closed Date
            //                    outStr.Append("  (date(ClosedDate) between '" + datestart + "' and '" + dateend + "') ");
            //                    break;
            //            }      
            //            break;

            //        //case "ld"://Logged Date
            //        //    outStr.Append(" and (date(LoggedDate) between '" + datestart + "' and '" + dateend + "') ");
            //        //    break;
            //    }
            //}

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketItem item = new TicketItem();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.HDTicketNo = dataObj.RecSet["HDTicketNo"].ToString();
                    item.RequesterId = Convert.ToInt32(dataObj.RecSet["RequesterId"]);
                    item.LoggedById = Convert.ToInt32(dataObj.RecSet["LoggedById"]);
                    item.LoggedDate = Convert.ToDateTime(dataObj.RecSet["LoggedDate"]);
                    item.ProblemSubject = dataObj.RecSet["ProblemSubject"].ToString();
                    item.ProblemDescription = dataObj.RecSet["ProblemDescription"].ToString();
                    item.ResolvedDate = Convert.ToDateTime(dataObj.RecSet["ResolvedDate"]);
                    item.ClosedDate = Convert.ToDateTime(dataObj.RecSet["ClosedDate"]);
                    item.CurrentSupportStaffId = Convert.ToInt32(dataObj.RecSet["CurrentSupportStaffId"]);
                    item.PriorityLevelId = Convert.ToInt32(dataObj.RecSet["PriorityLevelId"]);
                    item.CategoryId = Convert.ToInt32(dataObj.RecSet["CategoryId"]);
                    item.StatusCodeId = Convert.ToInt32(dataObj.RecSet["StatusCodeId"]);
                    item.TypeId = Convert.ToInt32(dataObj.RecSet["TypeId"]);
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    item.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    item.Guid = dataObj.RecSet["Guid"].ToString();
                    item.RegionName = dataObj.RecSet["RegionName"].ToString();
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            switch (sortByType)
            {
                case "ASC":
                    switch (sortBy)
                    {
                        case "hd":
                            Listing = Listing.OrderBy(me => me.HDTicketNo).ToList();
                            break;

                        case "pl":
                            Listing = Listing.OrderBy(me => me.PriorityLevelId).ToList();
                            break;

                        case "cat":
                            Listing = Listing.OrderBy(me => me.CategoryId).ToList();
                            break;

                        case "sci":
                            Listing = Listing.OrderBy(me => me.StatusCodeId).ToList();
                            break;

                        case "ti":
                            Listing = Listing.OrderBy(me => me.TypeId).ToList();
                            break;

                        case "ld":
                            Listing = Listing.OrderBy(me => me.LoggedDate).ToList();
                            break;

                        case "rd":
                            Listing = Listing.OrderBy(me => me.ResolvedDate).ToList();
                            break;

                        case "cd":
                            Listing = Listing.OrderBy(me => me.ClosedDate).ToList();
                            break;

                        case "ictt":
                            Listing = Listing.OrderBy(me => me.CurrentSupportStaffId).ToList();
                            break;

                        default:
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;
                    }
                    break;

                case "DESC":
                    switch (sortBy)
                    {
                        case "hd":
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;

                        case "pl":
                            Listing = Listing.OrderByDescending(me => me.PriorityLevelId).ToList();
                            break;

                        case "cat":
                            Listing = Listing.OrderByDescending(me => me.CategoryId).ToList();
                            break;

                        case "sci":
                            Listing = Listing.OrderByDescending(me => me.StatusCodeId).ToList();
                            break;

                        case "ti":
                            Listing = Listing.OrderByDescending(me => me.TypeId).ToList();
                            break;

                        case "ld":
                            Listing = Listing.OrderByDescending(me => me.LoggedDate).ToList();
                            break;

                        case "rd":
                            Listing = Listing.OrderByDescending(me => me.ResolvedDate).ToList();
                            break;

                        case "cd":
                            Listing = Listing.OrderByDescending(me => me.ClosedDate).ToList();
                            break;

                        case "ictt":
                            Listing = Listing.OrderByDescending(me => me.CurrentSupportStaffId).ToList();
                            break;

                        default:
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;
                    }
                    break;
            }
        }

        public TicketList(int SupportITId)
        {
            Listing = new List<TicketItem>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.TicketBaseSelectNew);

            if (SupportITId > 0)
            {
                outStr.Append(" AND tTIC.CurrentSupportStaffId = " + SupportITId);
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketItem item = new TicketItem();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.HDTicketNo = dataObj.RecSet["HDTicketNo"].ToString();
                    item.RequesterId = Convert.ToInt32(dataObj.RecSet["RequesterId"]);
                    item.LoggedById = Convert.ToInt32(dataObj.RecSet["LoggedById"]);
                    item.LoggedDate = Convert.ToDateTime(dataObj.RecSet["LoggedDate"]);
                    item.ProblemSubject = dataObj.RecSet["ProblemSubject"].ToString();
                    item.ProblemDescription = dataObj.RecSet["ProblemDescription"].ToString();
                    item.ResolvedDate = Convert.ToDateTime(dataObj.RecSet["ResolvedDate"]);
                    item.ClosedDate = Convert.ToDateTime(dataObj.RecSet["ClosedDate"]);
                    item.CurrentSupportStaffId = Convert.ToInt32(dataObj.RecSet["CurrentSupportStaffId"]);
                    item.PriorityLevelId = Convert.ToInt32(dataObj.RecSet["PriorityLevelId"]);
                    item.CategoryId = Convert.ToInt32(dataObj.RecSet["CategoryId"]);
                    item.StatusCodeId = Convert.ToInt32(dataObj.RecSet["StatusCodeId"]);
                    item.TypeId = Convert.ToInt32(dataObj.RecSet["TypeId"]);
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    item.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    item.Guid = dataObj.RecSet["Guid"].ToString();
                    item.RegionName = dataObj.RecSet["RegionName"].ToString();
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
        }
        //filter ticketlist
        public TicketList(bool mustBeActive, string selPriorities, string selCategories, string sortBy, string sortByType, string selTicketType, string selStatus, bool viewTicektsforUser, bool viewTicketsForTech, string dateRangeType, String datestart, String dateend, string selTechnician, string selSearchBy, string SearchText)
        {
            Listing = new List<TicketItem>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.FilterTickekBaseSelect);

            if (selSearchBy == "Chief Directorate")
            {
                outStr.Append(" INNER JOIN dcssysman.tbl_directorate tDir  ON tDir.Id=tUser.DirectorateId ");

                outStr.Append(" And tDir.Id = " + SearchText);
            }

            if (selSearchBy == "Directorate")
            {
                outStr.Append(" INNER JOIN dcssysman.tbl_divisions tDiv  ON tDiv.Id=tUser.DivisionId ");

                outStr.Append(" And tDiv.Id = " + SearchText);
            }

            if (selSearchBy == "Sub-Directorate")
            {
                outStr.Append(" INNER JOIN dcssysman.tbl_subdirectorates tSub ON tSub.Id=tUser.SubdirectorateId ");

                outStr.Append(" And tSub.Id = " + SearchText);
            }

            if (selSearchBy == "Region")
            {
                outStr.Append(" INNER JOIN dcssysman.tbl_region tReg  ON tReg.Id=tUser.RegionId ");

                outStr.Append(" And tReg.Id = " + SearchText);
            }

            if (viewTicektsforUser || viewTicketsForTech)
            {
                if (viewTicektsforUser && viewTicketsForTech)
                {
                    outStr.Append(" and (tDesk.RequesterId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                    outStr.Append(" or tDesk.CurrentSupportStaffId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + ") ");
                }
                else if (viewTicketsForTech)
                {
                    outStr.Append(" and tDesk.CurrentSupportStaffId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                }
                else if (viewTicektsforUser)
                {
                    outStr.Append(" and tDesk.RequesterId = " + HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + " ");
                }
            }

            if (!string.IsNullOrEmpty(dateRangeType))
            {
                switch (dateRangeType)
                {
                    case "ld"://Logged Date
                        outStr.Append("  and (date(LoggedDate) between '" + datestart + "' and '" + dateend + "') ");
                        break;

                    case "rd"://Resolved Date
                        outStr.Append("  and (date(ResolvedDate) between '" + datestart + "' and '" + dateend + "') ");
                        break;

                    case "cd"://Closed Date
                        outStr.Append("  and (date(ClosedDate) between '" + datestart + "' and '" + dateend + "') ");
                        break;
                }
            }

            //Service Channels Filter
            if (!string.IsNullOrEmpty(selPriorities))
                outStr.Append(" AND tDesk.PriorityLevelId IN (" + selPriorities + ") ");

            if (!string.IsNullOrEmpty(selCategories))
                outStr.Append(" AND tDesk.CategoryId IN (" + selCategories + ") ");

            if (!string.IsNullOrEmpty(selTicketType))
                outStr.Append(" AND tDesk.TypeId IN (" + selTicketType + ") ");

            if (!string.IsNullOrEmpty(selStatus))
                outStr.Append(" AND tDesk.StatusCodeId IN (" + selStatus + ") ");

            if (!string.IsNullOrEmpty(selTechnician) && (Gen.isSpecificType(selTechnician, "int")))
            {
                if (Convert.ToInt32(selTechnician) > 0)
                {
                    outStr.Append(" AND tDesk.CurrentSupportStaffId = " + selTechnician + " ");
                }
            }
                
            

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketItem item = new TicketItem();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.HDTicketNo = dataObj.RecSet["HDTicketNo"].ToString();
                    item.RequesterId = Convert.ToInt32(dataObj.RecSet["RequesterId"]);
                    item.LoggedById = Convert.ToInt32(dataObj.RecSet["LoggedById"]);
                    item.LoggedDate = Convert.ToDateTime(dataObj.RecSet["LoggedDate"]);
                    item.ProblemSubject = dataObj.RecSet["ProblemSubject"].ToString();
                    item.ProblemDescription = dataObj.RecSet["ProblemDescription"].ToString();
                    item.ResolvedDate = Convert.ToDateTime(dataObj.RecSet["ResolvedDate"]);
                    item.ClosedDate = Convert.ToDateTime(dataObj.RecSet["ClosedDate"]);
                    item.CurrentSupportStaffId = Convert.ToInt32(dataObj.RecSet["CurrentSupportStaffId"]);
                    item.PriorityLevelId = Convert.ToInt32(dataObj.RecSet["PriorityLevelId"]);
                    item.CategoryId = Convert.ToInt32(dataObj.RecSet["CategoryId"]);
                    item.StatusCodeId = Convert.ToInt32(dataObj.RecSet["StatusCodeId"]);
                    item.TypeId = Convert.ToInt32(dataObj.RecSet["TypeId"]);
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    item.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    item.RegionName = dataObj.RecSet["RegionName"].ToString();
                    item.Guid = dataObj.RecSet["Guid"].ToString();
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            switch (sortByType)
            {
                case "ASC":
                    switch (sortBy)
                    {
                        case "hd":
                            Listing = Listing.OrderBy(me => me.HDTicketNo).ToList();
                            break;

                        case "pl":
                            Listing = Listing.OrderBy(me => me.PriorityLevelId).ToList();
                            break;

                        case "cat":
                            Listing = Listing.OrderBy(me => me.CategoryId).ToList();
                            break;

                        case "sci":
                            Listing = Listing.OrderBy(me => me.StatusCodeId).ToList();
                            break;

                        case "ti":
                            Listing = Listing.OrderBy(me => me.TypeId).ToList();
                            break;

                        case "ld":
                            Listing = Listing.OrderBy(me => me.LoggedDate).ToList();
                            break;

                        case "rd":
                            Listing = Listing.OrderBy(me => me.ResolvedDate).ToList();
                            break;

                        case "cd":
                            Listing = Listing.OrderBy(me => me.ClosedDate).ToList();
                            break;

                        case "ictt":
                            Listing = Listing.OrderBy(me => me.CurrentSupportStaffId).ToList();
                            break;

                        default:
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;
                    }
                    break;

                case "DESC":
                    switch (sortBy)
                    {
                        case "hd":
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;

                        case "pl":
                            Listing = Listing.OrderByDescending(me => me.PriorityLevelId).ToList();
                            break;

                        case "cat":
                            Listing = Listing.OrderByDescending(me => me.CategoryId).ToList();
                            break;

                        case "sci":
                            Listing = Listing.OrderByDescending(me => me.StatusCodeId).ToList();
                            break;

                        case "ti":
                            Listing = Listing.OrderByDescending(me => me.TypeId).ToList();
                            break;

                        case "ld":
                            Listing = Listing.OrderByDescending(me => me.LoggedDate).ToList();
                            break;

                        case "rd":
                            Listing = Listing.OrderByDescending(me => me.ResolvedDate).ToList();
                            break;

                        case "cd":
                            Listing = Listing.OrderByDescending(me => me.ClosedDate).ToList();
                            break;

                        case "ictt":
                            Listing = Listing.OrderByDescending(me => me.CurrentSupportStaffId).ToList();
                            break;

                        default:
                            Listing = Listing.OrderByDescending(me => me.HDTicketNo).ToList();
                            break;
                    }
                    break;
            }
        }
    
    }

    public class TicketUpdatesItem
    {
        public int Id { get; set; }
        public int TicketId { get; set; }
        public int Asigned_Support_Staff_Id { get; set; }
        public String Update_Description { get; set; }        
        public String ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
    }

    public class TicketUpdatesList
    {
        Data dataObj = new Data();
        public List<TicketUpdatesItem> Listing { get; set; }

        public TicketUpdatesList(int TicketId)
        {
            Listing = new List<TicketUpdatesItem>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.TicketHistoryBaseSelect);

            outStr.Append(" AND TicketId = " + TicketId);
            outStr.Append(" ORDER BY ModifiedDate DESC");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketUpdatesItem item = new TicketUpdatesItem();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.TicketId = Convert.ToInt32(dataObj.RecSet["TicketId"].ToString());
                    item.Asigned_Support_Staff_Id = Convert.ToInt32(dataObj.RecSet["Asigned_Support_Staff_Id"]);
                    item.Update_Description = dataObj.RecSet["Update_Description"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    item.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }

    public class TicketLifeCycle
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int TicketId { get; set; }
        public int StatusId { get; set; }
        public int Support_Staff_Id { get; set; }
        public String ModifiedBy { get; set; }
        public DateTime LifeCycleDate { get; set; }

        public TicketLifeCycle() { }

        public TicketLifeCycle(int TicketId)
        {

            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.TicketLifeCycleBaseSelect);

            if (TicketId > 0)
            {
                outStr.Append(" AND TicketId = " + TicketId);
            }


            outStr.Append(" ORDER BY LifeCycleDate DESC");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {

                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.TicketId = Convert.ToInt32(dataObj.RecSet["TicketId"].ToString());
                    this.StatusId = Convert.ToInt32(dataObj.RecSet["StatusId"].ToString());
                    this.Support_Staff_Id = Convert.ToInt32(dataObj.RecSet["Support_Staff_Id"]);
                    this.LifeCycleDate = Convert.ToDateTime(dataObj.RecSet["LifeCycleDate"]);
                    this.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    //Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }

    public class TicketLifeCycleList
    {
        Data dataObj = new Data();
        public List<TicketLifeCycle> Listing { get; set; }

        public TicketLifeCycleList(int TicketId, int supportStaffId, String datestart, String dateend)
        {
            Listing = new List<TicketLifeCycle>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.TicketLifeCycleBaseSelect);

            if (TicketId > 0)
            {
                outStr.Append(" AND TicketId = " + TicketId);
            }

            if (supportStaffId > 0) //For Reporting Purposes
            {
                outStr.Append(" AND Support_Staff_Id = " + supportStaffId);
            }

            if (datestart != null && dateend != null)
            {
                outStr.Append("  AND (date(LifeCycleDate) between '" + datestart + "' and '" + dateend + "') ");
            }

            outStr.Append(" ORDER BY LifeCycleDate DESC");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketLifeCycle item = new TicketLifeCycle();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.TicketId = Convert.ToInt32(dataObj.RecSet["TicketId"].ToString());
                    item.StatusId = Convert.ToInt32(dataObj.RecSet["StatusId"].ToString());
                    item.Support_Staff_Id = Convert.ToInt32(dataObj.RecSet["Support_Staff_Id"]);
                    item.LifeCycleDate = Convert.ToDateTime(dataObj.RecSet["LifeCycleDate"]);
                    item.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }

    public class TicketScreenshotAttachment
    {
        public TicketScreenshotAttachment() { }
        public int recID { get; set; }
        public int ticketID { get; set; }
        public String filename { get; set; }
        public String title { get; set; }
        public String extention { get; set; }
    }

    public class TicketScreenShotAttachmentList
    {
        Data dataObj = new Data();
        public List<TicketScreenshotAttachment> Listing { get; set; }
        public TicketScreenShotAttachmentList() { }

        public TicketScreenShotAttachmentList(int ticketId)
        {
            Listing = new List<TicketScreenshotAttachment>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            outStr.Append("select ");
            outStr.Append("tATT.id as vID, ");
            outStr.Append("tATT.ticket_id as vTICKETID, ");
            outStr.Append("tATT.filename as vFILENAME, ");
            outStr.Append("tATT.title as vTITLE, ");
            outStr.Append("tATT.extention as vEXTENTION ");
            outStr.Append("from hd_ticket_screenshott_attachement tATT ");
            outStr.Append("where tATT.ticket_id=" + ticketId + " ");
            outStr.Append("order by tATT.title");

            String query = outStr.ToString();

            dataObj.SqlQuery.CommandText = query;
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketScreenshotAttachment item = new TicketScreenshotAttachment();
                    item.recID = Convert.ToInt32(dataObj.RecSet["vID"]);
                    item.ticketID = Convert.ToInt32(dataObj.RecSet["vTICKETID"]);
                    item.filename = dataObj.RecSet["vFILENAME"].ToString();
                    item.title = dataObj.RecSet["vTITLE"].ToString();
                    item.extention = dataObj.RecSet["vEXTENTION"].ToString();
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }

    public class TicketClientAvailabilityItem
    {
        public int Id { get; set; }
        public int TicketId { get; set; }
        public int SentById { get; set; }
        public String MessageSent { get; set; }
        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String ModifiedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public String Guid { get; set; }
    }

    public class TicketClientAvailabilityList
    {
        Data dataObj = new Data();
        public List<TicketClientAvailabilityItem> Listing { get; set; }

        public TicketClientAvailabilityList(int TicketId)
        {
            Listing = new List<TicketClientAvailabilityItem>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append("select * from hd_clientavailability_history where ('x'='x') ");

            if (TicketId > 0)
            {
                outStr.Append(" AND TicketId = " + TicketId);
            }

            outStr.Append(" ORDER BY CreatedDate DESC");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    TicketClientAvailabilityItem item = new TicketClientAvailabilityItem();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.TicketId = Convert.ToInt32(dataObj.RecSet["TicketId"].ToString());
                    item.SentById = Convert.ToInt32(dataObj.RecSet["SentById"].ToString());
                    item.MessageSent = dataObj.RecSet["MessageSent"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.ModifiedBy = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }

    public class TicketParamsItem
    {
        public int TicketId { get; set; }
        public String TicketHDNo { get; set; }
        public String TicketStatus { get; set; }
        public String Email_WhoToNotify { get; set; }
        public String Email_Message { get; set; }
        public String Email_Subject { get; set; }
        public String Email_LoggedByEmail { get; set; }
        public String Email_sentfromEmail { get; set; }
        public String Email_sentfromName { get; set; }
        public String Email_sentToEmail { get; set; }
        public String Email_sentToName { get; set; }
        public bool Email_isForSomeone { get; set; }
        public bool Email_includeDevTeam { get; set; }
        public bool Email_isNotification { get; set; }
    }


   
}