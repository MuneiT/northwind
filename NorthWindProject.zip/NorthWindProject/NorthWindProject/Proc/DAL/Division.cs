﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using EmployeeHealthWellness.Proc;
using EmployeeHealthWellness.Proc;


    public class Division
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int DirectorateId { get; set; }
        //public String DirectorateName { get; set; }
        public String DivisionName { get; set; }
        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public int Active { get; set; }

        public Division() { }

        public Division(int DivisionID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.DivisionBaseSelect);
            outStr.Append(" AND Id = " + DivisionID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.DirectorateId = Convert.ToInt32(dataObj.RecSet["DirectorateId"]);
                    this.DivisionName = dataObj.RecSet["DivisionName"].ToString();
                    //this.DirectorateName = dataObj.RecSet["DirectorateName"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["Modifiedby"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Close DB Connection
        }

        public void CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLData.DivisionBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.DirectorateId + "',");
                outStr.Append("'" + this.DivisionName + "',");
                outStr.Append("'" + this.Active + "',");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_Divisions Set ");
                outStr.Append("DirectorateId = '" + this.DirectorateId + "', ");
                outStr.Append("DivisionName = '" + this.DivisionName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

        }
    }

    public class DivisionList
    {
        Data dataObj = new Data();
        public List<Division> Listing { get; set; }
        public DivisionList() { }

        public DivisionList(int DirectorateId, bool showOnlyActive)
        {
            Listing = new List<Division>();
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.DivisionBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            if(DirectorateId > 0)
            {
                outStr.Append(" AND DirectorateId = '" + DirectorateId + "' ");
            }

            outStr.Append(" order by DivisionName");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    Division item = new Division();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.DirectorateId = Convert.ToInt32(dataObj.RecSet["DirectorateId"]);
                    item.DivisionName = dataObj.RecSet["DivisionName"].ToString();
                    //item.DirectorateName = dataObj.RecSet["DirectorateName"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["Modifiedby"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
        }
    }
