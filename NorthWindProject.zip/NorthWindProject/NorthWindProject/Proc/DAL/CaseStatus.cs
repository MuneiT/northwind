﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace EmployeeHealthWellness.Proc.DAL
{

    public class CaseStatus
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int Active { get; set; }
        public String CaseStatusName { get; set; }

        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public CaseStatus() { }

        public CaseStatus(int DesignationID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.CaseStatusBaseSelect);
            outStr.Append(" AND Id = " + DesignationID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.CaseStatusName = dataObj.RecSet["CaseStatusName"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLEHWPData.CaseStatusBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.CaseStatusName + "',");
                outStr.Append("'" + this.Active + "' ,");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_case_status Set ");
                outStr.Append("CaseStatusName = '" + this.CaseStatusName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }
            String retValue = this.Id.ToString();
            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

      

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;

        }
        public bool CheckIfExist()
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.CaseStatusName))
            {
                outStr.Append("select  * from tbl_case_status  WHERE ('x'='x') ");
                outStr.Append(" and (");

                if (!string.IsNullOrEmpty(this.CaseStatusName))
                {
                    outStr.Append(" CaseStatusName ='" + this.CaseStatusName + "' ");
                }
            }

            outStr.Append(") ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();


            List<string> ErrorMessage = new List<string>();
            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
                ErrorMessage.Add("*  Name with the name supplied " + this.CaseStatusName + " already exist.");

            }

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            if (AlreadyExist)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return AlreadyExist;
        }
    }

    public class CaseStatusList
    {
        Data dataObj = new Data();
        public List<CaseStatus> Listing { get; set; }
        public CaseStatusList(bool showOnlyActive)
        {
            Listing = new List<CaseStatus>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.CaseStatusBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            outStr.Append("order by CaseStatusName");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    CaseStatus item = new CaseStatus();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.CaseStatusName = dataObj.RecSet["CaseStatusName"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }
}