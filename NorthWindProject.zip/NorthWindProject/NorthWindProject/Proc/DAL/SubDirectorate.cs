﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using EmployeeHealthWellness.Proc;

namespace SystemsManager.Proc.DAL
{
    public class SubDirectorate
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int DirectorateId { get; set; }
        public String SubDirName { get; set; }
        public String DirectorateName { get; set; }
        public int Active { get; set; }
        public int Deleted { get; set; }
        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public SubDirectorate() { }

        public SubDirectorate(int SubDirectorateId)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.SubDirectorateSQLSelect);
            outStr.Append(" AND sub.Id = " + SubDirectorateId);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.Deleted = Convert.ToInt32(dataObj.RecSet["Deleted"]);
                    this.DirectorateId = Convert.ToInt32(dataObj.RecSet["DirectorateId"]);
                    this.SubDirName = dataObj.RecSet["SubDirName"].ToString();
                    this.DirectorateName = dataObj.RecSet["DivisionName"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["Modifiedby"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Close DB Connection
        }

        public void CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLData.SubDirectorateSQLInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.DirectorateId + "',");
                outStr.Append("'" + this.SubDirName + "',");
                outStr.Append("'" + this.Active + "',");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_subdirectorates Set ");
                outStr.Append("DirectorateId = '" + this.DirectorateId + "', ");
                outStr.Append("SubDirName = '" + this.SubDirName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
        }
    }

    public class SubDirectorateList
    {
        Data dataObj = new Data();
        public List<SubDirectorate> Listing { get; set; }
        public SubDirectorateList() { }

        public SubDirectorateList(int DirectorateId, bool showOnlyActive)
        {
            Listing = new List<SubDirectorate>();
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.SubDirectorateSQLSelect);

            if (showOnlyActive)
            {
                outStr.Append(" And Active = 1 ");
            }

            if (DirectorateId > 0)
            {
                outStr.Append(" And DirectorateId = '" + DirectorateId + "' ");
            }

            outStr.Append(" order by SubDirName ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    SubDirectorate item = new SubDirectorate();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.Deleted = Convert.ToInt32(dataObj.RecSet["Deleted"]);
                    item.DirectorateId = Convert.ToInt32(dataObj.RecSet["DirectorateId"]);
                    item.SubDirName = dataObj.RecSet["SubDirName"].ToString();
                    //item.DirectorateName = dataObj.RecSet["DivisionName"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["Modifiedby"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
        }
    }
}