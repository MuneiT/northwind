﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class AppExceptions : Exception
{
    public List<string> ErrorMessage { get; set; }
}
