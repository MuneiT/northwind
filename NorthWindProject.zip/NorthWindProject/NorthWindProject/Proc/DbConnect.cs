﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Odbc;
using System.Configuration;
using System.Data;

public class Data
{
    public OdbcConnection dbConnSysMan = new OdbcConnection(ConfigurationManager.AppSettings["DSN_SYSMAN"]);
    public OdbcConnection dbConnEHWP = new OdbcConnection(ConfigurationManager.AppSettings["DSN_EHWP"]);
    public OdbcCommand SqlQuery = new OdbcCommand();
    public OdbcDataReader RecSet;

    public void SetDbConn(int state, OdbcConnection db)
    {
        switch (state)
        {
            case -1:
                db.Close();
                db.Dispose();
                break;

            case 0:
                if (db.State == System.Data.ConnectionState.Open)
                {
                    db.Close();
                }
                break;

            case 1:
                SqlQuery.Connection = db;
                if (db.State != System.Data.ConnectionState.Closed)
                {
                    db.Close();
                    db.Open();
                }
                else
                {
                    db.Open();
                }
                break;

            //case -1:
            //    db.Close();
            //    db.Dispose();
            //    break;

            //case 0:
            //    //if (db.State == System.Data.ConnectionState.Open)
            //    //{
            //        db.Close();
            //        db.Dispose();
            //    //}      
            //    break;

            //case 1:
            //    SqlQuery.Connection = db;
            //    if (db.State == ConnectionState.Open)
            //    {
            //        db.Close();
            //        db.Dispose();
            //        db.Open();
            //    }
            //    else
            //    {
            //        db.Open();
            //    }
            //    break;
        }
    }

    public void SetMssqlDbConn(int state, OdbcConnection db)
    {
        switch (state)
        {


                //Old Code Version 2
            case -1:
                db.Close();
                db.Dispose();
                break;

            case 0:
                //if (db.State == System.Data.ConnectionState.Open)
                //{
                db.Close();
                db.Dispose();
                //}   
                break;

            case 1:
                db.ConnectionString = db.ConnectionString + ";UID=" + ConfigurationManager.AppSettings["DSN_UID"] + ";PWD=" + ConfigurationManager.AppSettings["DSN_PWD"] + ";";
                SqlQuery.Connection = db;
                if (db.State != System.Data.ConnectionState.Closed)
                {
                    db.Close();
                    db.Open();
                }
                else
                {
                    db.Open();
                }
                break;


                //Old Code Version 1
                //if (db.State == System.Data.ConnectionState.Open)
                //{
                //    db.Close();
                //}

                //db.ConnectionString = db.ConnectionString + ";UID=" + ConfigurationManager.AppSettings["DSN_UID"] + ";PWD=" + ConfigurationManager.AppSettings["DSN_PWD"] + ";";
                //SqlQuery.Connection = db;
                //db.Open();
                //break;
        }
    }
}
