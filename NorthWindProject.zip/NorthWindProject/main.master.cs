﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Configuration;

namespace EmployeeHealthWellness
{
    public partial class main : System.Web.UI.MasterPage
    {
        protected override void OnInit(EventArgs e)
        {
            if (Request.Cookies.Get(ConfigurationManager.AppSettings["PrimaryCookie"]) == null)
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            lit_fullname.Text = Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["name"] + " " + Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["surname"];

            lit_date.Text = DateTime.Now.ToString("MMMM dd, yyyy");

            buildMainMenu();
        }

        public HtmlGenericControl BodyTag
        {
            get
            {
                return bodyPrimary;
            }
            set
            {
                bodyPrimary = value;
            }
        }

        protected void buildMainMenu()
        {
     
            bool CaseAdmin = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["CaseAdmin"]);
            bool CaseManager = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["CaseManager"]);

            lit_mainmenu.Text = "";
            lit_mainmenu.Text += "<ul class=\"menu\">";

            if (CaseAdmin || CaseManager)
            {
                lit_mainmenu.Text += "    <li><a href=\"StartUp.html?page=Dashboard.aspx\">Dashboard</a></li>";
            }



            lit_mainmenu.Text += "    <li><a href=\"#\">EHWP CASE MANAGEMENT</a>";
            lit_mainmenu.Text += "          <ul>";
            lit_mainmenu.Text += "              <li><a href=\"StartUp.html?page=CaseList.aspx\" class=\"settings\">Case List</a></li>";

            lit_mainmenu.Text += "            <li><a href=\"https://app.powerbi.com/groups/me/reports/9f220f4e-0fac-4a75-bb94-8e1ea870d29c/ReportSection7f2f59ddf12f8e8c1d97\" target=\"_blank\">Power BI Report</a></li>";
      
            lit_mainmenu.Text += "          </ul>";
            lit_mainmenu.Text += "    </li>";

            if (CaseAdmin)
            {
      
 

                lit_mainmenu.Text += "    <li><a href=\"#\">General Configuration</a>";
                lit_mainmenu.Text += "          <ul>";
              
                lit_mainmenu.Text += "            <li><a href=\"StartUp.html?page=PositionList.aspx\">Designation List</a></li>";
                lit_mainmenu.Text += "            <li><a href=\"StartUp.html?page=CaseStatusView.aspx\">Case Status List</a></li>";
                lit_mainmenu.Text += "            <li><a href=\"StartUp.html?page=ReferralTypeView.aspx\">Referral List</a></li>";
                lit_mainmenu.Text += "            <li><a href=\"StartUp.html?page=ServiceTypeView.aspx\">Service List</a></li>";
                lit_mainmenu.Text += "            <li><a href=\"StartUp.html?page=ProblemCategoryView.aspx\">Problem Category List</a></li>";
                lit_mainmenu.Text += "            <li><a href=\"StartUp.html?page=ProblemTypeView.aspx\">Problem Type List</a></li>";
                lit_mainmenu.Text += "          </ul>";
                lit_mainmenu.Text += "    </li>";
            }

            lit_mainmenu.Text += "</ul>";

        }
    }
}