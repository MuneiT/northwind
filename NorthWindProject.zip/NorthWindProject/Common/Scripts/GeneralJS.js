function gotoURL(url)
	{
		window.location=url;
}

function openURL(url) {
    window.open(url,'_blank');
}

function dropMenu(menuToDrop,state)
{
	document.getElementById(menuToDrop).style.display = state;
}

function ChangeClass(elementID, newClass) {
    if (window.document.getElementById(elementID) != null) {
        window.document.getElementById(elementID).className = newClass;
    }
}

function deleteEntry(param) {
    if (confirm("Are you sure you want to permanently delete that Staff?")) {
        gotoURL(param);
    }
}
	
function ShowHideDiv(elementID, state) {
    if (window.document.getElementById(elementID) != null) {
        if ((state == 'block') && (window.document.getElementById(elementID).style.display == 'block')) {
            window.document.getElementById(elementID).style.display = 'none';
        }
        else {
            window.document.getElementById(elementID).style.display = state;
        }
    }
}

//function ShowHideDiv(elementID, iframe) {
//    if (iframe != '') {
//        window.document.getElementById(iframe).src = "about:blank";
//    }

//    if (window.document.getElementById(elementID) != null) {
//        if (window.document.getElementById(elementID).style.display == "block") {
//            window.document.getElementById(elementID).style.display = "none";
//        }
//        else {
//            window.document.getElementById(elementID).style.display = "block";
//        }
//    }
//}


function OpenPopupDialog(popupDiv, popupIframe, popHeight, popWidth, url, newClass) {
    if (popupIframe != '') {
        window.document.getElementById(popupIframe).src = url;
        window.document.getElementById(popupIframe).style.width = popWidth + 'px';

        if (popHeight != 0) {
            window.document.getElementById(popupIframe).style.height = popHeight + 'px';
        }
        else {
            window.document.getElementById(popupIframe).onload = function () {
                setIFrameSizeFitToIt(popupIframe);
            }
        }
    }

    window.document.getElementById(popupDiv).className = newClass;
    window.document.getElementById(popupDiv).style.display = "block";

    CenterDiv(popupDiv);
}

function CenterDiv(popupDiv) {
    var newTop = -2000;
    var newLeft = -2000;

    window.document.getElementById(popupDiv).style.top = newTop + 'px';
    window.document.getElementById(popupDiv).style.left = newLeft + 'px';

    newTop = (document.body.parentNode.clientHeight / 2) - (window.document.getElementById(popupDiv).offsetHeight / 2) - 50;
    newLeft = (document.body.parentNode.clientWidth / 2) - (window.document.getElementById(popupDiv).offsetWidth / 2);

    if (newTop < 10) { newTop = 10; }
    if (newLeft < 10) { newLeft = 10; }

    window.document.getElementById(popupDiv).style.top = newTop + 'px';
    window.document.getElementById(popupDiv).style.left = newLeft + 'px';
}



function ShowHideContainer(elementID, iframe) {
    if (iframe != '') {
        window.document.getElementById(iframe).src = "about:blank";
    }

    if (window.document.getElementById(elementID) != null) {
        if (window.document.getElementById(elementID).style.display == "block") {
            window.document.getElementById(elementID).style.display = "none";
        }
        else {
            window.document.getElementById(elementID).style.display = "block";
        }
    }
}


function AlignDivCenter(popupDiv, minTop, minLeft) {
    if (window.document.getElementById(popupDiv) != null) {
        var newTop = -2000;
        var newLeft = -2000;

        window.document.getElementById(popupDiv).style.top = newTop + 'px';
        window.document.getElementById(popupDiv).style.left = newLeft + 'px';

        newTop = (document.body.parentNode.clientHeight / 2) - (window.document.getElementById(popupDiv).offsetHeight / 2) - 50;
        newLeft = (document.body.parentNode.clientWidth / 2) - (window.document.getElementById(popupDiv).offsetWidth / 2);

        if (newTop < minTop) { newTop = minTop; }
        if (newLeft < minLeft) { newLeft = minLeft; }

        if (document.body.parentNode.clientHeight < window.document.getElementById(popupDiv).offsetHeight || document.body.parentNode.clientWidth < window.document.getElementById(popupDiv).offsetWidth) {
            window.document.getElementById(popupDiv).style.position = 'absolute';
        }
        else {
            window.document.getElementById(popupDiv).style.position = 'fixed';
        }

        window.document.getElementById(popupDiv).style.top = newTop + 'px';
        window.document.getElementById(popupDiv).style.left = newLeft + 'px';
    }
}



function ShowHideAttachments(elementID) {
    switch (document.getElementById('div_attachments').style.display) {
        case "block":
            document.getElementById('div_attachments').style.display = "none";
            document.getElementById(elementID).innerHTML = "[ INSERT FILES ]";
            break;

        case "none":
            document.getElementById('div_attachments').style.display = "block";
            document.getElementById(elementID).innerHTML = "[ CLOSE LIST ]";
            break;
    }
}

function ShowHideStakeholders(elementID) {
    switch (document.getElementById('div_stakeholders').style.display) {
        case "block":
            document.getElementById('div_stakeholders').style.display = "none";
            document.getElementById(elementID).innerHTML = "[ EDIT LIST ]";
            break;

        case "none":
            document.getElementById('div_stakeholders').style.display = "block";
            document.getElementById(elementID).innerHTML = "[ CLOSE LIST ]";
            break;
    }
}

function ShowHideAttention() {
    switch (document.getElementById('div_attention').style.display) {
        case "block":
            document.getElementById('div_attention').style.display = "none";
            break;

        case "none":
            document.getElementById('div_attention').style.display = "block";
            break;
    }
}

function OpenAttention(url) {
    switch (document.getElementById('div_attention').style.display) {
        case "block":
            document.getElementById('div_attention').style.display = "none";
            document.getElementById('ifAttention').src = '';
            break;

        case "none":
            document.getElementById('div_attention').style.display = "block";
            document.getElementById('ifAttention').src = url;
            break;
    }
}
	


