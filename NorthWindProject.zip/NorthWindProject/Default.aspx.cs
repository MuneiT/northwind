﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeeHealthWellness.Proc;
using System.Configuration;

namespace EmployeeHealthWellness
{
    public partial class Default : System.Web.UI.Page
    {
        private int Id;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Gen.isSpecificType(Request.QueryString["id"], "int"))
            {
                Id = Convert.ToInt32(Request.QueryString["id"]);
            }

           
            Response.Redirect("CaseList.aspx?id=" + Id);            
        }
    }
}