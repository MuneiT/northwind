﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Web.UI.HtmlControls;
using System.Text;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Data;
using System.Configuration;
using EmployeeHealthWellness.Proc.DAL;
using EmployeeHealthWellness.Proc;


namespace EmployeeHealthWellness
{
    public partial class CaseList : System.Web.UI.Page
    {
        public int pageSize = 10;
        public int PageCurr = 0;
        public int OrderByType = 0;
        public string OrderBy = string.Empty;
        public string SearchBy = string.Empty;
        public string SearchText = string.Empty;
        public string StatusRec = string.Empty;
        public string selOrderBy = string.Empty;
        public string sortBy = string.Empty;
        public string sortByType = string.Empty;
        public string sortTemp = string.Empty;

        public string selGender = string.Empty;
        public string selDesignation = string.Empty;
        public string selPersal = string.Empty;
        public string selHLanguage = string.Empty;
        public string selFJUOfficial = string.Empty;

        public int PreProbId, IntakeId, DevPlanId, IncTypeId;

        public int PBenId;

        public string selIntakeNo = string.Empty;
        public string selOrderByType = string.Empty;


        public officerList thisList = null;

        public CultureInfo cultureInfo = new CultureInfo("en-ZA");


        protected void Page_Load(object sender, EventArgs e)
        {

            bool CaseAdmin = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["CaseAdmin"]);
            bool CaseManager = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["CaseManager"]);


            if(CaseManager)
            {
                hlCreateNew.Visible = false;
            }
          


            if (!string.IsNullOrEmpty(Request.QueryString["pg"]) && Gen.isSpecificType(Request.QueryString["pg"], "int"))
            {
                PageCurr = Convert.ToInt32(Request.QueryString["pg"]);
            }
            if (!string.IsNullOrEmpty(Request.QueryString["SearchBy"])) { SearchBy = Request.QueryString["SearchBy"].ToString(); ViewState["selectedSearchColumn"] = SearchBy; }
            if (!string.IsNullOrEmpty(Request.QueryString["SearchText"])) { SearchText = Request.QueryString["SearchText"].ToString(); ViewState["selectedSearchText"] = SearchText; }
            if (!string.IsNullOrEmpty(Request.QueryString["OrderBy"])) { OrderBy = Request.QueryString["OrderBy"].ToString(); ViewState["SelectedOrder"] = OrderBy; }
            if (!string.IsNullOrEmpty(Request.QueryString["OrderType"]) && Gen.isSpecificType(Request.QueryString["OrderType"], "int"))
            {
                OrderByType = Convert.ToInt32(Request.QueryString["OrderType"]);
                ViewState["SelectedOrderType"] = OrderByType;
            }

            if (!string.IsNullOrEmpty(Request.QueryString["selIntakeNo"]))
            {
                selIntakeNo = Request.QueryString["selIntakeNo"].ToString();
            }

            if (!string.IsNullOrEmpty(Request.QueryString["selGender"]))
            {
                selGender = Request.QueryString["selGender"].ToString();
            }

            if (!string.IsNullOrEmpty(Request.QueryString["selDesignation"]))
            {
                selDesignation = Request.QueryString["selDesignation"].ToString();
            }

            //if (!string.IsNullOrEmpty(Request.QueryString["selCountry"]))
            //{
            //    selCountry = Request.QueryString["selCountry"].ToString();
            //}

            //if (!string.IsNullOrEmpty(Request.QueryString["selHLanguage"]))
            //{
            //    selDesignation = Request.QueryString["selHLanguage"].ToString();
            //}

            //if (!string.IsNullOrEmpty(Request.QueryString["selFJUOfficial"]))
            //{
            //    selFJUOfficial = Request.QueryString["selFJUOfficial"].ToString();
            //}




            //this is the incident status
            if (!string.IsNullOrEmpty(Request.QueryString["Status"]))
            {
                StatusRec = Request.QueryString["Status"].ToString();
            }

            if (!Page.IsPostBack)
            {
                if (CaseAdmin)
                {
                    hlCreateNew.Attributes.Add("onclick", "gotoURL('OfficerAddEdit.aspx?new=true');");
                    hlCreateNew.Attributes.Add("style", "cursor:pointer;");
                }

                
                //PopulateSelectedFilterOptions();
                PopulateDropDownOptions();
                buildIntakeList(Navigation.None);

            }
        }

        private void buildIntakeList(Navigation navigation)
        {
            try
            {

 
                PagedDataSource pageData = new PagedDataSource();

         

                thisList = new OrderList(f_fromDate.Text, f_ToDate.Text, f_searchby.Text, f_searchby.Text);

                    pageData.DataSource = thisList.Listing;
                    pageData.AllowPaging = true;
                    pageData.PageSize = pageSize;




                switch (navigation)
                {
                    case Navigation.First:
                        NowViewing = 0;
                        break;
                    case Navigation.Next:
                        NowViewing++;
                        break;
                    case Navigation.Previous:
                        NowViewing--;
                        break;
                    case Navigation.Last:
                        NowViewing = pageData.PageCount - 1;
                        break;
                    case Navigation.Pager:
                        if (int.Parse(txtPage.Text) >= pageData.PageCount)
                            NowViewing = pageData.PageCount - 1;
                        break;
                    case Navigation.Sorting:
                        break;
                    default:
                        NowViewing = PageCurr;
                        break;
                }

                ViewState["SelectedPage"] = NowViewing;
                pageData.CurrentPageIndex = NowViewing;
                PageCurr = (int)ViewState["SelectedPage"];

                rptList.DataSource = pageData;
                rptList.DataBind();

                if (pageData.Count == 0)
                {
                    lblTotalPages.Text = "0";
                    txtPage.Text = "0";

                    btnNext.CssClass = "btn btn-primary btn-sm disabled";
                    btnPrev.CssClass = "btn btn-primary btn-sm disabled";
                    btnFirst.CssClass = "btn btn-primary btn-sm disabled";
                    btnLast.CssClass = "btn btn-primary btn-sm disabled";

                    dvRecords.Visible = false;
                    dvNoRecords.Visible = true;

                }
                else
                {


                    lblTotalPages.Text = pageData.PageCount.ToString();
                    txtPage.Text = (pageData.CurrentPageIndex + 1).ToString();
                    //lblIntakeCount.Text = thisList.Listing.Count.ToString();

                    pnlViewPrintable.Visible = true;
                    dvRecords.Visible = true;
                    dvNoRecords.Visible = false;

                    if (pageData.IsLastPage)
                    {
                        btnNext.Enabled = false;
                        btnNext.CssClass = "btn btn-primary btn-sm disabled";

                        btnLast.Enabled = false;
                        btnLast.CssClass = "btn btn-primary btn-sm disabled";
                    }
                    else
                    {
                        btnNext.Enabled = true;
                        btnNext.CssClass = "btn btn-primary btn-sm";

                        btnLast.Enabled = true;
                        btnLast.CssClass = "btn btn-primary btn-sm";
                    }

                    if (pageData.IsFirstPage)
                    {
                        btnFirst.Enabled = false;
                        btnFirst.CssClass = "btn btn-primary btn-sm disabled";

                        btnPrev.Enabled = false;
                        btnPrev.CssClass = "btn btn-primary btn-sm disabled";
                    }
                    else
                    {
                        btnPrev.Enabled = true;
                        btnPrev.CssClass = "btn btn-primary btn-sm";

                        btnFirst.Enabled = true;
                        btnFirst.CssClass = "btn btn-primary btn-sm";
                    }
                }

            }
            catch (Exception io)
            {
                Response.Write(io.Message.ToString());
            }
        }

        protected void rptList_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            bool CaseAdmin = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["CaseAdmin"]);
            bool CaseManager = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["CaseManager"]);


            if ((e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem))
            {
                Order item = (Order)e.Item.DataItem;

                HtmlGenericControl wrapList = new HtmlGenericControl("div");
                StringBuilder outStr = new StringBuilder();

                String rowClass = "", activityClass = "";
                rowClass = "txt_blue_cgothic_13"; activityClass = "txt_green_12";

                outStr.Append("  <tr class=\"" + rowClass + "\">");
                outStr.Append("      <td align=\"center\" valign=\"middle\"  bgcolor=\"#FFFFFF\">");
                outStr.Append("        <table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">");
                outStr.Append("	          <tr>");

                outStr.Append("		       <td width=\"50\" align=\"center\" valign=\"middle\" style=\"padding:0 1px 0 0;\" bgcolor=\"#FFFFFF\"><div id=\"btnEdit_" + item.Id + "\" style=\"width:50px;text-align:center;\" title=\"Edit\" class=\"btn btn-primary btn-sm\"           onmouseover=\"ChangeClass(this.id, 'btn btn-primary btn-sm')\" onmouseout=\"ChangeClass(this.id, 'btn btn-primary btn-sm')\" onclick=\"gotoURL('OfficerAddEdit.aspx?new=false&id=" + item.Id + "','PopUpBase PopPrimary');\"><span class=\"glyphicon glyphicon-edit\"></span>&nbspED</div></td>");
                       // outStr.Append("             <td width=\"15\" align=\"center\" valign=\"middle\" style=\"padding:0 1px 0 0;\" bgcolor=\"#FFFFFF\"><div id=\"btnCaseD_" + item.Id + "\" style=\"width:50px;text-align:center;\" title=\"Beneficiary Case Details\" class=\"btn btn-success btn-sm\" onmouseover=\"ChangeClass(this.id, 'btn btn-success btn-sm')\" onmouseout=\"ChangeClass(this.id, 'btn btn-success btn-sm')\" onclick=\"gotoURL('PreliminaryProblemEdit.aspx?IntakeId=" + item.Id + "&PreProbId=" + PreProbEntry.Id + "','PopUpBase PopPrimary');\"><span class=\"glyphicon glyphicon-edit\"></span>&nbspBN</div></td>");
                      //outStr.Append("             <td width=\"15\" align=\"center\" valign=\"middle\" style=\"padding:0 1px 0 0;\" bgcolor=\"#FFFFFF\"><div id=\"btnAR_" + item.Id + "\" style=\"width:50px;text-align:center;\" title=\"Assessment Report\" class=\"btn btn-info btn-sm\" onmouseover=\"ChangeClass(this.id, 'btn btn-info btn-sm')\" onmouseout=\"ChangeClass(this.id, 'btn btn-info btn-sm')\" onclick=\"gotoURL('IntakeReportEdit.aspx?IntakeId=" + item.Id + "','PopUpBase PopPrimary');\"><span class=\"glyphicon glyphicon-edit\"></span>&nbspAR</div></td>");
                       // outStr.Append("             <td width=\"15\" align=\"center\" valign=\"middle\" style=\"padding:0 1px 0 0;\" bgcolor=\"#FFFFFF\"><div id=\"btnNok_" + item.Id + "\" style=\"width:50px;text-align:center;\" title=\"Individual Development Plan\" class=\"btn btn-info btn-sm\" onmouseover=\"ChangeClass(this.id, 'btn btn-info btn-sm')\" onmouseout=\"ChangeClass(this.id, 'btn btn-info btn-sm')\" onclick=\"gotoURL('Lifeline_DevelopmentPlanEdit.aspx?IntakeId=" + item.Id + "&DevPlanId=" + DevPlanEntry.Id + "','PopUpBase PopPrimary');\"><span class=\"glyphicon glyphicon-edit\"></span>&nbspDP</div></td>");
                       // outStr.Append("             <td width=\"15\" align=\"center\" valign=\"middle\" style=\"padding:0 1px 0 0;\" bgcolor=\"#FFFFFF\"><div id=\"btnCP_" + item.Id + "\" style=\"width:50px;text-align:center;\" title=\"Care Plan\" class=\"btn btn-danger btn-sm\" onmouseover=\"ChangeClass(this.id, 'btn btn-danger btn-sm')\" onmouseout=\"ChangeClass(this.id, 'btn btn-danger btn-sm')\" onclick=\"gotoURL('Lifeline_CarePlanEdit.aspx?IntakeId=" + item.Id + "','PopUpBase PopPrimary');\"><span class=\"glyphicon glyphicon-edit\"></span>&nbspCP</div></td>");
                      //outStr.Append("		       <td width=\"50\" align=\"center\" valign=\"middle\" style=\"padding:0 1px 0 0;\" bgcolor=\"#FFFFFF\"><div id=\"btnFJU_" + item.Id + "\" style=\"width:50px;text-align:center;\" title=\"Family Justice\" class=\"btn btn-primary btn-sm\" onmouseover=\"ChangeClass(this.id, 'btn btn-primary btn-sm')\" onmouseout=\"ChangeClass(this.id, 'btn btn-primary btn-sm')\" onclick=\"gotoURL('FamJusticeEdit.aspx?IntakeId=" + item.Id + "','PopUpBase PopPrimary');\"><span class=\"glyphicon glyphicon-edit\"></span>&nbspFJ</div></td>");
                 //   outStr.Append("             <td width=\"21\" align=\"center\" valign=\"middle\" style=\"padding:0 1px 0 0;\" bgcolor=\"#FFFFFF\"><div id=\"btnATT_" + item.Id + "\" style=\"width:50px;text-align:center;\" title=\"Attach Documents\" class=\"btn btn-warning btn-sm\" onmouseover=\"ChangeClass(this.id, 'btn btn-warning btn-sm')\" onmouseout=\"ChangeClass(this.id, 'btn btn-warning btn-sm')\" onclick=\"OpenPopupDialog('divPopupDialog', 'ifOptions', 500, 500, 'Intake_Attachments.aspx?Id=" + item.Id + "&new=false','PopUpBase PopPrimary');\"><span class=\"glyphicon glyphicon-paperclip\"></span>&nbspATT</div></td>");

                    outStr.Append("           </tr>");
                    outStr.Append("         </table>");
                    outStr.Append("      </td>");
                    outStr.Append("      <td align=\"left\" class=\"datagridRow\" valign=\"middle\" bgcolor=\"#FFFFFF\"><strong>" + item.EmployeeFullname + "</strong></td>");
                    outStr.Append("      <td align=\"left\" class=\"datagridRow\" valign=\"middle\" bgcolor=\"#FFFFFF\"><strong>" + item.Name.ToUpper() + " " + item.Surname.ToUpper() + "</strong></td>");

                    outStr.Append("      <td align=\"left\" class=\"datagridRow\" valign=\"middle\" bgcolor=\"#FFFFFF\">" + item.CustomerID+ "</td>");
                    outStr.Append("      <td align=\"left\" class=\"datagridRow\" valign=\"middle\" bgcolor=\"#FFFFFF\">" + item.NumberOfOrder + "</td>");
                
                    outStr.Append("      <td align=\"left\" class=\"datagridRow\" valign=\"middle\" bgcolor=\"#FFFFFF\">" + item.Modifiedby.ToUpper() + " @ "+  item.ModifiedDate.ToString() + "</td>");
                    outStr.Append("      <td align=\"left\" class=\"datagridRow\" valign=\"middle\" bgcolor=\"#FFFFFF\">" + item.CreatedBy.ToUpper() + " @ " + item.Date.ToString() + "</td>");

                    outStr.Append("  </tr>");
                    wrapList.InnerHtml = outStr.ToString();
                    e.Item.Controls.Add(wrapList);
                
            }
        }

        protected void f_sections_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filter = drpSearchBy.SelectedValue;

            switch (filter)
            {
                case "":
                    pnlSearchBy.Visible = false;
                    this.pnlCaseStatus.Visible = false;
                    this.pnlIncidentType.Visible = false;
                    break;

                case "Status":
                    pnlSearchBy.Visible = false;
                    this.pnlCaseStatus.Visible = true;
                    this.pnlIncidentType.Visible = false;

                    break;

                case "type":
                    pnlSearchBy.Visible = false;
                    this.pnlCaseStatus.Visible = true;
                    this.drpCaseStatus.Visible = true;
                    break;

                case "RefNo":
                case "Name":
                case "Surname":
                    pnlSearchBy.Visible = true;
                    f_searchby.Attributes.Remove("readonly");
                    this.pnlCaseStatus.Visible = false;
                    this.pnlIncidentType.Visible = false;
                    break;
            }
        }

        protected void btnApplyFilter_Click(object sender, EventArgs e)
        {
            buildResultFilterOptions();

            List<string> ErrorMessage = new List<string>();

            try
            {
                StringBuilder searchParameters = new StringBuilder();
                searchParameters.Append("CaseList.aspx?&OrderBy=" + drpSortBy.SelectedValue + "&OrderType=" + rblOrderType.SelectedValue + "&selGender=" + selGender + "&selDesignation=" + selDesignation + "&selHLanguage=" + selHLanguage + "&selFJUOfficial=" + selFJUOfficial);

                if ((!string.IsNullOrEmpty(drpSearchBy.SelectedValue)) && (!string.IsNullOrEmpty(f_searchby.Text.Trim())))
                {
                    searchParameters.Append("&SearchBy=" + drpSearchBy.SelectedValue);
                    searchParameters.Append("&SearchText=" + f_searchby.Text.Trim().Replace("&", "[TTTTT]"));
                }
                else if (this.pnlCaseStatus.Visible == true)
                {
                    searchParameters.Append("&SearchBy=" + drpSearchBy.SelectedValue);
                    searchParameters.Append("&SearchText=" + this.drpCaseStatus.SelectedItem.Text.Replace("&", "[TTTTT]"));
                }
                else if (this.pnlIncidentType.Visible == true)
                {
                    searchParameters.Append("&SearchBy=" + drpSearchBy.SelectedValue);
                    searchParameters.Append("&SearchText=" + this.drpIncidentType.SelectedItem.Text.Replace("&", "[TTTTT]"));
                }




                Response.Redirect(searchParameters.ToString());

            }
            catch (AppExceptions ex)
            {
                string output = string.Empty;
                foreach (string msg in ex.ErrorMessage)
                {
                    output += msg + "<br />";
                }

              //  userMessageBox.showPopupMesage(output, "cau", "The following issues are preventing the process from completing successfully");
            }
        }

        protected void buildResultFilterOptions()
        {

            selGender = string.Empty;
            selDesignation = string.Empty;
;
            selHLanguage = string.Empty;
            selFJUOfficial = string.Empty;

           
             foreach (System.Web.UI.WebControls.ListItem item in chkIntakeGender.Items)
            {
                if (item.Selected)
                {
                    selGender += item.Value + ",";
                }
            }

            if (selGender.Length > 0) { selGender = selGender.Remove(selGender.Length - 1, 1); }



            //Selected Race
            foreach (System.Web.UI.WebControls.ListItem item in chkDesignation.Items)
            {
                if (item.Selected)
                {
                    selDesignation += item.Value + ",";
                }
            }

            if (selDesignation.Length > 0) { selDesignation = selDesignation.Remove(selDesignation.Length - 1, 1); }


            ////Selected Country
            //foreach (System.Web.UI.WebControls.ListItem item in chkIntakeCountry.Items)
            //{
            //    if (item.Selected)
            //    {
            //        selCountry += item.Value + ",";
            //    }
            //}

            //if (selCountry.Length > 0) { selCountry = selCountry.Remove(selCountry.Length - 1, 1); }

            ////Select Home Language
            //foreach (System.Web.UI.WebControls.ListItem item in chkIntakeHLanguage.Items)
            //{
            //    if (item.Selected)
            //    {
            //        selHLanguage += item.Value + ",";
            //    }
            //}

            //if (selHLanguage.Length > 0) { selHLanguage = selHLanguage.Remove(selHLanguage.Length - 1, 1); }



            ////Select Fam Just Official
            //foreach (System.Web.UI.WebControls.ListItem item in chkFJUOffical.Items)
            //{
            //    if (item.Selected)
            //    {
            //        selFJUOfficial += item.Value + ",";
            //    }
            //}

            //if (selFJUOfficial.Length > 0) { selFJUOfficial = selFJUOfficial.Remove(selFJUOfficial.Length - 1, 1); }

        }
 
        void PopulateSelectedFilterOptions()
        {

            //Pupulate Gender
            if (!string.IsNullOrEmpty(selGender))
            {
                string[] IntakeGenderList = selGender.Split(',');

                foreach (var itemValue in IntakeGenderList)
                {
                    System.Web.UI.WebControls.ListItem listItem = chkIntakeGender.Items.FindByValue(itemValue);
                    if (listItem != null) listItem.Selected = true;
                }
            }

            //Pupulate Race
            if (!string.IsNullOrEmpty(selDesignation))
            {
                string[] IntakeRaceList = selDesignation.Split(',');

                foreach (var itemValue in IntakeRaceList)
                {
                    System.Web.UI.WebControls.ListItem listItem = chkDesignation.Items.FindByValue(itemValue);
                    if (listItem != null) listItem.Selected = true;
                }
            }

           
            //Pupulate Country
            //if (!string.IsNullOrEmpty(selCountry))
            //{
            //    string[] IntakeCountryList = selCountry.Split(',');

            //    foreach (var itemValue in IntakeCountryList)
            //    {
            //        System.Web.UI.WebControls.ListItem listItem = chkIntakeCountry.Items.FindByValue(itemValue);
            //        if (listItem != null) listItem.Selected = true;
            //    }
            //}


            //Pupulate Home Language
            //if (!string.IsNullOrEmpty(selHLanguage))
            //{
            //    string[] HomeLanguageList = selHLanguage.Split(',');

            //    foreach (var itemValue in HomeLanguageList)
            //    {
            //        System.Web.UI.WebControls.ListItem listItem = this.chkIntakeHLanguage.Items.FindByValue(itemValue);
            //        if (listItem != null) listItem.Selected = true;
            //    }
            //}

            //Pupulate Fam Justice Official cases
            //if (!string.IsNullOrEmpty(selFJUOfficial))
            //{
            //    string[] OfficialList = selFJUOfficial.Split(',');

            //    foreach (var itemValue in OfficialList)
            //    {
            //        System.Web.UI.WebControls.ListItem listItem = this.chkFJUOffical.Items.FindByValue(itemValue);
            //        if (listItem != null) listItem.Selected = true;
            //    }
            //}
        }

        protected void btnClearFilter_Click(object sender, EventArgs e)
        {
            StringBuilder searchParameters = new StringBuilder();
            searchParameters.Append("StartUp.htm?page=CaseList.aspx");
            Response.Redirect(searchParameters.ToString());
        }

        protected void btnClearMoreFilter_Click(object sender, EventArgs e)
        {
            StringBuilder searchParameters = new StringBuilder();
            searchParameters.Append("StartUp.htm?page=CaseList.aspx");
            Response.Redirect(searchParameters.ToString());
        }


        //protected void btnExportToWord_Click(object sender, EventArgs e)
        //{
        //    buildIntakeList(Navigation.None);

        //    if (thisList.Listing.Count > 0)
        //    {
        //        DataTable dt = Gen.ConvertToDataTable(thisList.Listing);

        //        String fileName = "IkhayaLethemba_Report";
        //        HttpContext.Current.Response.Clear();
        //        HttpContext.Current.Response.Charset = "";

        //        HttpContext.Current.Response.ContentType = "application/doc";
        //        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName + "_" + DateTime.Now.ToString("dd-MM-yyyy") + ".doc");

        //        var strHTMLContent = new StringBuilder();

        //        strHTMLContent.Append("<h1 title='Heading' align='Center'style='font-family: verdana; font-size:16px;color: black'><u>Client Details</u> </h1> ");

        //        strHTMLContent.Append("<br>");
        //        strHTMLContent.Append("<table border='1' align='Center'>");

        //        // Row with Column headers
        //        strHTMLContent.Append("<tr>");
        //        strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>IKLT Ref No.</b></td>");
        //        strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>FIRSTNAME</b></td>");
        //        strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>SURNAME</b></td>");
        //        //strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>MOBILE</b></td>");
        //        strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>GENDER</b></td>");
        //        strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>COUNTRY</b></td>");
        //        strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>RACE</b></td>");
        //        strHTMLContent.Append("<td style='width:100px; background:# 99CC00'><b>INTAKE DATE</b></td>");
        //        strHTMLContent.Append(" </tr> ");

        //        foreach (var item in thisList.Listing)
        //        {
        //            // First Row Data
        //            strHTMLContent.Append("<tr>");
        //            strHTMLContent.Append("     <td style='width:100px'>" + item.iThembaRef + "</td>");
        //            strHTMLContent.Append("     <td style='width:100px'>" + item.ClientFirstName.ToUpper() + "</td>");
        //            strHTMLContent.Append("     <td style='width:100px'>" + item.ClientSurname.ToUpper() + "</td>");
        //            //strHTMLContent.Append("     <td style='width:100px'>" + item.ClientMobile + "</td>");
        //            strHTMLContent.Append("     <td style='width:100px'>" + Gen.GetIkhayaGender(item.ClientGender.ToString()).ToUpper() + "</td>");
        //            strHTMLContent.Append("     <td style='width:100px'>" + Gen.GetCountry(item.ClientCountry.ToString()).ToUpper() + "</td>");
        //            strHTMLContent.Append("     <td style='width:100px'>" + Gen.GetIkhayaRace(item.ClientRace.ToString()).ToUpper() + "</td>");
        //            strHTMLContent.Append("     <td style='width:100px'>" + item.ClientIntakeDate.ToString("yyyy-MM-dd") + "</td>");
        //            strHTMLContent.Append("</tr>");
        //        }

        //        strHTMLContent.Append("</table>");

        //        HttpContext.Current.Response.Write(strHTMLContent);
        //        HttpContext.Current.Response.End();
        //        HttpContext.Current.Response.Flush();

        //    }
        //}

        protected void printSchedule(string reqUrl, string idKey)
        {
            Gen.execOpenNewWindow(this, reqUrl, idKey);
        }

        //protected void btnExportToPDF_Click(object sender, EventArgs e)
        //{

        //    buildIntakeList(Navigation.None);

        //    if (thisList.Listing.Count > 0)
        //    {
        //        using (StringWriter sw = new StringWriter())
        //        {
        //            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
        //            {
        //                StringBuilder sb = new StringBuilder();

        //                //Header.
        //                sb.Append("<table width='100%' border='0' cellspacing='0' cellpadding='1'>");
        //                sb.Append("     <tr><td align='center'><img src=\"" + Server.MapPath("Common/Graphics/logo_gaut.png") + "\" width=\"160px\" height=\"60px\" alt=\"DCS\"/></td></tr>");
        //                sb.Append("</table>");
        //                sb.Append("<br />");

        //                String curUser = Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["name"] + " " + Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["surname"];
        //                String curDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

        //                sb.Append("<p align='right'> Official :" + curUser + "</p>");
        //                sb.Append("<p align='right'> Date :" + curDateTime + "</p>");
        //                sb.Append("<br />");

        //                sb.Append("<table width='100%' bordercolor='#CD5C5C' border='0.5' cellspacing='0' cellpadding='2'>");
        //                sb.Append("   <tr>");
        //                sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>IKLT Ref.No</strong></span></td>");
        //                sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>FIRST NAME</strong></span></td>");
        //                sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>SURNAME</strong></span></td>");
        //                //sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>MOBILE NUMBER</strong></span></td>");
        //                sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>GENDER</strong></span></td>");
        //                sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>COUNTRY</strong></span></td>");
        //                sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>RACE</strong></span></td>");
        //                sb.Append("     <td height='50px' bgcolor='#4682B4' align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 10px; color: #FFF; text-decoration: none;'><strong>INTAKE DATE</strong></span></td>");

        //                sb.Append("   </tr>");

        //                int count = 0;

        //                foreach (var item in thisList.Listing)
        //                {
        //                    count++;
        //                    sb.Append("   <tr>");
        //                    sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + item.iThembaRef + "</span></td>");
        //                    sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + item.ClientFirstName.ToUpper() + "</span></td>");
        //                    sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + item.ClientSurname.ToUpper() + "</span></td>");
        //                    //sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + item.ClientMobile + "</span></td>");
        //                    sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + Gen.GetIkhayaGender(item.ClientGender).ToUpper() + "</span></td>");
        //                    sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + Gen.GetCountry(item.ClientCountry).ToUpper() + "</span></td>");
        //                    sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + Gen.GetIkhayaRace(item.ClientRace).ToUpper() + "</span></td>");

        //                    if (item.ClientIntakeDate.Year != 1900)
        //                    {
        //                        sb.Append("     <td align='left'><span style='font-family: Arial, Helvetica, sans-serif; font-size: 8px; color: #000000; text-decoration: none;'>" + item.ClientIntakeDate.ToString("yyyy-MM-dd") + "</span></td>");

        //                    }
        //                    else
        //                    {
        //                        sb.Append("     <td align='left'></td>");
        //                    }


        //                    sb.Append("   </tr>");
        //                }



        //                sb.Append("</table>");

        //                StringReader sr = new StringReader(sb.ToString());

        //                Document pdfDoc = new Document(new Rectangle(288f, 144f), 10, 10, 10, 10);
        //                pdfDoc.SetPageSize(iTextSharp.text.PageSize.A4.Rotate());

        //                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        //                PdfWriter writer = PdfWriter.GetInstance(pdfDoc, Response.OutputStream);
        //                pdfDoc.Open();

        //                htmlparser.Parse(sr);
        //                pdfDoc.Close();
        //                Response.ContentType = "application/pdf";
        //                Response.AddHeader("content-disposition", "attachment;filename=IntakeList.pdf");
        //                Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //                Response.Write(pdfDoc);
        //                Response.End();
        //            }
        //        }
        //    }


        //}

        //protected void btnExportToExcel_Click(object sender, EventArgs e)
        //{

        //    buildIntakeList(Navigation.None);

        //    if (thisList.Listing.Count > 0)
        //    {
        //        String fileName = "Intake_Report";
        //        HttpContext.Current.Response.Clear();
        //        HttpContext.Current.Response.AddHeader("content-disposition", string.Format("attachment; filename={0}", fileName + ".xls"));
        //        HttpContext.Current.Response.ContentType = "application/ms-excel";

        //        using (StringWriter sw = new StringWriter())
        //        {
        //            using (HtmlTextWriter hw = new HtmlTextWriter(sw))
        //            {
        //                System.Web.UI.WebControls.Table table = new System.Web.UI.WebControls.Table();
        //                TableRow row = new TableRow();

        //                TableHeaderCell hcel0 = new TableHeaderCell();
        //                hcel0.Text = "INTAKE Ref No.";
        //                row.Cells.Add(hcel0);

        //                TableHeaderCell hceld = new TableHeaderCell();
        //                hceld.Text = "FIRST NAME";
        //                row.Cells.Add(hceld);

        //                TableHeaderCell hcell1 = new TableHeaderCell();
        //                hcell1.Text = "SURNAME";
        //                row.Cells.Add(hcell1);

        //                //TableHeaderCell hcel2 = new TableHeaderCell();
        //                //hcel2.Text = "MOBILE NO.";
        //                //row.Cells.Add(hcel2);

        //                TableHeaderCell hcel2 = new TableHeaderCell();
        //                hcel2.Text = "GENDER";
        //                row.Cells.Add(hcel2);

        //                TableHeaderCell hcel3 = new TableHeaderCell();
        //                hcel3.Text = "COUNTRY";
        //                row.Cells.Add(hcel3);


        //                TableHeaderCell hcel4 = new TableHeaderCell();
        //                hcel4.Text = "RACE";
        //                row.Cells.Add(hcel4);

        //                TableHeaderCell hce15 = new TableHeaderCell();
        //                hce15.Text = "INTAKE DATE";
        //                row.Cells.Add(hce15);

        //                table.Rows.Add(row);

        //                foreach (var item in thisList.Listing)
        //                {
        //                    TableRow row1 = new TableRow();

        //                    TableCell cellRefNum = new TableCell();
        //                    cellRefNum.Text = "" + item.iThembaRef;

        //                    TableCell cellFirstName = new TableCell();
        //                    cellFirstName.Text = "" + item.ClientFirstName;

        //                    TableCell cellSurname = new TableCell();
        //                    cellSurname.Text = "" + item.ClientSurname;

        //                    //TableCell cellMobile = new TableCell();
        //                    //cellMobile.Text = "" + item.ClientMobile;

        //                    TableCell cellGender = new TableCell();
        //                    cellGender.Text = "" + Gen.GetIkhayaGender(item.ClientGender).ToUpper();

        //                    TableCell cellCountry = new TableCell();
        //                    cellCountry.Text = "" + Gen.GetCountry(item.ClientCountry).ToUpper();

        //                    TableCell cellRace = new TableCell();
        //                    cellRace.Text = "" + Gen.GetIkhayaRace(item.ClientRace).ToString();

        //                    TableCell cellIntakeDate = new TableCell();
        //                    if (item.ClientIntakeDate.Year != 1900)
        //                    {
        //                        cellIntakeDate.Text = "" + item.ClientIntakeDate.ToString("yyyy/MM/dd");
        //                    }
        //                    else
        //                    {
        //                        cellIntakeDate.Text = "";
        //                    }


        //                    row1.Cells.Add(cellRefNum);
        //                    row1.Cells.Add(cellFirstName);
        //                    row1.Cells.Add(cellSurname);
        //                    //row1.Cells.Add(cellMobile);
        //                    row1.Cells.Add(cellGender);
        //                    row1.Cells.Add(cellCountry);
        //                    row1.Cells.Add(cellRace);
        //                    row1.Cells.Add(cellIntakeDate);

        //                    table.Rows.Add(row1);
        //                }

        //                table.RenderControl(hw);

        //                //  render the htmlwriter into the response
        //                HttpContext.Current.Response.Write(sw.ToString());
        //                HttpContext.Current.Response.End();
        //            }
        //        }
        //    }
        //}

        //protected void chkIntakeSelectAllGender_CheckedChanged(object sender, EventArgs e)
        //{
        //    foreach (System.Web.UI.WebControls.ListItem checkBox in chkIntakeGender.Items)
        //    {
        //        checkBox.Selected = chkIntakeSelectAllGender.Checked;
        //    }
        //}

        //protected void chkSelectAllIntakeRace_CheckedChanged(object sender, EventArgs e)
        //{
        //    foreach (System.Web.UI.WebControls.ListItem checkBox in chkIntakeRace.Items)
        //    {
        //        checkBox.Selected = chkSelectAllIntakeRace.Checked;
        //    }
        //}

        //protected void chkSelectAllIntakeCountry_CheckedChanged(object sender, EventArgs e)
        //{
        //    foreach (System.Web.UI.WebControls.ListItem checkBox in chkIntakeCountry.Items)
        //    {
        //        checkBox.Selected = chkSelectAllIntakeCountry.Checked;
        //    }
        //}

        //protected void chkSelectAllIntakeLanuage_CheckedChanged(object sender, EventArgs e)
        //{
        //    foreach (System.Web.UI.WebControls.ListItem checkBox in chkIntakeHLanguage.Items)
        //    {
        //        checkBox.Selected = chkSelectAllIntakeLanuage.Checked;
        //    }
        //}

        void PopulateDropDownOptions()
        {
            chkIntakeGender.DataSource = Gen.GetGenderList();
            chkIntakeGender.DataTextField = "Key";
            chkIntakeGender.DataValueField = "Value";
            chkIntakeGender.DataBind();
           


            DesignationList DesignationData = new DesignationList(true);
            chkDesignation.DataSource = DesignationData.Listing;
            chkDesignation.DataValueField = "Id";
            chkDesignation.DataTextField = "DesignationName";
            chkDesignation.DataBind();
            //chkDesignation.Items.Insert(0, new ListItem("Select Designation...", ""));

            //chkIntakeGender.DataSource = Gen.GetGenderList();
            //chkIntakeGender.DataTextField = "Key";
            //chkIntakeGender.DataValueField = "Value";
            //chkIntakeGender.DataBind();

            //chkIntakeRace.DataSource = Gen.GetRaceList();
            //chkIntakeRace.DataTextField = "Key";
            //chkIntakeRace.DataValueField = "Value";
            //chkIntakeRace.DataBind();

            //CountryList CountryData = new CountryList(true);
            //chkIntakeCountry.DataSource = CountryData.Listing;
            //chkIntakeCountry.DataTextField = "CountryName";
            //chkIntakeCountry.DataValueField = "CountryName";
            //chkIntakeCountry.DataBind();

            //chkIntakeHLanguage.DataSource = Gen.GetLanguageList();
            //chkIntakeHLanguage.DataTextField = "Key";
            //chkIntakeHLanguage.DataValueField = "Value";
            //chkIntakeHLanguage.DataBind();

            //OfficialList officialData = new OfficialList(true);
            //chkFJUOffical.DataSource = officialData.Listing;
            //chkFJUOffical.DataTextField = "OfficialFullName";
            //chkFJUOffical.DataValueField = "OfficialFullName";
            //chkFJUOffical.DataBind();

            //FamJustice_CaseStatusList familyData = new FamJustice_CaseStatusList(true);
            //drpCaseStatus.DataSource = familyData.Listing;
            //drpCaseStatus.DataTextField = "CaseStatus";
            //drpCaseStatus.DataValueField = "CaseStatus";
            //drpCaseStatus.DataBind();

            //IncidentTypeList IncidentTypeData = new IncidentTypeList(true);
            //drpIncidentType.DataSource = IncidentTypeData.Listing;
            //drpIncidentType.DataTextField = "IncidentType";
            //drpIncidentType.DataValueField = "IncidentType";
            //drpIncidentType.DataBind();


        }

        protected void btnPrev_Click(object sender, EventArgs e)
        {
            buildIntakeList(Navigation.Previous);
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            buildIntakeList(Navigation.Next);
        }

        protected void btnLast_Click(object sender, EventArgs e)
        {
            buildIntakeList(Navigation.Last);
        }

        protected void btnFirst_Click(object sender, EventArgs e)
        {
            buildIntakeList(Navigation.First);
        }

        public int NowViewing
        {
            get
            {
                object obj = ViewState["_NowViewing"];
                if (obj == null)
                    return 0;
                else
                    return (int)obj;
            }
            set
            {
                this.ViewState["_NowViewing"] = value;
            }
        }


    }
}
