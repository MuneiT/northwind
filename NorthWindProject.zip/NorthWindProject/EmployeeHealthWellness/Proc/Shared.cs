﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Reflection;
using System.Net.Mail;
using EmployeeHealthWellness.Proc.DAL;
using System.IO;
using System.Net;

namespace EmployeeHealthWellness.Proc
{
    public class Gen
    {
        public static void delCookie(string cookieName)
        {
            HttpCookie theCookie = HttpContext.Current.Request.Cookies[ConfigurationManager.AppSettings[cookieName]];

            if (theCookie != null)
            {
                theCookie.Expires = DateTime.Now.AddDays(-1);
                HttpContext.Current.Response.Cookies.Add(theCookie);
            }
        }

        public static String buildMessageImageUrl(String messageType)
        {
            String retStr = "";

            switch (messageType)
            {
                case "err":
                    retStr = "~/Common/Graphics/message_img/error.png";
                    break;

                case "info":
                    retStr = "~/Common/Graphics/message_img/info.png";
                    break;

                case "cau":
                    retStr = "~/Common/Graphics/message_img/warning.png";
                    break;

                default:
                    retStr = "~/Common/Graphics/message_img/error.png";
                    break;
            }

            return retStr;
        }
        public static String generateEHWPCaseRef(String Config_Type)
        {
            Data dataObj = new Data();
            dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();

            outStr.Append("SELECT Config_Value + 1 from tbl_Config WHERE Config_Type = '" + Config_Type + "' ");
            dataObj.SqlQuery.CommandText = outStr.ToString();
            string retValue = dataObj.SqlQuery.ExecuteScalar().ToString();

            outStr.Clear();
            outStr.Append("update tbl_Config set Config_Value = '" + retValue + "' WHERE Config_Type = '" + Config_Type + "' ");
            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection
            return "DCS" + DateTime.Now.ToString("yy") + "" + DateTime.Now.ToString("MM") + "" + retValue.PadLeft(4, '0');

            //return "INT" + DateTime.Now.ToString("yy") + DateTime.Now.ToString("MM") + retValue.PadLeft(3, '0'); ;
        }
        public static void execOpenNewWindow(Page page, string scriptBlock, string idKey)
        {
            ScriptManager.RegisterStartupScript(page, page.GetType(), idKey, scriptBlock, true);
        }

        public static String buildPageHeading(String heading)
        {
            String retStr = "";

            retStr += "<div class=\"txt_blue_10\"><strong>" + heading + "</strong></div>" + Environment.NewLine;

            return retStr;
        }
        public static Dictionary<string, string> GetGenderList()
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            dictionary.Add("MALE", "MALE");
            dictionary.Add("FEMALE", "FEMALE");
            //dictionary.Add("LGBT", 2);
            //dictionary.Add("LGBTI+", 3);

            return dictionary;
        }
        public static String makeSpace(int height, String bgCol, bool clear)
        {
            String spaceDiv = "";
            String clearVal = "none";
            if (clear == true)
            {
                clearVal = "both";
            }
            spaceDiv += "<div style=\"height:" + height + "px; background-color:" + bgCol + "; clear:" + clearVal + ";\"></div>";
            return spaceDiv;
        }

        public static void refreshParent(Control theControl, string page)
        {
            if (!string.IsNullOrEmpty(page))
            {
                ScriptManager.RegisterStartupScript(theControl, typeof(string), "script", "<script type=text/javascript> parent.location.href = '" + page + "';</script>", false);
            }
            else
            {
                ScriptManager.RegisterStartupScript(theControl, typeof(string), "script", "<script type=text/javascript> parent.location.href = parent.location.href;</script>", false);
            }
        }

        public static string GetCurrentPageName(String qString, bool useCurrentQuerystring)
        {
            String sRet;
            String sPath = System.Web.HttpContext.Current.Request.Url.AbsolutePath;
            System.IO.FileInfo oInfo = new System.IO.FileInfo(sPath);
            sRet = oInfo.Name;

            if (useCurrentQuerystring)
            {
                sRet += qString;
            }

            return sRet;
        }

        public static void buildYears(DropDownList dropField, int yearStart, int yearsTotal)
        {
            //int startYear = DateTime.Now.AddMonths(-1).Year;
            int startYear = DateTime.Now.AddYears(-yearStart).Year;

            for (int i = 0; i < yearsTotal; i++)
            {
                dropField.Items.Insert(i, new ListItem("" + (startYear + i).ToString() + "", "" + (startYear + i).ToString() + ""));
            }

            dropField.Items.Insert(0, new ListItem("", ""));
        }

        public static void buildMonths(DropDownList dropField)
        {
            for (int i = 0; i < 12; i++)
            {
                dropField.Items.Insert(i, new ListItem("" + Convert.ToDateTime(("1900-" + (i + 1).ToString() + "-01")).ToString("MMMM") + "", "" + (i + 1).ToString().PadLeft(2, '0') + ""));
            }

            dropField.Items.Insert(0, new ListItem("", ""));
        }

        public static void buildDays(DropDownList dropField)
        {
            for (int i = 0; i < 31; i++)
            {
                dropField.Items.Insert(i, new ListItem("" + (i + 1).ToString().PadLeft(2, '0') + "", "" + (i + 1).ToString().PadLeft(2, '0') + ""));
            }

            dropField.Items.Insert(0, new ListItem("", ""));
        }

        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }

        public static String buildAlphabetIndex(String curPage, String align)
        {
            String indexTable = "";
            String asciiChar;
            indexTable += " <table align=\"" + align + "\" border=\"0\" cellpadding=\"3\" cellspacing=\"1\" style=\"margin:0 auto;\">" + Environment.NewLine;
            indexTable += "     <tr class=\"txt_white_10\">" + Environment.NewLine;

            for (int i = 0; i < 26; i++)
            {
                asciiChar = Convert.ToChar(i + 65).ToString();

                indexTable += "         <td class=\"btn btn-primary btn-sm\" onclick=\"gotoURL('" + curPage + "?sel=" + asciiChar + "')\"><strong>" + asciiChar + "</strong></td>" + Environment.NewLine;
            }

            indexTable += "         <td class=\"btn btn-warning btn-sm\" onclick=\"gotoURL('" + curPage + "?sel=0-9')\"><strong>Other</strong></td>" + Environment.NewLine;

            indexTable += "     </tr>" + Environment.NewLine;
            indexTable += " </table>" + Environment.NewLine;

            return indexTable;
        }

        public static String buildGraphFrame(int type, Dictionary<string,int> GraphList, String GraphTitle)
        {
            String retStr = "";

            switch (type)
            {
                case 0: //BARCHART
                    retStr += "<div class=\"css_bar_graph\">";
                    retStr += "    <ul class=\"y_axis\"><li>170</li><li>130</li><li>110</li><li>70</li><li>30</li><li>10</li><li>0</li></ul>";

                    if (GraphList.Count > 0)
                    {
                        retStr += "    <ul class=\"x_axis\">";
                        foreach (var item in GraphList)
                        {
                            retStr += "    <li>" + item.Key.ToString() + "</li>";
                        }
                        retStr += "    </ul>";

                        retStr += "     <div class=\"graph\">";
                        retStr += "         <ul class=\"grid\"><li></li><li></li><li></li><li></li><li></li><li></li><li class=\"bottom\"></li></ul>";
                        
                        retStr += "            <ul>";
                        foreach (var item in GraphList)
                        {
                            retStr += "           <li class=\"bar nr_1 blue\" style=\"height:" + item.Value + "px;\"><div class=\"top\"></div><div class=\"bottom\"></div><span>" + item.Value + "</span></li>";
                        }
                        retStr += "            </ul>";

                        retStr += "     </div>";

                        retStr += "     <div class=\"label\"><span>" + GraphTitle + "</span></div>";
                    }

                    retStr += "</div>";
                    break;

                case 1: //PIECHART
                    break;
            }

            return retStr;
        }

        public static String buildFrame(int part, int width, int frameSize, string color)
        {
            String retStr = "";

            switch (part)
            {
                case 0:
                    retStr += "<table width=\"" + width + "\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
                    retStr += "    <tr>";
                    retStr += "	    <td width=\"" + frameSize + "\" height=\"" + frameSize + "\" style=\"background:url(External/Graphics/fade_top_left_" + frameSize + ".png) top left no-repeat;\"></td>";
                    retStr += "	    <td style=\"background:url(External/Graphics/fade_top_" + frameSize + ".png) top left repeat-x;\"></td>";
                    retStr += "	    <td width=\"" + frameSize + "\" height=\"" + frameSize + "\" style=\"background:url(External/Graphics/fade_top_right_" + frameSize + ".png) top left no-repeat;\"></td>";
                    retStr += "    </tr>";
                    retStr += "    <tr>";
                    retStr += "	    <td width=\"" + frameSize + "\" style=\"background:url(External/Graphics/fade_left_" + frameSize + ".png) top left repeat-y;\"></td>";
                    retStr += "	    <td style=\"padding:5px;\" bgcolor=\"" + color + "\">";
                    break;

                case 1:
                    retStr += "	    </td>";
                    retStr += "	    <td width=\"" + frameSize + "\" style=\"background:url(External/Graphics/fade_right_" + frameSize + ".png) top left repeat-y;\"></td>";
                    retStr += "    </tr>";
                    retStr += "    <tr>";
                    retStr += "	    <td width=\"" + frameSize + "\" height=\"" + frameSize + "\" style=\"background:url(External/Graphics/fade_bottom_left_" + frameSize + ".png) top left no-repeat;\"></td>";
                    retStr += "	    <td style=\"background:url(External/Graphics/fade_bottom_" + frameSize + ".png) top left repeat-x;\"></td>";
                    retStr += "	    <td width=\"" + frameSize + "\" height=\"" + frameSize + "\" style=\"background:url(External/Graphics/fade_bottom_right_" + frameSize + ".png) top left no-repeat;\"></td>";
                    retStr += "    </tr>";
                    retStr += "</table>";
                    break;
            }

            return retStr;
        }

        public static bool isSpecificType(String testValue, String testType)
        {
            bool returnVal = false;

            switch (testType)
            {
                case "int":
                    int out_INT;

                    if (int.TryParse(testValue, out out_INT))
                    {
                        returnVal = true;
                    }
                    break;

                case "double":
                    double out_DOUBLE;

                    if (double.TryParse(testValue, out out_DOUBLE))
                    {
                        returnVal = true;
                    }
                    break;

                case "long":
                    long out_LNG;

                    if (long.TryParse(testValue, out out_LNG))
                    {
                        returnVal = true;
                    }
                    break;

                case "bool":
                    bool out_BOOL;

                    if (bool.TryParse(testValue, out out_BOOL))
                    {
                        returnVal = true;
                    }
                    break;

                case "date":
                    DateTime out_DATE;
                    if (DateTime.TryParse(testValue, out out_DATE))
                    {
                        returnVal = true;
                    }
                    break;
            }

            return returnVal;
        }

        public static bool IsValidEmail(string strEmail)
        {
            Regex rgxEmail = new Regex(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                                       @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                                       @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$");
            return rgxEmail.IsMatch(strEmail);
        }

        public static String generateGUID()
        {
            return System.Guid.NewGuid().ToString();
        }

        public static String generateHelpDeskNumber(String Config_Type)
        {
            Data dataObj = new Data();
            dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();

            outStr.Append("SELECT Config_Value + 1 from tbl_Config WHERE Config_Type = '" + Config_Type + "' ");
            dataObj.SqlQuery.CommandText = outStr.ToString();
            string retValue = dataObj.SqlQuery.ExecuteScalar().ToString();

            outStr.Clear();
            outStr.Append("update tbl_Config set Config_Value = '" + retValue + "' WHERE Config_Type = '" + Config_Type + "' ");
            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection

            return "HD" + DateTime.Now.ToString("yyMM") + retValue.PadLeft(4, '0');
        }

        public static String getPriorityLevel(int Id)
        {
            Data dataObj = new Data();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();

            outStr.Append("SELECT IFNULL((SELECT PriorityDescription FROM hd_priority_levels WHERE Id = " + Id + "),'Undifined')");
            dataObj.SqlQuery.CommandText = outStr.ToString();
            string retValue = dataObj.SqlQuery.ExecuteScalar().ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Opend DB Connection

            return retValue;
        }

        public static String getTicketCategory(int Id)
        {
            Data dataObj = new Data();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();

            outStr.Append("SELECT IFNULL((SELECT CategoryName FROM hd_category WHERE Id = " + Id + "),'Undifined')");
            dataObj.SqlQuery.CommandText = outStr.ToString();
            string retValue = dataObj.SqlQuery.ExecuteScalar().ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Opend DB Connection

            return retValue;
        }

        public static String getPriorityClass(int pID)
        {
            String retStr = "";

            switch (pID)
            {
                case 1:
                    //retStr = "btnNORMAL";
                    retStr = "label label-default";
                    break;

                case 2:
                    //retStr = "btnMEDIUM";
                    retStr = "label label-primary";
                    break;

                case 3:
                    //retStr = "btnHIGH";
                    retStr = "label label-success";
                    break;

                case 4:
                    //retStr = "btnEMERGENCY";
                    retStr = "label label-info";
                    break;

                case 5:
                    //retStr = "btnURGENT";
                    retStr = "label label-warning";
                    break;

                case 6:
                    //retStr = "btnCRITICAL";
                    retStr = "label label-danger";
                    break;

                default:
                    //retStr = "btnNORMAL";
                    retStr = "label label-default";
                    break;
            }

            return retStr;
        }

        public static int getTurnAroundTime(int pID)
        {
            int retStr = 0;

            switch (pID)
            {
                case 1:
                case 2:
                    retStr = 120; //5 Days
                    break;

                case 3:
                    retStr = 48; //2 Days
                    break;

                case 4:
                case 5:
                case 6:
                    retStr = 8;
                    break;

                default:
                    retStr = 0;
                    break;
            }

            return retStr;
        }

        public static String getStatus(int pID)
        {
            String retStr = "";

            switch (pID)
            {
                case 0:
                    retStr = "Open";
                    break;

                case 1:
                    retStr = "In Progress";
                    break;

                case 2:
                    retStr = "Resolved";
                    break;

                case 3:
                    retStr = "Re-Assigned";
                    break;

                case 4:
                    retStr = "Closed";
                    break;

                case 5:
                    retStr = "Un-Resolved";
                    break;

                case 6:
                    retStr = "Re-Opened";
                    break;

                case 7:
                    retStr = "Trashed";
                    break;

                case 8:
                    retStr = "Escalated";
                    break;
            }

            return retStr;
        }

        public static String getStatusClass(int sID)
        {
            String retStr = "";

            switch (sID)
            {
                case 0:
                    retStr = "label label-info";
                    break;

                case 2:
                    retStr = "label label-warning";
                    break;

                case 1:
                case 3:
                case 6:
                    retStr = "label label-primary";
                    break;

                case 4:
                    retStr = "label label-success";
                    break;

                case 5:
                    retStr = "label label-warning";
                    break;

                case 8:
                    retStr = "label label-default";
                    break;

                case 7:
                    retStr = "label label-danger";
                    break;
            }

            return retStr;
        }

        public static String getCategoryType(int tID)
        {
            String retStr = "";

            switch (tID)
            {
                case 0:
                    retStr = "Issue";
                    break;

                case 1:
                    retStr = "Task";
                    break;

                case 2:
                    retStr = "Bug";
                    break;

                case 3:
                    retStr = "Lead";
                    break;

                case 4:
                    retStr = "Feedback";
                    break;

                case 5:
                    retStr = "Incident";
                    break;

                case 6:
                    retStr = "Problem";
                    break;
            }

            return retStr;
        }

        public static String getCategoryTypeClass(int tID)
        {
            String retStr = "";

            switch (tID)
            {
                case 0:
                    retStr = "label label-info";
                    break;

                case 1:
                case 4:
                    retStr = "label label-success";
                    break;

                case 2:
                    retStr = "label label-primary";
                    break;

                case 3:
                    retStr = "label label-default";
                    break;

                case 5:
                    retStr = "label label-warning";
                    break;

                case 6:
                    retStr = "label label-danger";
                    break;
            }

            return retStr;
        }

        public static String buildStatusImageUrl(int statusCode)
        {
            String retStr = "";

            switch (statusCode)
            {
                case 0:
                    retStr = "<img src=\"Common/Graphics/sideMenu/unassigned.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 1:
                    retStr = "<img src=\"Common/Graphics/sideMenu/inprogress.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 2:
                    retStr = "<img src=\"Common/Graphics/sideMenu/resolved.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 3:
                    retStr = "<img src=\"Common/Graphics/sideMenu/reassigned.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 4:
                    retStr = "<img src=\"Common/Graphics/sideMenu/closed.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 5:
                    retStr = "<img src=\"Common/Graphics/sideMenu/unresolved.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 6:
                    retStr = "<img src=\"Common/Graphics/sideMenu/reopened.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 7:
                    retStr = "<img src=\"Common/Graphics/sideMenu/trash.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                case 8:
                    retStr = "<img src=\"Common/Graphics/sideMenu/issue.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;

                default:
                    retStr = "<img src=\"Common/Graphics/Ticket/ticket.png\" height=\"15px\" width=\"15px\" alt=\"\" />";
                    break;
            }

            return retStr;
        }

        public static Dictionary<string, int> getCategoryTypeList()
        {
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            dictionary.Add("Issue", 0);
            dictionary.Add("Task", 1);
            dictionary.Add("Bug", 2);
            dictionary.Add("Lead", 3);
            dictionary.Add("Feedback", 4);
            dictionary.Add("Incident", 5);
            dictionary.Add("Problem", 6);
            return dictionary;
        }

        public static Dictionary<string, int> getPriorityList()
        {
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            //dictionary.Add("Undefined", 0);
            dictionary.Add("Normal", 1);
            dictionary.Add("Medium", 2);
            dictionary.Add("High", 3);
            dictionary.Add("Urgent", 4);
            dictionary.Add("Emergency", 5);
            dictionary.Add("Critical", 6);
            return dictionary;
        }

        public static Dictionary<string, int> getStatusList()
        {
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            dictionary.Add("Open", 0);
            dictionary.Add("In Progress", 1);
            dictionary.Add("Resolved", 2);      //If this status, check from History Table for Reporting
            dictionary.Add("Re-Assigned", 3);
            dictionary.Add("Closed", 4); 
            dictionary.Add("Un-Resolved", 5);
            dictionary.Add("Re-Opened", 6);
            dictionary.Add("Trashed", 7);
            dictionary.Add("Escalated", 8);
            return dictionary;
        }

        public static Dictionary<string, string> getTicketFilterList(bool UserRole)
        {
            Dictionary<string, string> dictionary = new Dictionary<string, string>();
            dictionary.Add("HD Number", "hd");

            if (UserRole)
            {
                dictionary.Add("Priority", "pl");
                dictionary.Add("Category", "cat");
                dictionary.Add("Status Code", "sci");
                dictionary.Add("Logged Date", "ld");
                dictionary.Add("Resolved Date", "rd");
                dictionary.Add("Closed Date", "cd");
                dictionary.Add("Ticket Type", "ti");
            }    
            
            return dictionary;
        }

        //public static void sendNotificationMessage(int TicketNo, String whoToNotify, string Message, bool isForSomeone, string LoggeByEmail, bool includeDevTeam, bool notification, string passedSubject)
        //{
        //    String HTMLTemplatePath = string.Empty, query = "", HTMLBody = "", Subject = "";
        //    MailMessage emailMsg = new MailMessage();
        //    SmtpClient smtp = new SmtpClient();
        //    Data dataObj = new Data();

        //    Subject = passedSubject;

        //    //String vEmail = Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"];

        //    MailAddress fromAddy = new MailAddress("IT.Helpdesk@gauteng.gov.za", "DCS IT HELPDESK");

        //    List<string> emailList = new List<string>();
        //    List<string> AppsDevTeamEmailList = new List<string>();

        //    if (!string.IsNullOrEmpty(TicketNo.ToString()) && Gen.isSpecificType(TicketNo.ToString(), "int"))
        //    {
        //        TicketItem thisNewTicket = new TicketItem(TicketNo);

        //        switch (whoToNotify)
        //        {
        //            case "requester":
        //                User thisRequester = new User(thisNewTicket.RequesterId);
        //                if (thisRequester.Id > 0)
        //                {
        //                    if (notification) //for only checking availability
        //                    {
        //                        //Subject = "[" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
        //                        HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/NotificationTemplets.htm");
        //                        HTMLBody = File.ReadAllText(HTMLTemplatePath);
        //                        HTMLBody = HTMLBody.Replace("[RequesterName]", thisRequester.Name);
        //                        HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
        //                        HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject + " " + thisNewTicket.ProblemDescription);
        //                        HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);
        //                        HTMLBody = HTMLBody.Replace("[Message]", Message);

        //                        if (thisNewTicket.CurrentSupportStaffId > 0)
        //                        {
        //                            User thisUser = new User(thisNewTicket.CurrentSupportStaffId);
        //                            HTMLBody = HTMLBody.Replace("[ReplyTo]", thisUser.Email);
        //                            fromAddy = new MailAddress(thisUser.Email, thisUser.FullName);
        //                        }
        //                    }
        //                    else
        //                    {
        //                        Subject = "[" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
        //                        HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/NewTicketTemplets.htm");
        //                        HTMLBody = File.ReadAllText(HTMLTemplatePath);
        //                        HTMLBody = HTMLBody.Replace("[RequesterName]", thisRequester.Name);
        //                        HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
        //                        HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));
        //                        HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject);
        //                        HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);

        //                    }

        //                    emailList.Add(thisRequester.Email);
        //                }

        //                break;
        //            case "itsupport":
        //                if (thisNewTicket.CurrentSupportStaffId > 0)
        //                {                            
        //                    Subject = "[" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
        //                    HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/AssignedTicketTemplets.htm");
        //                    HTMLBody = File.ReadAllText(HTMLTemplatePath);

        //                    if (!string.IsNullOrEmpty(Message))
        //                    {
        //                        HTMLBody = HTMLBody.Replace("[MESSAGE]", "<tr><td style=\"padding-top:20px; border-bottom:2px dotted #06F;\" class=\"txt_black_12\" colspan=\"2\">" + Message + "</td></tr>");
        //                    }
        //                    else
        //                    {
        //                        HTMLBody = HTMLBody.Replace("[MESSAGE]", "");
        //                    }

        //                    HTMLBody = HTMLBody.Replace("[TicketID]", thisNewTicket.HDTicketNo.ToString());
        //                    HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);

        //                    HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject.ToString());

        //                    User thisUser = new User(thisNewTicket.RequesterId); //Get Ticket Requester Info
        //                    HTMLBody = HTMLBody.Replace("[FullName]", thisUser.FullName);
        //                    HTMLBody = HTMLBody.Replace("[Email]", thisUser.Email);

        //                    HTMLBody = HTMLBody.Replace("[Creator]", thisUser.GetUserRole(thisNewTicket.LoggedById));
        //                    Region thisRegion = new Region(thisUser.RegionId);
        //                    HTMLBody = HTMLBody.Replace("[Region]", thisRegion.RegionName);

        //                    thisUser = new User(thisNewTicket.CurrentSupportStaffId); //Get Ticket IT Support Info
        //                    HTMLBody = HTMLBody.Replace("[SupportStaff]", thisUser.FullName);
        //                    HTMLBody = HTMLBody.Replace("[Priority]", getPriorityLevel(thisNewTicket.PriorityLevelId));
        //                    HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));

        //                    #region Get SLA
        //                    DateTime dueDate = new DateTime();
        //                    if (thisNewTicket.PriorityLevelId > 0)
        //                    {
        //                        int turnAroundTime = getTurnAroundTime(thisNewTicket.PriorityLevelId);
        //                        string strDspl = string.Empty;

        //                        if (turnAroundTime >= 24)
        //                        {
        //                            strDspl = "Default " + (turnAroundTime / 24).ToString() + " Day(s) Plan";
        //                            dueDate = thisNewTicket.LoggedDate.AddDays(turnAroundTime / 24);
        //                        }
        //                        else
        //                        {
        //                            strDspl = "Default " + turnAroundTime.ToString() + " Hour(s) Plan";
        //                            dueDate = thisNewTicket.LoggedDate.AddHours(turnAroundTime);
        //                        }

        //                        HTMLBody = HTMLBody.Replace("[SLA]", strDspl);
        //                    }
        //                    else
        //                    {
        //                        HTMLBody = HTMLBody.Replace("[SLA]", string.Empty);
        //                    }



        //                    if (dueDate.Year != 1 || dueDate.Year != 1900)
        //                    {
        //                        HTMLBody = HTMLBody.Replace("[Due]", dueDate.ToString("dd MMMM yyyy HH:mm"));
        //                    }

        //                    #endregion

        //                    HTMLBody = HTMLBody.Replace("[Created]", thisNewTicket.LoggedDate.ToString("dd MMMM yyyy HH:mm"));
        //                    HTMLBody = HTMLBody.Replace("[Updated]", thisNewTicket.ModifiedDate.ToString("dd MMMM yyyy HH:mm"));
                            

        //                    HTMLBody = HTMLBody.Replace("[Description]", thisNewTicket.ProblemDescription.ToString());
        //                    emailList.Add(thisUser.Email);
        //                }
        //                break;
        //            case "ithelpdesk":
        //                    Subject = getStatus(thisNewTicket.StatusCodeId) + " [" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
        //                    HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/UpdatedTicketTemplets.htm");
        //                    HTMLBody = File.ReadAllText(HTMLTemplatePath);

        //                    HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
        //                    HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);
        //                    HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject.ToString());
        //                    HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));
        //                    HTMLBody = HTMLBody.Replace("[StatusType]", getStatus(thisNewTicket.StatusCodeId));
                            
        //                    query += "select ";
        //                    query += "tUSE.Id as vUID, ";
        //                    query += "tUSE.Name as vNAME, ";
        //                    query += "tUSE.Surname as vSURNAME, ";
        //                    query += "tUSE.Email as vEMAIL ";
        //                    query += "from tbl_AppsUsers tUSE ";
        //                    query += "inner join tbl_AppGroups_Roles_Members tROL on tROL.AppUserId = tUSE.Id ";
        //                    query += "inner join tbl_AppGroups_Roles tGRO on tGRO.Id = tROL.AppRoleId ";
        //                    query += "where tUSE.Active = 1 "; 
        //                    query += "and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"] + " ";
        //                    query += "and tROL.AppRoleId = " + ConfigurationManager.AppSettings["AdminRoleId"];

        //                    #region Retrieve list of Recieptients
        //                        dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection

        //                        if (!string.IsNullOrEmpty(query))
        //                        {
        //                            dataObj.SqlQuery.CommandText = query;
        //                            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

        //                            if (dataObj.RecSet.HasRows)
        //                            {
        //                                while (dataObj.RecSet.Read())
        //                                {
        //                                    if (!string.IsNullOrEmpty(dataObj.RecSet["vEMAIL"].ToString()) && Gen.IsValidEmail(dataObj.RecSet["vEMAIL"].ToString()))
        //                                    {
        //                                        emailList.Add(dataObj.RecSet["vEMAIL"].ToString());
        //                                    }
        //                                }
        //                            }
        //                        }

        //                        dataObj.RecSet.Close();
        //                        dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection
        //                     #endregion

        //                    emailList.Distinct();
        //                break;

        //            case "helpdesk_managers":

        //                Subject = "[" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
        //                HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/TicketProblemTemplets.htm");
        //                HTMLBody = File.ReadAllText(HTMLTemplatePath);
        //                HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
        //                HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));
        //                HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject);
        //                HTMLBody = HTMLBody.Replace("[Type]", getCategoryType(thisNewTicket.TypeId));
        //                HTMLBody = HTMLBody.Replace("[Priority]", getPriorityLevel(thisNewTicket.PriorityLevelId));
        //                HTMLBody = HTMLBody.Replace("[ReportedDate]", thisNewTicket.LoggedDate.ToString("dd MMMM yyyy HH:mm"));
        //                HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);
                        
        //                User thisITSupportTeam = new User(thisNewTicket.CurrentSupportStaffId);
        //                HTMLBody = HTMLBody.Replace("[AssignedTo]", thisITSupportTeam.FullName);

        //                query += "select ";
        //                query += "tUSE.Id as vUID, ";
        //                query += "tUSE.Name as vNAME, ";
        //                query += "tUSE.Surname as vSURNAME, ";
        //                query += "tUSE.Email as vEMAIL ";
        //                query += "from tbl_AppsUsers tUSE ";
        //                query += "inner join tbl_AppGroups_Roles_Members tROL on tROL.AppUserId = tUSE.Id ";
        //                query += "inner join tbl_AppGroups_Roles tGRO on tGRO.Id = tROL.AppRoleId ";
        //                query += "where tUSE.Active = 1 "; 
        //                query += "and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"] + " ";
        //                query += "and tROL.AppRoleId = " + ConfigurationManager.AppSettings["HelpDeskManagers"];

        //                #region Retrieve list of Recieptients
        //                dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection

        //                if (!string.IsNullOrEmpty(query))
        //                {
        //                    dataObj.SqlQuery.CommandText = query;
        //                    dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

        //                    if (dataObj.RecSet.HasRows)
        //                    {
        //                        while (dataObj.RecSet.Read())
        //                        {
        //                            if (!string.IsNullOrEmpty(dataObj.RecSet["vEMAIL"].ToString()) && Gen.IsValidEmail(dataObj.RecSet["vEMAIL"].ToString()))
        //                            {
        //                                emailList.Add(dataObj.RecSet["vEMAIL"].ToString());
        //                            }
        //                        }
        //                    }
        //                }

        //                dataObj.RecSet.Close();
        //                dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection
        //                #endregion

        //                emailList.Distinct();
        //                break;
        //        }

        //        smtp.Host = ConfigurationManager.AppSettings["SMTPHost"];
                
        //        emailMsg.IsBodyHtml = true;
        //        emailMsg.From = fromAddy;
        //        //emailMsg.Subject = "DEV Environment : " + Subject;
        //        //emailMsg.Subject = "UAT Environment : " + Subject;
        //        emailMsg.Subject = Subject; // Production Environment
        //        emailMsg.Body = HTMLBody;
        //    }

        //    try
        //    {
        //        #region Include Application Development on the email

        //        if (includeDevTeam)
        //        {
        //            query += "select ";
        //            query += "tUSE.Id as vUID, ";
        //            query += "tUSE.Name as vNAME, ";
        //            query += "tUSE.Surname as vSURNAME, ";
        //            query += "tUSE.Email as vEMAIL ";
        //            query += "from tbl_AppsUsers tUSE ";
        //            query += "inner join tbl_AppGroups_Roles_Members tROL on tROL.AppUserId = tUSE.Id ";
        //            query += "inner join tbl_AppGroups_Roles tGRO on tGRO.Id = tROL.AppRoleId ";
        //            query += "where tUSE.Active = 1 ";
        //            query += "and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"] + " ";
        //            query += "and tROL.AppRoleId = " + ConfigurationManager.AppSettings["AppsDevTeamRoleId"];

        //            #region Retrieve list of Recieptients
        //            dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection

        //            if (!string.IsNullOrEmpty(query))
        //            {
        //                dataObj.SqlQuery.CommandText = query;
        //                dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

        //                if (dataObj.RecSet.HasRows)
        //                {
        //                    while (dataObj.RecSet.Read())
        //                    {
        //                        if (!string.IsNullOrEmpty(dataObj.RecSet["vEMAIL"].ToString()) && Gen.IsValidEmail(dataObj.RecSet["vEMAIL"].ToString()))
        //                        {
        //                            AppsDevTeamEmailList.Add(dataObj.RecSet["vEMAIL"].ToString());
        //                        }
        //                    }
        //                }
        //            }

        //            dataObj.RecSet.Close();
        //            dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection
        //            #endregion

        //            AppsDevTeamEmailList.Distinct();

        //            foreach (var devEmailItem in AppsDevTeamEmailList)
        //            {
        //                emailMsg.Bcc.Add(devEmailItem);
        //            }
        //        }
        //        #endregion

        //        if (string.IsNullOrEmpty(LoggeByEmail) && isForSomeone )
        //        {
        //            emailMsg.CC.Add(LoggeByEmail);
        //        }

        //        foreach (var emailItem in emailList)
        //        {
        //            emailMsg.To.Add(emailItem);
        //            smtp.Send(emailMsg);
        //            emailMsg.To.Clear();
        //        }
        //    }
        //    catch (System.Exception ex)
        //    {
                
        //    }


        //}

        public static void sendNotificationMessage(TicketParamsItem thisMessageParams)
        {
            String HTMLTemplatePath = string.Empty, query = "", HTMLBody = "", Subject = "";
            MailMessage emailMsg = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            Data dataObj = new Data();

            MailAddress fromAddy = new MailAddress("IT.Helpdesk@gauteng.gov.za", "DCS IT HELPDESK");

            List<string> emailList = new List<string>();
            List<string> AppsDevTeamEmailList = new List<string>();

            if (!string.IsNullOrEmpty(thisMessageParams.TicketId.ToString()) && Gen.isSpecificType(thisMessageParams.TicketId.ToString(), "int"))
            {
                TicketItem thisNewTicket = new TicketItem(thisMessageParams.TicketId);

                switch (thisMessageParams.Email_WhoToNotify)
                {
                    case "requester":
                        User thisRequester = new User(thisNewTicket.RequesterId);
                        if (thisRequester.Id > 0)
                        {
                            Subject = "[" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
                            HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/NewTicketTemplets.htm");
                            HTMLBody = File.ReadAllText(HTMLTemplatePath);
                            HTMLBody = HTMLBody.Replace("[RequesterName]", thisMessageParams.Email_sentToName);
                            HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
                            HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));
                            HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject);
                            HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);
                            emailList.Add(thisMessageParams.Email_sentToEmail);
                        }
                        break;

                    case "notification":
                        Subject = thisMessageParams.Email_Subject;
                        HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/NotificationTemplets.htm");
                        HTMLBody = File.ReadAllText(HTMLTemplatePath);
                        HTMLBody = HTMLBody.Replace("[RequesterName]", thisMessageParams.Email_sentToName);
                        HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
                        HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject + " " + thisNewTicket.ProblemDescription);
                        HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);
                        HTMLBody = HTMLBody.Replace("[Message]", thisMessageParams.Email_Message);
                        HTMLBody = HTMLBody.Replace("[Status]", thisMessageParams.TicketStatus);

                        if (!string.IsNullOrEmpty(thisMessageParams.Email_sentfromEmail))
                        {
                            fromAddy = new MailAddress(thisMessageParams.Email_sentfromEmail, thisMessageParams.Email_sentfromName);
                            emailMsg.CC.Add(thisMessageParams.Email_sentfromEmail);
                        }

                        emailList.Add(thisMessageParams.Email_sentToEmail);
                        break;

                    case "itsupport":
                        if (thisNewTicket.CurrentSupportStaffId > 0)
                        {
                            Subject = "[" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
                            HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/AssignedTicketTemplets.htm");
                            HTMLBody = File.ReadAllText(HTMLTemplatePath);

                            if (!string.IsNullOrEmpty(thisMessageParams.Email_Message))
                            {
                                HTMLBody = HTMLBody.Replace("[MESSAGE]", "<tr><td style=\"padding-top:20px; border-bottom:2px dotted #06F;\" class=\"txt_black_12\" colspan=\"2\">" + thisMessageParams.Email_Message + "</td></tr>");
                            }
                            else
                            {
                                HTMLBody = HTMLBody.Replace("[MESSAGE]", "");
                            }

                            HTMLBody = HTMLBody.Replace("[TicketID]", thisNewTicket.HDTicketNo.ToString());
                            HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);

                            HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject.ToString());

                            User thisUser = new User(thisNewTicket.RequesterId); //Get Ticket Requester Info
                            HTMLBody = HTMLBody.Replace("[FullName]", thisUser.FullName);
                            HTMLBody = HTMLBody.Replace("[Email]", thisUser.Email);

                            HTMLBody = HTMLBody.Replace("[Creator]", thisUser.GetUserRole(thisNewTicket.LoggedById));
                            Region thisRegion = new Region(thisUser.RegionId);
                            HTMLBody = HTMLBody.Replace("[Region]", thisRegion.RegionName);

                            thisUser = new User(thisNewTicket.CurrentSupportStaffId); //Get Ticket IT Support Info
                            HTMLBody = HTMLBody.Replace("[SupportStaff]", thisUser.FullName);
                            HTMLBody = HTMLBody.Replace("[Priority]", getPriorityLevel(thisNewTicket.PriorityLevelId));
                            HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));

                            #region Get SLA
                            DateTime dueDate = new DateTime();
                            if (thisNewTicket.PriorityLevelId > 0)
                            {
                                int turnAroundTime = getTurnAroundTime(thisNewTicket.PriorityLevelId);
                                string strDspl = string.Empty;

                                if (turnAroundTime >= 24)
                                {
                                    strDspl = "Default " + (turnAroundTime / 24).ToString() + " Day(s) Plan";
                                    dueDate = thisNewTicket.LoggedDate.AddDays(turnAroundTime / 24);
                                }
                                else
                                {
                                    strDspl = "Default " + turnAroundTime.ToString() + " Hour(s) Plan";
                                    dueDate = thisNewTicket.LoggedDate.AddHours(turnAroundTime);
                                }

                                HTMLBody = HTMLBody.Replace("[SLA]", strDspl);
                            }
                            else
                            {
                                HTMLBody = HTMLBody.Replace("[SLA]", string.Empty);
                            }



                            if (dueDate.Year != 1 || dueDate.Year != 1900)
                            {
                                HTMLBody = HTMLBody.Replace("[Due]", dueDate.ToString("dd MMMM yyyy HH:mm"));
                            }

                            #endregion

                            HTMLBody = HTMLBody.Replace("[Created]", thisNewTicket.LoggedDate.ToString("dd MMMM yyyy HH:mm"));
                            HTMLBody = HTMLBody.Replace("[Updated]", thisNewTicket.ModifiedDate.ToString("dd MMMM yyyy HH:mm"));


                            HTMLBody = HTMLBody.Replace("[Description]", thisNewTicket.ProblemDescription.ToString());
                            emailList.Add(thisUser.Email);
                        }
                        break;
                    case "ithelpdesk":
                        Subject = getStatus(thisNewTicket.StatusCodeId) + " [" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
                        HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/UpdatedTicketTemplets.htm");
                        HTMLBody = File.ReadAllText(HTMLTemplatePath);

                        HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
                        HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);
                        HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject.ToString());
                        HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));
                        HTMLBody = HTMLBody.Replace("[StatusType]", getStatus(thisNewTicket.StatusCodeId));

                        query += "select ";
                        query += "tUSE.Id as vUID, ";
                        query += "tUSE.Name as vNAME, ";
                        query += "tUSE.Surname as vSURNAME, ";
                        query += "tUSE.Email as vEMAIL ";
                        query += "from tbl_AppsUsers tUSE ";
                        query += "inner join tbl_AppGroups_Roles_Members tROL on tROL.AppUserId = tUSE.Id ";
                        query += "inner join tbl_AppGroups_Roles tGRO on tGRO.Id = tROL.AppRoleId ";
                        query += "where tUSE.Active = 1 ";
                        query += "and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"] + " ";
                        query += "and tROL.AppRoleId = " + ConfigurationManager.AppSettings["AdminRoleId"];

                        #region Retrieve list of Recieptients
                        dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection

                        if (!string.IsNullOrEmpty(query))
                        {
                            dataObj.SqlQuery.CommandText = query;
                            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

                            if (dataObj.RecSet.HasRows)
                            {
                                while (dataObj.RecSet.Read())
                                {
                                    if (!string.IsNullOrEmpty(dataObj.RecSet["vEMAIL"].ToString()) && Gen.IsValidEmail(dataObj.RecSet["vEMAIL"].ToString()))
                                    {
                                        emailList.Add(dataObj.RecSet["vEMAIL"].ToString());
                                    }
                                }
                            }
                        }

                        dataObj.RecSet.Close();
                        dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection
                        #endregion

                        emailList.Distinct();
                        break;

                    case "helpdesk_managers":

                        Subject = "[" + thisNewTicket.HDTicketNo + "]: " + thisNewTicket.ProblemSubject;
                        HTMLTemplatePath = HttpContext.Current.Server.MapPath("Common/Templetes/TicketProblemTemplets.htm");
                        HTMLBody = File.ReadAllText(HTMLTemplatePath);
                        HTMLBody = HTMLBody.Replace("[HDTicketNo]", thisNewTicket.HDTicketNo.ToString());
                        HTMLBody = HTMLBody.Replace("[Status]", getStatus(thisNewTicket.StatusCodeId));
                        HTMLBody = HTMLBody.Replace("[Subject]", thisNewTicket.ProblemSubject);
                        HTMLBody = HTMLBody.Replace("[Type]", getCategoryType(thisNewTicket.TypeId));
                        HTMLBody = HTMLBody.Replace("[Priority]", getPriorityLevel(thisNewTicket.PriorityLevelId));
                        HTMLBody = HTMLBody.Replace("[ReportedDate]", thisNewTicket.LoggedDate.ToString("dd MMMM yyyy HH:mm"));
                        HTMLBody = HTMLBody.Replace("[URL]", ConfigurationManager.AppSettings["DomainName"] + "/?id=" + thisNewTicket.Id);

                        User thisITSupportTeam = new User(thisNewTicket.CurrentSupportStaffId);
                        HTMLBody = HTMLBody.Replace("[AssignedTo]", thisITSupportTeam.FullName);

                        query += "select ";
                        query += "tUSE.Id as vUID, ";
                        query += "tUSE.Name as vNAME, ";
                        query += "tUSE.Surname as vSURNAME, ";
                        query += "tUSE.Email as vEMAIL ";
                        query += "from tbl_AppsUsers tUSE ";
                        query += "inner join tbl_AppGroups_Roles_Members tROL on tROL.AppUserId = tUSE.Id ";
                        query += "inner join tbl_AppGroups_Roles tGRO on tGRO.Id = tROL.AppRoleId ";
                        query += "where tUSE.Active = 1 ";
                        query += "and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"] + " ";
                        query += "and tROL.AppRoleId = " + ConfigurationManager.AppSettings["HelpDeskManagers"];

                        #region Retrieve list of Recieptients
                        dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection

                        if (!string.IsNullOrEmpty(query))
                        {
                            dataObj.SqlQuery.CommandText = query;
                            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

                            if (dataObj.RecSet.HasRows)
                            {
                                while (dataObj.RecSet.Read())
                                {
                                    if (!string.IsNullOrEmpty(dataObj.RecSet["vEMAIL"].ToString()) && Gen.IsValidEmail(dataObj.RecSet["vEMAIL"].ToString()))
                                    {
                                        emailList.Add(dataObj.RecSet["vEMAIL"].ToString());
                                    }
                                }
                            }
                        }

                        dataObj.RecSet.Close();
                        dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection
                        #endregion

                        emailList.Distinct();
                        break;
                }

                smtp.Host = ConfigurationManager.AppSettings["SMTPHost"];

                emailMsg.IsBodyHtml = true;
                emailMsg.From = fromAddy;
                emailMsg.Subject = Subject; // Production Environment
                emailMsg.Body = HTMLBody;
            }

            try
            {
                #region Include Application Development on the email

                if (thisMessageParams.Email_includeDevTeam)
                {
                    query += "select ";
                    query += "tUSE.Id as vUID, ";
                    query += "tUSE.Name as vNAME, ";
                    query += "tUSE.Surname as vSURNAME, ";
                    query += "tUSE.Email as vEMAIL ";
                    query += "from tbl_AppsUsers tUSE ";
                    query += "inner join tbl_AppGroups_Roles_Members tROL on tROL.AppUserId = tUSE.Id ";
                    query += "inner join tbl_AppGroups_Roles tGRO on tGRO.Id = tROL.AppRoleId ";
                    query += "where tUSE.Active = 1 ";
                    query += "and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"] + " ";
                    query += "and tROL.AppRoleId = " + ConfigurationManager.AppSettings["AppsDevTeamRoleId"];

                    #region Retrieve list of Recieptients
                    dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection

                    if (!string.IsNullOrEmpty(query))
                    {
                        dataObj.SqlQuery.CommandText = query;
                        dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

                        if (dataObj.RecSet.HasRows)
                        {
                            while (dataObj.RecSet.Read())
                            {
                                if (!string.IsNullOrEmpty(dataObj.RecSet["vEMAIL"].ToString()) && Gen.IsValidEmail(dataObj.RecSet["vEMAIL"].ToString()))
                                {
                                    AppsDevTeamEmailList.Add(dataObj.RecSet["vEMAIL"].ToString());
                                }
                            }
                        }
                    }

                    dataObj.RecSet.Close();
                    dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Opend DB Connection
                    #endregion

                    AppsDevTeamEmailList.Distinct();

                    foreach (var devEmailItem in AppsDevTeamEmailList)
                    {
                        emailMsg.Bcc.Add(devEmailItem);
                    }
                }
                #endregion

                if (string.IsNullOrEmpty(thisMessageParams.Email_LoggedByEmail) && thisMessageParams.Email_isForSomeone)
                {
                    emailMsg.CC.Add(thisMessageParams.Email_LoggedByEmail);
                }

                foreach (var emailItem in emailList)
                {
                    emailMsg.To.Add(emailItem);
                    smtp.Send(emailMsg);
                    emailMsg.To.Clear();
                }
            }
            catch (System.Exception ex)
            {

            }
        }


        public static string EncryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Encrypt(strQueryString, ConfigurationManager.AppSettings["SecurityKey"]);
        }

        private static string DecryptQueryString(string strQueryString)
        {
            EncryptDecryptQueryString objEDQueryString = new EncryptDecryptQueryString();
            return objEDQueryString.Decrypt(strQueryString, ConfigurationManager.AppSettings["SecurityKey"]);
        }

        public static void forceFileDownload(String filePath, String fileName)
        {
            FileStream fStream = new FileStream(@filePath + fileName, FileMode.Open, FileAccess.Read);
            byte[] byteBuffer = new byte[(int)fStream.Length];
            fStream.Read(byteBuffer, 0, (int)fStream.Length);
            fStream.Close();
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.ContentType = "application/octet-stream";
            HttpContext.Current.Response.AddHeader("Content-Length", byteBuffer.Length.ToString());
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=" + fileName);
            HttpContext.Current.Response.BinaryWrite(byteBuffer);
        }
    }
}