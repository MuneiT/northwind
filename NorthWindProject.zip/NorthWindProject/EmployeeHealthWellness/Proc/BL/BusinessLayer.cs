﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using EmployeeHealthWellness.Proc.DAL;

namespace EmployeeHealthWellness.Proc.BL
{
    public class EntriesBL
    {
        public static bool TicketInfo(String firstName, String Surname, String Email, String Tel, String OfficeNo, String Floor, String Region, String Directorate, String Division, String TicketTitle, String TicketDescription, String PersalNo, bool isForSomeone)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (isForSomeone)
            {
                if (string.IsNullOrEmpty(PersalNo))
                {
                    isValid = false;
                    ErrorMessage.Add("* Persal No cannot be empty");
                }
            }

            if (string.IsNullOrEmpty(TicketTitle))
            {
                isValid = false;
                ErrorMessage.Add("* Ticket subject cannot be empty");
            }

            if (string.IsNullOrEmpty(TicketDescription))
            {
                isValid = false;
                ErrorMessage.Add("* Ticket description cannot be empty");
            }

            if (string.IsNullOrEmpty(Region))
            {
                isValid = false;
                ErrorMessage.Add("* Region must be selected from dropdownlist.");
            }

            if (string.IsNullOrEmpty(Directorate))
            {
                isValid = false;
                ErrorMessage.Add("* Directorate must be selected from dropdownlist.");
            }

            if (string.IsNullOrEmpty(Division))
            {
                isValid = false;
                ErrorMessage.Add("* Division must be selected from dropdownlist.");
            }

            if (string.IsNullOrEmpty(firstName))
            {
                isValid = false;
                ErrorMessage.Add("* Firstname cannot be empty");
            }

            if (string.IsNullOrEmpty(Surname))
            {
                isValid = false;
                ErrorMessage.Add("* Surname cannot be empty");
            }

            if (string.IsNullOrEmpty(Email))
            {
                isValid = false;
                ErrorMessage.Add("* Email cannot be empty.");
            }
            else
            {
                if (!Gen.IsValidEmail(Email))
                {
                    isValid = false;
                    ErrorMessage.Add("* Email is not valid, please ensure you save correct email adress.");
                }
            }

            if (string.IsNullOrEmpty(Tel))
            {
                isValid = false;
                ErrorMessage.Add("* Telephone/Extention cannot be empty.");
            }

            if (string.IsNullOrEmpty(OfficeNo))
            {
                isValid = false;
                ErrorMessage.Add("* Office Number cannot be empty.");
            }

            if (string.IsNullOrEmpty(Floor))
            {
                isValid = false;
                ErrorMessage.Add("* Office Floor cannot be empty.");
            }

            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }

       
    
        public static bool ValidateCaseDetails(String ReportedDate,String ReferralType, String ServiceType, String ProblemCategory,String ProblemType, String CaseDescription)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (string.IsNullOrEmpty(ReportedDate))
            {
                isValid = false;
                ErrorMessage.Add("* Reported Date	cannot be empty");
            }

            if (string.IsNullOrEmpty(ReferralType))
                {
                    isValid = false;
                    ErrorMessage.Add("* Referral Type cannot be empty");
                }
            if (string.IsNullOrEmpty(ServiceType))
               {
                    isValid = false;
                    ErrorMessage.Add("* Service Type cannot be empty");
              }



            if (string.IsNullOrEmpty(ProblemCategory))
            {
                isValid = false;
                ErrorMessage.Add("* Problem Category cannot be empty");
            }

            if (string.IsNullOrEmpty(ProblemType))
            {
                isValid = false;
                ErrorMessage.Add("* Problem Type cannot be empty");
            }
            if (string.IsNullOrEmpty(CaseDescription))
            {
                isValid = false;
                ErrorMessage.Add("* Case Description No cannot be empty");
            }
           

            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }

        public static bool ValidateOfficer(String ClientType, String persal, String Name, String Surname, String Identity, String Gender, String Designation, String Region)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (string.IsNullOrEmpty(ClientType))
            {
                isValid = false;
                ErrorMessage.Add("* Type of Client	cannot be empty");
            }
            if (ClientType == "DCS Official")
            {
                if (string.IsNullOrEmpty(persal))
                {
                    isValid = false;
                    ErrorMessage.Add("* Persal No cannot be empty");
                }
                if (string.IsNullOrEmpty(Region))
                {
                    isValid = false;
                    ErrorMessage.Add("* Region No cannot be empty");
                }

            }

            if (string.IsNullOrEmpty(Name))
            {
                isValid = false;
                ErrorMessage.Add("* Name No cannot be empty");
            }
            if (string.IsNullOrEmpty(Surname))
            {
                isValid = false;
                ErrorMessage.Add("* Surname No cannot be empty");
            }
            if (string.IsNullOrEmpty(Identity))
            {
                isValid = false;
                ErrorMessage.Add("* ID number No cannot be empty");
            }
            if (string.IsNullOrEmpty(Gender))
            {
                isValid = false;
                ErrorMessage.Add("* Gender No cannot be empty");
            }
            if (string.IsNullOrEmpty(Designation))
            {
                isValid = false;
                ErrorMessage.Add("* Designation No cannot be empty");
            }

            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }
        public static bool TicketClientInfo(String priority, String category, String staffId, String status, String comments)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if ((string.IsNullOrEmpty(priority)) && (Convert.ToInt32(priority) <= 0))
            {
                isValid = false;
                ErrorMessage.Add("* Priority must be selected from dropdownlist.");
            }

            if ((string.IsNullOrEmpty(status)) && (Convert.ToInt32(status) <= 0))
            {
                isValid = false;
                ErrorMessage.Add("* Status must be selected from dropdownlist.");
            }

            if ((string.IsNullOrEmpty(category)) && (Convert.ToInt32(category) <= 0))
            {
                isValid = false;

                ErrorMessage.Add("* Category must be selected from dropdownlist.");
            }

            if ((string.IsNullOrEmpty(staffId)) && (Convert.ToInt32(staffId) <= 0))
            {
                isValid = false;
                ErrorMessage.Add("* Support Resource must be selected from dropdownlist.");
            }


            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }

        public static bool TicketITAgentInfo(String staffId, String status, String comments)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if ((string.IsNullOrEmpty(status)) && (Convert.ToInt32(status) <= 0))
            {
                isValid = false;
                ErrorMessage.Add("* Status must be selected from dropdownlist.");
            }

            if ((string.IsNullOrEmpty(staffId)) && (Convert.ToInt32(staffId) <= 0))
            {
                isValid = false;
                ErrorMessage.Add("* Support Resource must be selected from dropdownlist.");
            }


            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }

        public static bool validatePositon(String Position)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (string.IsNullOrEmpty(Position))
            {
                isValid = false;
                ErrorMessage.Add("* Position cannot be empty.");
            }
          
            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }
        public static bool validateReferralType(String Position)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (string.IsNullOrEmpty(Position))
            {
                isValid = false;
                ErrorMessage.Add("* Referral Type cannot be empty.");
            }

            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }

        public static bool ValidateUser(String PersalNo, String Name, String Surname, String Email, String MobiTel, String DirectorateName, String DivisionName, bool isNew, String Tel, String OfficeNo, String Floor, String Region)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (string.IsNullOrEmpty(PersalNo))
            {
                isValid = false;
                ErrorMessage.Add("* Persal Number cannot be empty.");
            }
            else
            {
                User thisUser = new User();
                thisUser.Ad = PersalNo;
                bool Exit = false;

                if (isNew)
                {
                    Exit = thisUser.CheckIfExist();
                }

                if (Exit)
                {
                    isValid = false;
                    ErrorMessage.Add("* Systems User with Persal Number " + PersalNo + " already exist.");
                }
            }

            if (string.IsNullOrEmpty(Name))
            {
                isValid = false;
                ErrorMessage.Add("* Staff Name cannot be empty.");
            }

            if (string.IsNullOrEmpty(Surname))
            {
                isValid = false;
                ErrorMessage.Add("* Staff Surname cannot be empty.");
            }

            if (string.IsNullOrEmpty(Email))
            {
                isValid = false;
                ErrorMessage.Add("* Staff Email cannot be empty.");
            }
            else
            {
                if (!Gen.IsValidEmail(Email))
                {
                    isValid = false;
                    ErrorMessage.Add("* Staff Email is invalid.");
                }
            }

            if (string.IsNullOrEmpty(Tel))
            {
                isValid = false;
                ErrorMessage.Add("* Staff Tellephone cannot be empty.");
            }

            if (string.IsNullOrEmpty(DirectorateName))
            {
                isValid = false;
                ErrorMessage.Add("* Directorate cannot be empty.");
            }

            if (string.IsNullOrEmpty(DivisionName))
            {
                isValid = false;
                ErrorMessage.Add("* Division Description cannot be empty.");
            }

            if (string.IsNullOrEmpty(Region))
            {
                isValid = false;
                ErrorMessage.Add("* Region cannot be empty.");
            }

            if (string.IsNullOrEmpty(OfficeNo))
            {
                isValid = false;
                ErrorMessage.Add("* Office Number cannot be empty.");
            }

            if (string.IsNullOrEmpty(Floor))
            {
                isValid = false;
                ErrorMessage.Add("* Floor Number cannot be empty.");
            }

            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }

        public static bool TicketComments(String Comment)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (string.IsNullOrEmpty(Comment))
            {
                isValid = false;
                ErrorMessage.Add("* Ticket Comment cannot be empty.");
            }

            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }



        public static bool TicketAvailabilityCheck(String Message)
        {
            bool isValid = true;
            List<string> ErrorMessage = new List<string>();

            if (string.IsNullOrEmpty(Message))
            {
                isValid = false;
                ErrorMessage.Add("* Availability check message cannot be empty.");
            }

            if (!isValid)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return isValid;
        }
    
    }
}