﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using EmployeeHealthWellness.Proc;


    public class Directorate
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public String DirectorateName { get; set; }
        public String Guid { get; set; }
        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public int Active { get; set; }

        public List<Division> DivisionList
        {
            get { return new DivisionList(this.Id, false).Listing; }
            set { }
        }

        public Directorate() { }

        public Directorate(int DirectorateID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.DirectorateBaseSelect);
            outStr.Append(" AND Id = " + DirectorateID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.DirectorateName = dataObj.RecSet["DirectorateName"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["Modifiedby"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLData.DirectorateBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.DirectorateName + "',");
                outStr.Append("'" + this.Active + "',");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_Directorate Set ");
                outStr.Append("DirectorateName = '" + this.DirectorateName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            if (isNew)
            {
                outStr.Clear();
                outStr.Append("select id from tbl_Directorate where Guid='" + this.Guid + "'");
                dataObj.SqlQuery.CommandText = outStr.ToString();
                retValue = dataObj.SqlQuery.ExecuteScalar().ToString();
            }

            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            return retValue;

        }
    }

    public class DirectorateList
    {
        Data dataObj = new Data();
        public List<Directorate> Listing { get; set; }
        public DirectorateList(bool showOnlyActive)
        {
            Listing = new List<Directorate>();
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.DirectorateBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            outStr.Append("order by DirectorateName");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    Directorate item = new Directorate();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.DirectorateName = dataObj.RecSet["DirectorateName"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["Modifiedby"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
        }
    }
