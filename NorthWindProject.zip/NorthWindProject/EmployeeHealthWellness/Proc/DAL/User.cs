﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Configuration;

namespace EmployeeHealthWellness.Proc.DAL
{
    public class User
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public String Ad { get; set; }
        public String AdminAcct { get; set; }
        public String FullName { get; set; }
        public String Name { get; set; }
        public String Surname { get; set; }
        public String Email { get; set; }
        public String Mobile_Phone { get; set; }
        public int Active { get; set; }
        public int Deleted { get; set; }
        public DateTime Created { get; set; }
        public String CreatedBy { get; set; }
        public DateTime Modified { get; set; }
        public String Modifiedby { get; set; }
        public DateTime LastSession { get; set; }
        public int SessionCount { get; set; }
        public String Guid { get; set; }
        public int DirectorateId { get; set; }
        public int DivisionId { get; set; }
        public int RegionId { get; set; }
        public String Floor { get; set; }
        public String OfficeNo { get; set; }
        public String Telephone { get; set; }
        public User() { }

        public User(int userID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.UserBaseSelect);
            outStr.Append("AND Id=" + userID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["vID"]);
                    this.Ad = dataObj.RecSet["vADNAME"].ToString();
                    this.AdminAcct = dataObj.RecSet["vADMINACC"].ToString();
                    this.Name = dataObj.RecSet["vNAME"].ToString();
                    this.Surname = dataObj.RecSet["vSURNAME"].ToString();
                    this.FullName = dataObj.RecSet["vNAME"].ToString() + " " + dataObj.RecSet["vSURNAME"].ToString();
                    this.Email = dataObj.RecSet["vEMAIL"].ToString();
                    this.Mobile_Phone = dataObj.RecSet["vPHONE"].ToString();
                    this.Active = Convert.ToInt32(dataObj.RecSet["vACTIVE"]);
                    this.Deleted = Convert.ToInt32(dataObj.RecSet["vDELETED"]);
                    this.Created = Convert.ToDateTime(dataObj.RecSet["vCREATEDDATE"]);
                    this.Modified = Convert.ToDateTime(dataObj.RecSet["vMODIFIEDDATE"]);
                    this.CreatedBy = dataObj.RecSet["vCREATEDBY"].ToString();
                    this.Modifiedby = dataObj.RecSet["vMODIFIEDBY"].ToString();
                    this.SessionCount = Convert.ToInt32(dataObj.RecSet["vSESSIONCOUNT"]);
                    this.LastSession = Convert.ToDateTime(dataObj.RecSet["vLASTSESSION"]);
                    this.DirectorateId = Convert.ToInt32(dataObj.RecSet["vDIRECORATE"]);
                    this.DivisionId = Convert.ToInt32(dataObj.RecSet["vDIVISION"]);
                    this.RegionId = Convert.ToInt32(dataObj.RecSet["vREGIONID"]);
                    this.Telephone = dataObj.RecSet["vTEL"].ToString();
                    this.Floor = dataObj.RecSet["vFLOOR"].ToString();
                    this.OfficeNo = dataObj.RecSet["vOFFICENO"].ToString();
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
        }

        public User(String persalNo)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.UserBaseSelect);
            outStr.Append(" AND Ad_Name= '" + persalNo + "'");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["vID"]);
                    this.Ad = dataObj.RecSet["vADNAME"].ToString();
                    this.AdminAcct = dataObj.RecSet["vADMINACC"].ToString();
                    this.Name = dataObj.RecSet["vNAME"].ToString();
                    this.Surname = dataObj.RecSet["vSURNAME"].ToString();
                    this.FullName = dataObj.RecSet["vNAME"].ToString() + " " + dataObj.RecSet["vSURNAME"].ToString();
                    this.Email = dataObj.RecSet["vEMAIL"].ToString();
                    this.Mobile_Phone = dataObj.RecSet["vPHONE"].ToString();
                    this.Active = Convert.ToInt32(dataObj.RecSet["vACTIVE"]);
                    this.Deleted = Convert.ToInt32(dataObj.RecSet["vDELETED"]);
                    this.Created = Convert.ToDateTime(dataObj.RecSet["vCREATEDDATE"]);
                    this.Modified = Convert.ToDateTime(dataObj.RecSet["vMODIFIEDDATE"]);
                    this.CreatedBy = dataObj.RecSet["vCREATEDBY"].ToString();
                    this.Modifiedby = dataObj.RecSet["vMODIFIEDBY"].ToString();
                    this.SessionCount = Convert.ToInt32(dataObj.RecSet["vSESSIONCOUNT"]);
                    this.LastSession = Convert.ToDateTime(dataObj.RecSet["vLASTSESSION"]);
                    this.DirectorateId = Convert.ToInt32(dataObj.RecSet["vDIRECORATE"]);
                    this.DivisionId = Convert.ToInt32(dataObj.RecSet["vDIVISION"]);
                    this.RegionId = Convert.ToInt32(dataObj.RecSet["vREGIONID"]);
                    this.Telephone = dataObj.RecSet["vTEL"].ToString();
                    this.Floor = dataObj.RecSet["vFLOOR"].ToString();
                    this.OfficeNo = dataObj.RecSet["vOFFICENO"].ToString();
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);
        }

        public bool CheckIfExist() //checking if official record exist
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.Ad))
            {
                outStr.Append("select * from tbl_AppsUsers WHERE ('x'='x') ");
                outStr.Append("  and (Ad_Name ='" + this.Ad + "') ");
                dataObj.SqlQuery.CommandText = outStr.ToString();
                dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();
            }

            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            return AlreadyExist;
        }

        public int CommitUserChanges(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();

            if (isNew)
            {
                outStr.Clear();
                outStr.Append("Insert Into tbl_AppsUsers (Ad_Name, Admin_Acc,Name,Surname,Email,Mobile,Active,Deleted,CreatedBy,ModifiedBy,CreatedDate,ModifiedDate, Guid, DirectorateId, DivisionId, RegionId, OfficeNo, Telephone,Floor) ");
                outStr.Append("values (");
                outStr.Append("'" + this.Ad + "','" + this.AdminAcct + "','" + this.Name + "','" + this.Surname + "','" + this.Email + "','" + this.Mobile_Phone + "',");
                outStr.Append("'" + Convert.ToInt32(this.Active) + "',");
                outStr.Append("'" + Convert.ToInt32(this.Deleted) + "',");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.Created.ToString("yyyy-MM-dd HH:mm:ss") + "',");
                outStr.Append("'" + this.Modified.ToString("yyyy-MM-dd HH:mm:ss") + "',");
                outStr.Append("'" + this.Guid + "',");
                outStr.Append("'" + Convert.ToInt32(this.DirectorateId) + "',");
                outStr.Append("'" + Convert.ToInt32(this.DivisionId) + "',");
                outStr.Append("'" + Convert.ToInt32(this.RegionId) + "',");
                outStr.Append("'" + this.OfficeNo + "',");
                outStr.Append("'" + this.Telephone + "',");
                outStr.Append("'" + this.Floor + "' ");
                outStr.Append(")");
            }
            else
            {
                outStr.Clear();
                outStr.Append("Update tbl_AppsUsers Set ");
                //outStr.Append("Ad_Name = '" + this.Ad + "', ");
                outStr.Append("Name = '" + this.Name + "', ");
                outStr.Append("Surname = '" + this.Surname + "', ");
                outStr.Append("Email = '" + this.Email + "', ");
                outStr.Append("Mobile = '" + this.Mobile_Phone + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.Modified.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("Active = '" + Convert.ToInt32(this.Active) + "', ");
                outStr.Append("Deleted = '" + Convert.ToInt32(this.Deleted) + "', ");
                outStr.Append("DirectorateId = '" + Convert.ToInt32(this.DirectorateId) + "', ");
                outStr.Append("DivisionId = '" + Convert.ToInt32(this.DivisionId) + "', ");
                outStr.Append("OfficeNo = '" + this.OfficeNo + "', ");
                outStr.Append("Floor = '" + this.Floor + "', ");
                outStr.Append("Telephone = '" + this.Telephone + "', ");
                outStr.Append("RegionId = '" + Convert.ToInt32(this.RegionId) + "' ");
                outStr.Append("where Id=" + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            int retValue = this.Id;

            if (isNew)
            {
                outStr.Clear();
                outStr.Append("select Id as newID from tbl_AppsUsers where Guid='" + this.Guid + "'");
                dataObj.SqlQuery.CommandText = outStr.ToString();
                retValue = (int)dataObj.SqlQuery.ExecuteScalar();
            }

            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            return retValue;
        }

        public string GetUserRole(int UserId)
        {
            dataObj.SetDbConn(1, dataObj.dbConnSysMan);

            StringBuilder outStr = new StringBuilder();
            String query;

            query = "";
            query += "select ";
            query += "tUSE.Id as vUID, ";

            query += "tROL.AppRoleId as vROLEID, ";
            query += "tGRO.RoleName as vROLE ";

            query += "from tbl_AppsUsers tUSE ";
            query += "inner join tbl_AppGroups_Roles_Members tROL on tROL.AppUserId = tUSE.Id ";
            query += "inner join tbl_AppGroups_Roles tGRO on tGRO.Id = tROL.AppRoleId ";

            query += "where tUSE.Id ='" + UserId + "' ";
            query += "and tROL.AppGroupId = " + ConfigurationManager.AppSettings["ApplicationIdentity"];

            dataObj.SqlQuery.CommandText = query;
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            String RoleName = string.Empty;

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    switch (Convert.ToInt32(dataObj.RecSet["vROLEID"].ToString()))
                    {
                        case 14: RoleName = "HelpDesk Agent"; break; // Administrator Account
                        case 15: RoleName = "IT Support Agent"; break; //Support Account
                    }
                }
            }
            else
            {
                RoleName = "System User";
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnSysMan);

            return RoleName;
        }

    }

    public class UserList
    {
        Data DataObj = new Data();
        public List<User> Listing { get; set; }

        public UserList(bool showOnlyActive)
        {
            Listing = new List<User>();
            DataObj.SetDbConn(1, DataObj.dbConnSysMan);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.UserBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" and active = 1 ");
            }

            outStr.Append(" order by Name");

            DataObj.SqlQuery.CommandText = outStr.ToString();
            DataObj.RecSet = DataObj.SqlQuery.ExecuteReader();

            if (DataObj.RecSet.HasRows)
            {
                while (DataObj.RecSet.Read())
                {
                    User item = new User();
                    item.Id = Convert.ToInt32(DataObj.RecSet["vID"]);
                    item.Ad = DataObj.RecSet["vADNAME"].ToString();
                    item.Name = DataObj.RecSet["vNAME"].ToString();
                    item.Surname = DataObj.RecSet["vSURNAME"].ToString();
                    item.FullName = DataObj.RecSet["vNAME"].ToString() + " " + DataObj.RecSet["vSURNAME"].ToString();
                    item.Email = DataObj.RecSet["vEMAIL"].ToString();
                    item.Mobile_Phone = DataObj.RecSet["vPHONE"].ToString();
                    item.Active = Convert.ToInt32(DataObj.RecSet["vACTIVE"]);
                    item.Deleted = Convert.ToInt32(DataObj.RecSet["vDELETED"]);
                    item.Created = Convert.ToDateTime(DataObj.RecSet["vCREATEDDATE"]);
                    item.Modified = Convert.ToDateTime(DataObj.RecSet["vMODIFIEDDATE"]);
                    item.CreatedBy = DataObj.RecSet["vCREATEDBY"].ToString();
                    item.Modifiedby = DataObj.RecSet["vMODIFIEDBY"].ToString();
                    item.SessionCount = Convert.ToInt32(DataObj.RecSet["vSESSIONCOUNT"]);
                    item.LastSession = Convert.ToDateTime(DataObj.RecSet["vLASTSESSION"]);
                    item.DirectorateId = Convert.ToInt32(DataObj.RecSet["vDIRECORATE"]);
                    item.DivisionId = Convert.ToInt32(DataObj.RecSet["vDIVISION"]);
                    item.RegionId = Convert.ToInt32(DataObj.RecSet["vREGIONID"]);
                    item.Telephone = DataObj.RecSet["vTEL"].ToString();
                    item.Floor = DataObj.RecSet["vFLOOR"].ToString();
                    item.OfficeNo = DataObj.RecSet["vOFFICENO"].ToString();
                    Listing.Add(item);
                }
            }

            DataObj.RecSet.Close();
            DataObj.SetDbConn(0, DataObj.dbConnSysMan);
        }

        public UserList(string selIndex)
        {
            Listing = new List<User>();
            DataObj.SetDbConn(1, DataObj.dbConnSysMan);

            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLData.UserBaseSelect);

            if (selIndex == "0-9")
            {
                outStr.Append(" and not (left(Name,1) IN ('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z')) ");
            }
            else
            {
                outStr.Append(" and (upper(Name) like '" + selIndex.ToUpper() + "%') ");
            }

            outStr.Append(" order by Name");


            DataObj.SqlQuery.CommandText = outStr.ToString();
            DataObj.RecSet = DataObj.SqlQuery.ExecuteReader();

            if (DataObj.RecSet.HasRows)
            {
                while (DataObj.RecSet.Read())
                {
                    User item = new User();
                    item.Id = Convert.ToInt32(DataObj.RecSet["vID"]);
                    item.Ad = DataObj.RecSet["vADNAME"].ToString();
                    item.Name = DataObj.RecSet["vNAME"].ToString();
                    item.Surname = DataObj.RecSet["vSURNAME"].ToString();
                    item.FullName = DataObj.RecSet["vNAME"].ToString() + " " + DataObj.RecSet["vSURNAME"].ToString();
                    item.Email = DataObj.RecSet["vEMAIL"].ToString();
                    item.Mobile_Phone = DataObj.RecSet["vPHONE"].ToString();
                    item.Active = Convert.ToInt32(DataObj.RecSet["vACTIVE"]);
                    item.Deleted = Convert.ToInt32(DataObj.RecSet["vDELETED"]);
                    item.Created = Convert.ToDateTime(DataObj.RecSet["vCREATEDDATE"]);
                    item.Modified = Convert.ToDateTime(DataObj.RecSet["vMODIFIEDDATE"]);
                    item.CreatedBy = DataObj.RecSet["vCREATEDBY"].ToString();
                    item.Modifiedby = DataObj.RecSet["vMODIFIEDBY"].ToString();
                    item.SessionCount = Convert.ToInt32(DataObj.RecSet["vSESSIONCOUNT"]);
                    item.LastSession = Convert.ToDateTime(DataObj.RecSet["vLASTSESSION"]);
                    item.DirectorateId = Convert.ToInt32(DataObj.RecSet["vDIRECORATE"]);
                    item.DivisionId = Convert.ToInt32(DataObj.RecSet["vDIVISION"]);
                    item.RegionId = Convert.ToInt32(DataObj.RecSet["vREGIONID"]);
                    item.Telephone = DataObj.RecSet["vTEL"].ToString();
                    item.Floor = DataObj.RecSet["vFLOOR"].ToString();
                    item.OfficeNo = DataObj.RecSet["vOFFICENO"].ToString();
                    Listing.Add(item);
                }
            }

            DataObj.RecSet.Close();
            DataObj.SetDbConn(0, DataObj.dbConnSysMan);
        }
    }
}