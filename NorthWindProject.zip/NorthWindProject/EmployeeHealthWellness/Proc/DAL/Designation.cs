﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace EmployeeHealthWellness.Proc.DAL
{
    public class Designation
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int Active { get; set; }
        public String DesignationName { get; set; }

        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public Designation() { }

        public Designation(int DesignationID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.DesignationBaseSelect);
            outStr.Append(" AND Id = " + DesignationID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.DesignationName = dataObj.RecSet["PositionName"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLEHWPData.DesignationBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.DesignationName + "',");
                outStr.Append("'" + this.Active + "' ,");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_designation Set ");
                outStr.Append("PositionName = '" + this.DesignationName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;

        }
        public bool CheckIfExist()
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.DesignationName))
            {
                outStr.Append("select  * from tbl_designation WHERE ('x'='x') ");
                outStr.Append(" and (");

                if (!string.IsNullOrEmpty(this.DesignationName))
                {
                    outStr.Append(" PositionName ='" + this.DesignationName + "' ");
                }
            }

            outStr.Append(") ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();


            List<string> ErrorMessage = new List<string>();
            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
                ErrorMessage.Add("*  Name with the name supplied " + this.DesignationName + " already exist.");

            }

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            if (AlreadyExist)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return AlreadyExist;
        }
    }

    public class DesignationList
    {
        Data dataObj = new Data();
        public List<Designation> Listing { get; set; }
        public DesignationList(bool showOnlyActive)
        {
            Listing = new List<Designation>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.DesignationBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            outStr.Append("order by PositionName");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    Designation item = new Designation();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.DesignationName = dataObj.RecSet["PositionName"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }
    public class ServiceType
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int Active { get; set; }
        public String ServiceTypeName { get; set; }

        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public ServiceType() { }

        public ServiceType(int DesignationID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ServiceTypeBaseSelect);
            outStr.Append(" AND Id = " + DesignationID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.ServiceTypeName = dataObj.RecSet["ServiceTypeName"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLEHWPData.ServiceTypeBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.ServiceTypeName + "',");
                outStr.Append("'" + this.Active + "' ,");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_service_type Set ");
                outStr.Append("ServiceTypeName = '" + this.ServiceTypeName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;

        }
        public bool CheckIfExist()
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.ServiceTypeName))
            {
                outStr.Append("select  * from tbl_service_type WHERE ('x'='x') ");
                outStr.Append(" and (");

                if (!string.IsNullOrEmpty(this.ServiceTypeName))
                {
                    outStr.Append(" ServiceTypeName ='" + this.ServiceTypeName + "' ");
                }
            }

            outStr.Append(") ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();


            List<string> ErrorMessage = new List<string>();
            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
                ErrorMessage.Add("*  Name with the name supplied " + this.ServiceTypeName + " already exist.");

            }

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            if (AlreadyExist)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return AlreadyExist;
        }
    }

    public class ServiceTypeList
    {
        Data dataObj = new Data();
        public List<ServiceType> Listing { get; set; }
        public ServiceTypeList(bool showOnlyActive)
        {
            Listing = new List<ServiceType>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ServiceTypeBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            outStr.Append(" order by CreatedDate");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    ServiceType item = new ServiceType();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.ServiceTypeName = dataObj.RecSet["ServiceTypeName"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }

    //problem cat
    public class ProblemCategory
    {
        Data dataObj = new Data();
        public int Id { get; set; }
        public int Active { get; set; }
        public String CategoryName { get; set; }

        public String CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public String Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public ProblemCategory() { }

        public ProblemCategory(int DesignationID)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP); //Opend DB Connection
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ProblemCategoryBaseSelect);
            outStr.Append(" AND Id = " + DesignationID);

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    this.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    this.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    this.CategoryName = dataObj.RecSet["ProblemCatName"].ToString();
                    this.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    this.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    this.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    this.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP); //Close DB Connection
        }

        public string CreateUpdate(bool isNew)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (isNew) // insert query
            {
                outStr.Clear();
                outStr.Append(SQLEHWPData.ProblemCategoryBaseInsert);
                outStr.Append(" values (");
                outStr.Append("'" + this.CategoryName + "',");
                outStr.Append("'" + this.Active + "' ,");
                outStr.Append("'" + this.CreatedBy + "',");
                outStr.Append("'" + this.CreatedDate.ToString("yyyy-MM-dd HH:mm:ss") + "', ");
                outStr.Append("'" + this.Modifiedby + "',");
                outStr.Append("'" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append(")");
            }
            else  // update query
            {
                outStr.Clear();
                outStr.Append("Update tbl_problem_category Set ");
                outStr.Append("ProblemCatName = '" + this.CategoryName + "', ");
                outStr.Append("Active = '" + this.Active + "', ");
                outStr.Append("ModifiedBy = '" + this.Modifiedby + "', ");
                outStr.Append("ModifiedDate = '" + this.ModifiedDate.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                outStr.Append("WHERE Id = " + this.Id + "");
            }

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.SqlQuery.ExecuteNonQuery();

            string retValue = this.Id.ToString();

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            return retValue;

        }
        public bool CheckIfExist()
        {
            bool AlreadyExist = false;
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();

            if (!string.IsNullOrEmpty(this.CategoryName))
            {
                outStr.Append("select  * from tbl_problem_category WHERE ('x'='x') ");
                outStr.Append(" and (");

                if (!string.IsNullOrEmpty(this.CategoryName))
                {
                    outStr.Append(" ProblemCatName ='" + this.CategoryName + "' ");
                }
            }

            outStr.Append(") ");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();


            List<string> ErrorMessage = new List<string>();
            if (dataObj.RecSet.HasRows)
            {
                AlreadyExist = true;
                ErrorMessage.Add("*  Name with the name supplied " + this.CategoryName + " already exist.");

            }

            dataObj.SetDbConn(0, dataObj.dbConnEHWP);

            if (AlreadyExist)
            {
                AppExceptions custExeption = new AppExceptions();
                custExeption.ErrorMessage = ErrorMessage;
                throw custExeption;
            }

            return AlreadyExist;
        }
    }

    public class ProblemCatList
    {
        Data dataObj = new Data();
        public List<ProblemCategory> Listing { get; set; }
        public ProblemCatList(bool showOnlyActive)
        {
            Listing = new List<ProblemCategory>();
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);
            StringBuilder outStr = new StringBuilder();
            outStr.Append(SQLEHWPData.ProblemCategoryBaseSelect);

            if (showOnlyActive)
            {
                outStr.Append(" AND Active = 1 ");
            }

            outStr.Append("order by ProblemCatName");

            dataObj.SqlQuery.CommandText = outStr.ToString();
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    ProblemCategory item = new ProblemCategory();
                    item.Id = Convert.ToInt32(dataObj.RecSet["Id"]);
                    item.Active = Convert.ToInt32(dataObj.RecSet["Active"]);
                    item.CategoryName = dataObj.RecSet["ProblemCatName"].ToString();
                    item.CreatedBy = dataObj.RecSet["CreatedBy"].ToString();
                    item.CreatedDate = Convert.ToDateTime(dataObj.RecSet["CreatedDate"]);
                    item.Modifiedby = dataObj.RecSet["ModifiedBy"].ToString();
                    item.ModifiedDate = Convert.ToDateTime(dataObj.RecSet["ModifiedDate"]);
                    Listing.Add(item);
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }



}