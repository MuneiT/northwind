﻿using EmployeeHealthWellness.Proc;
using EmployeeHealthWellness.Proc.BL;
using EmployeeHealthWellness.Proc.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EmployeeHealthWellness
{
    public partial class DesignationEdit : System.Web.UI.Page
    {
        public bool IsNew = false;
        public int Id = 0;
        public string thisUrl = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["new"]) && Gen.isSpecificType(Request.QueryString["new"], "bool"))
            {
                IsNew = Convert.ToBoolean(Request.QueryString["new"]);
            }

            if (!string.IsNullOrEmpty(Request.QueryString["id"]) && Gen.isSpecificType(Request.QueryString["id"], "int"))
            {
                Id = Convert.ToInt32(Request.QueryString["id"]);
            }

            if (!Page.IsPostBack)
            {
                if (!IsNew)
                {
                    ReferralType SectorEntry = new ReferralType(Id);
                    if (SectorEntry.Id > 0)
                    {
                        this.f_active.Checked = Convert.ToBoolean(SectorEntry.Active);
                        this.f_CorridorName.Text = SectorEntry.ReferralTypeName;

                    }
                }
            }
        }

        protected void btnCommit_Click(object sender, EventArgs e)
        {
            try
            {
                saveData(false);
            }
            catch (AppExceptions ex)
            {
                string output = string.Empty;

                foreach (string msg in ex.ErrorMessage)
                {
                    output += msg + "<br />";
                }

                lblException.Text = output;
                pnlException.Visible = true;
                pnlInterface.Visible = false;
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Gen.refreshParent(this, string.Empty);
            Response.Redirect("PositionList.aspx");
        }

        protected void saveData(bool reload)
        {
            List<string> ErrorMessage = new List<string>();

            if (EntriesBL.validatePositon(f_CorridorName.Text))
            {
                String curUser = Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["name"] + " " + Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["surname"];
                String curDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");

                Designation thisCorridor = new Designation();
                thisCorridor.Active = Convert.ToInt32(f_active.Checked);
                thisCorridor.DesignationName = this.f_CorridorName.Text.Replace("'", "''");

                if (!IsNew)
                {
                    thisCorridor.Id = Id;
                    thisCorridor.Modifiedby = curUser;
                    thisCorridor.ModifiedDate = Convert.ToDateTime(curDateTime);
                }
                else
                {
                    thisCorridor.CreatedBy = curUser;
                    thisCorridor.CreatedDate = Convert.ToDateTime(curDateTime);

                }
                String curRecID = string.Empty;

                if (IsNew)
                {
                    if (!thisCorridor.CheckIfExist())
                    {
                        curRecID = thisCorridor.CreateUpdate(IsNew);
                    }
                }
                else
                {
                    curRecID = thisCorridor.CreateUpdate(IsNew);
                }

                if (!reload)
                {
                    Gen.refreshParent(this, string.Empty);
                }
                else
                {
                    Response.Redirect("DesignationEdit.aspx?new=false&id=" + curRecID);
                }
            }
        }

        protected void btnCloseError_Click(object sender, EventArgs e)
        {
            pnlInterface.Visible = true;
            pnlException.Visible = false;
        }
    }
}