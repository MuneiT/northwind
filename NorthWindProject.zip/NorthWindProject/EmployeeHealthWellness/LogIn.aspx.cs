﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Text;
using EmployeeHealthWellness.Proc;

using EmployeeHealthWellness.Proc.DAL;

namespace EmployeeHealthWellness
{
    public partial class LogIn : System.Web.UI.Page
    {
    
  
    }
}