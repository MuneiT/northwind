﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeeHealthWellness.Proc;

namespace EmployeeHealthWellness.Common.UC
{
    public partial class PageOpener : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public void showPopupMesage(string titleMessage, int width, int height, String _urlToNavigate)
        {
            pnlPopup.Width = width;
            pnlPopup.Height = height;
            urIframe.Attributes.Add("src", _urlToNavigate);

            lt_Title.Text = titleMessage;

            MessageBoxModalPopup.Show();
        }

        public void closePopup()
        {
            MessageBoxModalPopup.Hide();
        }

        protected void btnClose_Click(object sender, EventArgs e)
        {
            MessageBoxModalPopup.Hide();
        }
    }
}