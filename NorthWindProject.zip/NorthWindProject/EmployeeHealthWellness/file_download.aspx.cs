﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeeHealthWellness.Proc;

namespace EmployeeHealthWellness
{
    public partial class file_download : System.Web.UI.Page
    {
        Data dataObj = new Data();
        String fid = "";
        public string strDefaultReportPath = "LogRequestAttachments";

        protected void Page_Unload(object sender, EventArgs e)
        {
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            dataObj.SetDbConn(1, dataObj.dbConnEHWP);

            fid = Request.QueryString["fid"];

            String query;

            query = "select filename from hd_ticket_screenshott_attachement where id=" + fid;

            dataObj.SqlQuery.CommandText = query;
            dataObj.RecSet = dataObj.SqlQuery.ExecuteReader();

            if (dataObj.RecSet.HasRows)
            {
                while (dataObj.RecSet.Read())
                {
                    String dlDir = MapPath(strDefaultReportPath) + "\\";
                    Gen.forceFileDownload(dlDir, dataObj.RecSet["filename"].ToString());
                }
            }

            dataObj.RecSet.Close();
            dataObj.SetDbConn(0, dataObj.dbConnEHWP);
        }
    }
}