﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EmployeeHealthWellness.Proc;

namespace EmployeeHealthWellness
{
    public partial class appError : System.Web.UI.Page
    {
        string err = "The system process could not be completed";
        bool sb = false;
        String errorMessage = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["err"]))
            {
                err = Request.QueryString["err"];
            }

            if (!string.IsNullOrEmpty(Request.QueryString["sb"]) && Gen.isSpecificType(Request.QueryString["sb"], "bool") == true)
            {
                sb = Convert.ToBoolean(Request.QueryString["sb"]);
            }

            if (!string.IsNullOrEmpty(Request.QueryString["errMsg"]))
            {
                errorMessage = Request.QueryString["errMsg"];
            }

            switch (err)
            {
                case "userpermission":
                    ltlErrMsg.Text = "User '" + Request.ServerVariables["REMOTE_USER"].ToString() + "' does not have permission to use <strong>EMPLOYEE AND WELLNESS MANAGEMENT SYSTEM</strong>.";
                    break;

                case "email":
                    ltlErrMsg.Text = "Error Occured on <strong>EMAIL PROBLEM</strong></ br> : A network problem occurred while attempting to alert the selected stakeholders";
                    break;

                default:
                    ltlErrMsg.Text = "Error Occured on <strong>EMPLOYEE AND WELLNESS MANAGEMENT SYSTEM/strong></ br> : " + errorMessage;
                    break;
            }

            pnlButton.Visible = sb;
        }
    }
}