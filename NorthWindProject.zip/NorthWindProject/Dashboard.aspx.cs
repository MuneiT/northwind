﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using EmployeeHealthWellness.Proc.DAL;
using EmployeeHealthWellness.Proc;
using AjaxControlToolkit;
using System.Data;
using System.Drawing;
//using System.Web.UI.DataVisualization.Charting;
using System.Text;
using FusionCharts.Charts;

namespace EmployeeHealthWellness
{
    public partial class Dashboard : System.Web.UI.Page
    {
        public DateTime StartDate = DateTime.Now.AddMonths(-1);
        public DateTime EndDate = DateTime.Now.AddHours(1);
        public bool viewOwnTickets = false, viewTechTickets = false, mustbeActive = false;
        public string startDate = string.Empty, endDate = string.Empty, dateRangeType = "ld";

        public string reqPeriod = DateTime.Now.ToString("yyyy-MM-01");

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(Request.QueryString["viewOwnTickets"]) && Gen.isSpecificType(Request.QueryString["viewOwnTickets"], "bool"))
            {
                viewOwnTickets = Convert.ToBoolean(Request.QueryString["viewOwnTickets"]);
            }

            if (Gen.isSpecificType(Request.QueryString["reqPeriod"], "date"))
            {
                reqPeriod = Convert.ToDateTime(Request.QueryString["reqPeriod"]).ToString("yyyy-MM-01");
            }

            if (!Page.IsPostBack)
            {
              //  PopulateTicketAuthethicationInfo();
                //buildQuickFilterMenuItems();
            }
        }

        string GenerateJSON(DataTable dt, string GraphyTitle)
        {
            
            StringBuilder JsonString = new StringBuilder();

            if (dt.Rows.Count > 0)
            {

                JsonString.Append("{\"chart\":{\"caption\":\"" + GraphyTitle + "\",\"xaxisname\":\"Month\",\"yaxisname\":\"Revenue\",\"numberprefix\":\"\",\"showvalues\":\"1\",\"animation\":\"0\"},\"data\"");
                JsonString.Append("     :[");
                foreach (DataRow row in dt.Rows) // Loop over the rows.
                {
                    JsonString.Append("     {\"label\":\"" + row[0] + "\"" + "," + "\"value\"" + ":\"" +row[1] + "\"},");
                }

                if (JsonString.Length > 0) { JsonString = JsonString.Remove(JsonString.Length - 1, 1); }

                JsonString.Append("     ]");
                JsonString.Append(",\"trendlines\":[{\"line\":[{\"startvalue\":\"700000\",\"istrendzone\":\"1\",\"valueonright\":\"1\",\"tooltext\":\"AYAN\",\"endvalue\":\"900000\",\"color\":\"009933\",\"displayvalue\":\"Target\",\"showontop\":\"1\",\"thickness\":\"5\"}]}],\"styles\":{\"definition\":[{\"name\":\"CanvasAnim\",\"type\":\"animation\",\"param\":\"_xScale\",\"start\":\"0\",\"duration\":\"1\"}],\"application\":[{\"toobject\":\"Canvas\",\"styles\":\"CanvasAnim\"}]}}");
            }
    
            return JsonString.ToString();
        }

        void pupulateGraph(DataTable dt, string graphType, bool HighDifinition, string reportType)
        {
            Chart tickets = new Chart();
            tickets.SetChartParameter(Chart.ChartParameter.chartWidth, "700");

             //Setting chart height to 350px
            tickets.SetChartParameter(Chart.ChartParameter.chartHeight, "380");

            // Setting chart data as XML URL
            //sales.SetData("Data/Data.xml", Chart.DataFormat.xmlurl);

            string JsonData = string.Empty;

            
            //http://www.fusioncharts.com/asp-net-charts/

            

            switch (reportType)
            {
                case "status":
                    JsonData = GenerateJSON(dt, "Monthly Ticket(s) Summary per Status");
                    tickets.SetChartParameter(Chart.ChartParameter.chartId, "myStatusChart");
                    tickets.SetChartParameter(Chart.ChartParameter.chartType, "pie3d");
                    tickets.SetData(JsonData);
                    lit_ByStatus.Text = tickets.Render();
                    break;

                case "priority":
                    JsonData = GenerateJSON(dt, "Monthly Ticket(s) Summary per Priority");
                    tickets.SetChartParameter(Chart.ChartParameter.chartId, "myPriorityChart");
                    tickets.SetChartParameter(Chart.ChartParameter.chartType, "pie3d");
                    tickets.SetData(JsonData);
                    lit_ByPriority.Text = tickets.Render();
                    break;

                case "category":
                    JsonData = GenerateJSON(dt, "Monthly Ticket(s) Summary per Category");
                    tickets.SetChartParameter(Chart.ChartParameter.chartId, "myCatChart");
                    tickets.SetChartParameter(Chart.ChartParameter.chartType, "pie3d");
                    tickets.SetData(JsonData);
                    lit_ByCategory.Text = tickets.Render();
                    break;
            }

            pnlBarChart.Visible = true;

            //switch(graphType)
            //{
            //    case "bar":
            //        pnlBarChart.Visible = true;
            //        Chart barChart = new Chart();

            //        barChart.Series.Add(new Series());
            //        barChart.ChartAreas.Add(new ChartArea());

            //        if(HighDifinition)
            //        {
            //           barChart.ChartAreas[0].Area3DStyle.Enable3D = true;
            //        }

            //        barChart.Series[0].YValueMembers = "y";
            //        barChart.Series[0].XValueMember = "x";

            //        //barChart.Series.Add(new Series());
            //        //barChart.Series[1].YValueMembers = "y";

            //        barChart.DataSource = dt;
            //        barChart.DataBind();

            //        //barChart.Series[0].Color = Color.Blue;

            //        Random random = new Random();
            //        foreach (var item in barChart.Series[0].Points)
            //        {
            //            Color c = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));
            //            item.Color = c;
            //        }

            //        barChart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
            //        barChart.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
            //        barChart.ChartAreas[0].AxisX.LabelStyle.Angle = -90;

            //        barChart.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Verdana", 11f, FontStyle.Regular);
            //        barChart.ChartAreas[0].AxisY.LabelStyle.Font = new Font("Verdana", 11f, FontStyle.Regular);
            //        barChart.Series[0].Font = new System.Drawing.Font("Verdana", 10f, System.Drawing.FontStyle.Bold); //, System.Drawing.FontStyle.Bold

            //        barChart.ChartAreas[0].AxisY.LabelStyle.ForeColor = System.Drawing.Color.Red;
            //        barChart.ChartAreas[0].AxisX.LabelStyle.ForeColor = System.Drawing.Color.DarkBlue;
            //        barChart.Series[0].IsValueShownAsLabel = true;                   
            //        barChart.ImageType = System.Web.UI.DataVisualization.Charting.ChartImageType.Jpeg;
            //        barChart.Width = new System.Web.UI.WebControls.Unit(550, System.Web.UI.WebControls.UnitType.Pixel);

            //        switch (reportType)
            //        {
            //            case "status":
            //                //phStatus.Controls.Add(barChart);
            //                break;

            //            case "priority":
            //                //phPriorities.Controls.Add(barChart);
            //                break;

            //            case "category":
            //                //phCategories.Controls.Add(barChart);
            //                break;
            //        }
            //        break;


            //    case "pie":
            //        break;
            //}
        }

        void PopulateTicketAuthethicationInfo()
        {
            bool HelpDeskClientAdmin = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["admin"]);
            bool supportStaff = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["staff"]);

            if (HelpDeskClientAdmin || supportStaff)
            {
                pnlAdministrativeQuickMenus.Visible = true;
                hlManageTickets.Attributes.Add("onclick", "window.location='StartUp.html?page=TicketsList.aspx';");

                if (HelpDeskClientAdmin)
                {
                    //mustbeActive = false;
                    hlAddUserProfile.Attributes.Add("onclick", "OpenPopupDialog('divPopupDialog', 'ifOptions', 400, 790, 'UserProfile.aspx?new=true','PopUpBase PopPrimary'); return false;");
                    hlUserManagement.Attributes.Add("onclick", "window.location='StartUp.html?page=UserManagement.aspx';");

                    //pnlKnowledgeBaseAdmin.Visible = true;
                    pnlUserManagementAdmin.Visible = true;
                }
                //else
                //{
                //    mustbeActive = true;
                //}

                if (supportStaff && !viewOwnTickets)
                {
                    viewTechTickets = false;
                }
            }
            else
            {
                viewOwnTickets = true;
                //mustbeActive = true;
            }

            //Accesable to Everyone
            hlViewMyLoggedTickets.Attributes.Add("onclick", "window.location='StartUp.html?page=TicketsList.aspx?viewOwnTickets=true';");
            hlDashboard.Attributes.Add("onclick", "window.location='StartUp.html?page=Dashboard.aspx';");
            hlUserProfile.Attributes.Add("onclick", "OpenPopupDialog('divPopupDialog', 'ifOptions', 400, 790, 'UserProfile.aspx?id=" + Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["id"] + "&new=false','PopUpBase PopPrimary'); return false;");

        }

        protected void buildQuickFilterMenuItems()
        {
            bool HelpDeskClientAdmin = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["admin"]);
            bool supportStaff = Convert.ToBoolean(Request.Cookies[ConfigurationManager.AppSettings["PrimaryCookie"]]["staff"]);

            if (string.IsNullOrEmpty(startDate) && string.IsNullOrEmpty(endDate))
            {
                startDate = reqPeriod.ToString();
                var lastDayOfMonth = DateTime.DaysInMonth(Convert.ToDateTime(startDate).Year, Convert.ToDateTime(startDate).Month);
                DateTime lastdayOfMonth = new DateTime(Convert.ToDateTime(startDate).Year, Convert.ToDateTime(startDate).Month, lastDayOfMonth);
                endDate = lastdayOfMonth.ToString("yyyy-MM-dd");
            }

            reqPeriod = Convert.ToDateTime(startDate).ToString("yyyy-MM-01");

            StringBuilder str = new StringBuilder();
            str.Append("<table width=\"100%\" border=\"0\" align=\"center\" cellpadding=\"3\" cellspacing=\"1\">");
            str.Append("	<tr>");
            str.Append("		<td align=\"center\">");
            str.Append("			<span class=\"txt_blue_cgothic_13\"><a href=\"Dashboard.aspx?reqPeriod=" + Convert.ToDateTime(reqPeriod).AddMonths(-1).ToString("yyyy-MM-01") + "&viewOwnTickets=" + viewOwnTickets + "\"><em>&lt;&lt;&nbsp;" + Convert.ToDateTime(reqPeriod).AddMonths(-1).ToString("MMMM").ToUpper() + "</em></a></span>&nbsp;&nbsp;&nbsp;");
            str.Append("			<span class=\"txt_blue_cgothic_18\"><em><strong>" + Convert.ToDateTime(reqPeriod).ToString("MMMM yyyy").ToUpper() + "</strong></em></span>&nbsp;&nbsp;&nbsp;");
            str.Append("			<span class=\"txt_blue_cgothic_13\"><a href=\"Dashboard.aspx?reqPeriod=" + Convert.ToDateTime(reqPeriod).AddMonths(+1).ToString("yyyy-MM-01") + "&viewOwnTickets=" + viewOwnTickets + "\"><em>" + Convert.ToDateTime(reqPeriod).AddMonths(+1).ToString("MMMM").ToUpper() + "&nbsp;&gt;&gt;</em></a></span>");
            str.Append("		</td>");
            str.Append("	</tr>");
            str.Append("</table>");
            lit_calendarNavigation.Text = str.ToString();

            TicketList thisList = new TicketList(mustbeActive, "", "", "", "", "", "", viewOwnTickets, viewTechTickets, dateRangeType, startDate, endDate, "");

            HttpBrowserCapabilities browser = HttpContext.Current.Request.Browser;
            int width = browser.ScreenBitDepth;

            if (thisList.Listing.Count > 0)
            {
                //var generalSelectQuery = thisList.Listing.Where(i => i.Active == 1);
                int totalRecords = 0;
                var generalAllQuery = thisList.Listing;
                //var generalActiveQuery = thisList.Listing.Where(i => i.Active == 1);
                //var generalTrashedDeletedQuery = thisList.Listing.Where(i => i.Active == 0);

                if (generalAllQuery.Count() > 0)
                {
                    
                    lit_QuickMenu.Text += "<tbody>";

                    DataTable dtAllStatusTickets = new DataTable();
                    dtAllStatusTickets.Columns.Add("x", typeof(string));
                    dtAllStatusTickets.Columns.Add("y", typeof(int));

                    var grpByQuery = generalAllQuery.Where(i => i.Active == 1).GroupBy(x => new { x.StatusCodeId }).OrderBy(x => x.Key.StatusCodeId).Where(i => i.Key.StatusCodeId != 7 && i.Key.StatusCodeId != 4);
                    if (grpByQuery.Count() > 0)
                    {
                        totalRecords = 0;                        
                        foreach (var statusItem in grpByQuery)
                        {
                            string StatusName = Gen.getStatus(statusItem.Key.StatusCodeId);
                            int row = statusItem.Count();
                            totalRecords += row;

                            dtAllStatusTickets.Rows.Add(StatusName, row);

                            lit_QuickMenu.Text += "<tr>" + Environment.NewLine;
                            lit_QuickMenu.Text += "    <td align=\"left\" valign=\"middle\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=true&selStatus=" + statusItem.Key.StatusCodeId + "&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">" + Gen.buildStatusImageUrl(statusItem.Key.StatusCodeId) + "&nbsp;" + StatusName + " <span class=\"badge\"><strong>" + row + "</strong></span></a></td>" + Environment.NewLine;
                            lit_QuickMenu.Text += "</tr>" + Environment.NewLine;
                        }
                    }

                    //Get Closed Calls
                    
                    var grpByClosedQuery = generalAllQuery.Where(i => i.Active == 0).GroupBy(x => new { x.StatusCodeId }).OrderBy(x => x.Key.StatusCodeId).Where(i => i.Key.StatusCodeId == 4);
                    foreach (var statusItem in grpByClosedQuery)
                    {
                        string StatusName = Gen.getStatus(statusItem.Key.StatusCodeId);
                        int row = statusItem.Count();
                        totalRecords += row;

                        dtAllStatusTickets.Rows.Add(StatusName, row);
                        //dtAllStatusTickets.Rows.Add(row, StatusName);

                        lit_QuickMenu.Text += "<tr>" + Environment.NewLine;
                        lit_QuickMenu.Text += "    <td align=\"left\" valign=\"middle\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=false&selStatus=" + statusItem.Key.StatusCodeId + "&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">" + Gen.buildStatusImageUrl(statusItem.Key.StatusCodeId) + "&nbsp;Closed" + " <span class=\"badge\"><strong>" + row + "</strong></span></a></td>" + Environment.NewLine;
                        lit_QuickMenu.Text += "</tr>" + Environment.NewLine;
                    }


                    //Get Trashed Calls
                    if (HelpDeskClientAdmin || supportStaff)
                    {
                        var grpByTrashedQuery = generalAllQuery.Where(i => i.Active == 0).GroupBy(x => new { x.StatusCodeId }).OrderBy(x => x.Key.StatusCodeId).Where(i => i.Key.StatusCodeId == 7);
                        foreach (var statusItem in grpByTrashedQuery)
                        {
                            string StatusName = Gen.getStatus(statusItem.Key.StatusCodeId);
                            int row = statusItem.Count();
                            totalRecords += row;

                            dtAllStatusTickets.Rows.Add(StatusName, row);
                            //dtAllStatusTickets.Rows.Add(row, StatusName);

                            lit_QuickMenu.Text += "<tr>" + Environment.NewLine;
                            lit_QuickMenu.Text += "    <td align=\"left\" valign=\"middle\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=false&selStatus=" + statusItem.Key.StatusCodeId + "&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">" + Gen.buildStatusImageUrl(statusItem.Key.StatusCodeId) + "&nbsp;Trashed" + " <span class=\"badge\"><strong>" + row + "</strong></span></a></td>" + Environment.NewLine;
                            lit_QuickMenu.Text += "</tr>" + Environment.NewLine;
                        }
                    }


                    lit_QuickMenu.Text += "<tr>" + Environment.NewLine;
                    lit_QuickMenu.Text += "    <td align=\"left\" valign=\"middle\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=false&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">" + Gen.buildStatusImageUrl(-1) + "&nbsp;All Status Call Tickets" + "  <span class=\"badge\"><strong>" + totalRecords + "</strong></span></a></td>" + Environment.NewLine;
                    lit_QuickMenu.Text += "</tr>" + Environment.NewLine;

                    lit_QuickMenu.Text += "</tbody>";


                    //Pupulate Graph
                    pupulateGraph(dtAllStatusTickets, "bar", false, "status");
                    quickFilter.Visible = true;
                }


                //     

                //Build Priority Level
                var grpByPriorityQuery = generalAllQuery.GroupBy(x => new { x.PriorityLevelId }).OrderBy(x => x.Key.PriorityLevelId);
                if (grpByPriorityQuery.Count() > 0)
                {
                    DataTable dtAllPriorityTickets = new DataTable();
                    dtAllPriorityTickets.Columns.Add("x", typeof(string));
                    dtAllPriorityTickets.Columns.Add("y", typeof(int));


                    string category = "";
                    decimal[] values = new decimal[grpByPriorityQuery.Count()];
                    int counter = -1;

                    totalRecords = 0;
                    priorityFilter.Visible = true;
                    lit_PriorityFilter.Text += "<tbody>";

                    foreach (var priorityItem in grpByPriorityQuery)
                    {
                        counter++;
                        String PriorityName = Gen.getPriorityLevel(priorityItem.Key.PriorityLevelId);
                        int row = priorityItem.Count();

                        dtAllPriorityTickets.Rows.Add(PriorityName, row);
                        totalRecords += row;

                        lit_PriorityFilter.Text += "<tr>" + Environment.NewLine;
                        lit_PriorityFilter.Text += "    <td align=\"left\" valign=\"middle\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=true&selPriorities=" + priorityItem.Key.PriorityLevelId + "&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">" + PriorityName + " <span class=\"badge\"><strong>" + row + "</strong></span></a></td>" + Environment.NewLine;
                        lit_PriorityFilter.Text += "</tr>" + Environment.NewLine;

                        values[counter] = Convert.ToDecimal(row);
                        category = category + "," + PriorityName;
                    }

                    lit_PriorityFilter.Text += "<tr>" + Environment.NewLine;
                    lit_PriorityFilter.Text += "    <td align=\"left\" valign=\"middle\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=false&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">All Priority Call Tickets" + " <span class=\"badge\"><strong>" + totalRecords + "</strong></span></a></td>" + Environment.NewLine;
                    lit_PriorityFilter.Text += "</tr>" + Environment.NewLine;

                    lit_PriorityFilter.Text += "</tbody>";

                    //brPriorityDashboard.CategoriesAxis = category.Remove(0, 1);
                    //brPriorityDashboard.Series.Add(new BarChartSeries { Data = values, BarColor = "#2fd1f9", Name = "Ticket Priority" });

                    pupulateGraph(dtAllPriorityTickets, "bar", false, "priority");
                }



                //Populate Category Filter
                var grpByCategoryQuery = generalAllQuery.GroupBy(x => new { x.CategoryId }).OrderBy(x => x.Key.CategoryId);
                if (grpByCategoryQuery.Count() > 0)
                {

                    DataTable dtAllCategoryTickets = new DataTable();
                    dtAllCategoryTickets.Columns.Add("x", typeof(string));
                    dtAllCategoryTickets.Columns.Add("y", typeof(int));

                    string category = "";
                    decimal[] values = new decimal[grpByCategoryQuery.Count()];
                    int counter = -1;

                    totalRecords = 0;
                    categoryFilter.Visible = true;
                    lit_categorylist.Text += "<tbody>";
                    foreach (var catItem in grpByCategoryQuery)
                    {
                        counter++;
                        string CategoryName = Gen.getTicketCategory(catItem.Key.CategoryId);
                        int row = catItem.Count();

                        dtAllCategoryTickets.Rows.Add(CategoryName, row);
                        totalRecords += row;

                        lit_categorylist.Text += "<tr>" + Environment.NewLine;
                        lit_categorylist.Text += "    <td align=\"left\" valign=\"top\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=true&selCategories=" + catItem.Key.CategoryId + "&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">" + CategoryName + " <span class=\"badge\"><strong>" + row + "</strong></span></a></td>" + Environment.NewLine;
                        lit_categorylist.Text += "</tr>" + Environment.NewLine;

                        values[counter] = Convert.ToDecimal(row);
                        category = category + "," + CategoryName;
                    }

                    lit_categorylist.Text += "<tr>" + Environment.NewLine;
                    lit_categorylist.Text += "    <td align=\"left\" valign=\"middle\" class=\"datagridRow txt_blue_cgothic_13\" bgcolor=\"#FFFFFF\"><a class=\"hyperLinkClass\" href=\"StartUp.html?page=TicketsList.aspx?mustBeActive=false&viewOwnTickets=" + viewOwnTickets + "&reqPeriod=" + reqPeriod + "\">All Categories Call Tickets" + " <span class=\"badge\"><strong>" + totalRecords + "</strong></span></a></td>" + Environment.NewLine;
                    lit_categorylist.Text += "</tr>" + Environment.NewLine;

                    lit_categorylist.Text += "</tbody>";

                    pupulateGraph(dtAllCategoryTickets, "bar", false, "category");
                }
            }
        }
    }
}